/*
 * primitives.cpp
 *
 *  Created on: 13 Apr 2023
 *
 */
#include <sys/platform.h>
#include <stdio.h>

#include <stdio.h>
#include <math.h>
#include <float.h>
#include <complex.h>

#include <matrix.h>
#include <filter.h>
#include <vector.h>

#define NVEC 32
#include "primitives.h"
#include "math_fixedpoint_vec.h"
/* Cross-platform data type definitions. */
#include "libdsp_types.h"


#define MIN(X, Y) (((X) < (Y)) ? (X) : (Y))
#define MAX(X, Y) (((X) > (Y)) ? (X) : (Y))

#define USE_EXTRA_PRECISION
#define ROUNDING_MODE                    1
#define ACT_MAX                        127
#define ACT_MIN                       -128
#define INT_32BIT_MAX             0x007FFFFFFF
#define INT_32BIT_MIN             0xFF80000000
#define ARRAY_INPUT_SIZE           8192
#define INT_16BIT_MAX             32767
#define INT_16BIT_MIN            -32768
#define INT_8BIT_MAX                127
#define INT_8BIT_MIN               -128
#define INT_U8BIT_MAX               255
#define INT_3X3_FILTER_WIDTH_x_HEIGHT	9
#define INT_3x3_FILTER_WIDTH			3
#define ROUNDING_MODE_2				2
#define STRIDE_2					2
int64_t nQFormatBuffer[ARRAY_INPUT_SIZE];

inline int8_t quantize_and_store(
				xb_vec2Mx40 acc,
				int32_t pBiasBuffer,
				int32_t nQuantizedMultiplierValue,
				int32_t nQuantizedShiftValue,
				int32_t nFil,
				int32_t pOutZeroPoint
				)
{
	xb_int32 temp;
	xb_int40 sat_sum;
	xb_int80 product;
	sat_sum = PDX_RADD_2MX40(acc);	//PDX_RADD_2MX40: Adds across all 16lanes of acc and returns sum
	if(pBiasBuffer)	{
		sat_sum += ((xb_int40)pBiasBuffer)<<1;
	}
	sat_sum = (MAX(MIN(sat_sum, (xb_int40)INT_32BIT_MAX), (xb_int40)INT_32BIT_MIN));//32bit saturation check to store result
	temp = (xb_int32)((int32_t)((int64_t)PDX_CVT64_40(sat_sum)));	//convert 40bit var into 32bit to perform multiplication

	product = PDX_MULW_32(temp, (xb_int32)nQuantizedMultiplierValue);	//multiply with the quantization multiplier; product(80bit) = temp(32bit) * nQuantizedMultiplier(32bit)
	product =  PDX_SLA_80(product, (xb_int32)nQuantizedShiftValue);		//shift result by quantization multiplier

	temp = PDX_PACKQSRV_80(product,ROUNDING_MODE_2);				//packs 80bit product into 32bit var with saturation and rounding
	temp+= (xb_int32)pOutZeroPoint;									//add output offset
	temp = (MAX(MIN(temp, (xb_int32)INT_8BIT_MAX), (xb_int32)INT_8BIT_MIN));//8bit saturation check to store result

	return (int8_t)((int32_t)temp);
}

//Temp scratch buffer used to introduce padding in depthwise convolution
int8_t pTemp[TEMP_BUFFER_SIZE]__attribute__((section(".L1.data"), aligned(8)));


//1x1 2D convolution in interleaved format using 16bit Eagle intrinsics
void conv2d_1x1_8bitconv_16bitquant(
									const int8_t* pInputBuffer,
									const int8_t* pWeightsBuffer,
									const int32_t* pBiasBuffer,
									int8_t* pOutputBuffer,
									int32_t nBatches,
									int32_t nInChannels,
									int32_t nOutChannels,
									int32_t nSize,
									int32_t *nQuantizedMultiplier,
									int32_t *nQuantizedShift,
									int32_t pInZeroPoint,
									int32_t pOutZeroPoint)
{
	int8_t* __restrict outp = (int8_t*) pOutputBuffer;

	const immediate Lane=0;
	//Defining the input and filter offsets
	xb_vec2Mx16 vInZP = PDX_REP_2MX16((xb_vec2Mx16)pInZeroPoint,Lane);//Replicates the lane of data specified, across all lanes of a vector register

	xb_vec2Mx16 vin,vwt;
	xb_int32 temp;
	xb_int40 sat_sum;
	xb_int80 product;

	vbool4M temp_mask;
	vbool2M acc_mask, ffff;

	temp_mask = PDX_MOVB_AU32(0xFFFFFFFF);
	PDX_CVTBB2M_B4M(ffff, ffff, temp_mask);

	int32_t nPixProcessed=0;

	xb_vec2Mx40 acc = 0;
	xb_vec2Mx8 *inp = (xb_vec2Mx8 *)pInputBuffer;
	int32_t nFilterDepth = nInChannels;
	int32_t nFilterRem = nFilterDepth % 16;//2*PDX_M

	if(nFilterRem != 0){
		int32_t nFilterDepth_16mul = nFilterDepth - nFilterRem;
		temp_mask = PDX_MOVB_AU32((0b1<<(nFilterRem)) - 1);
		acc_mask = PDX_CVTBB2M_B4M_L(temp_mask);

		for (int b = 0; b < nBatches; b++){
			//process upto 2*PDX_M channels at at time for conv
			for(int32_t nCol=0; nCol < nSize; nCol++)//per pixel, do upto 2*PDX_M channel of input channel at at time
			{
				//do all output channels for a single pixel
				for (int32_t nChannelCnt = 0; nChannelCnt < nOutChannels; nChannelCnt++)
				{
					acc = 0;//reset accumulator

					//reset input
					inp = (xb_vec2Mx8 *)(pInputBuffer + nCol*nInChannels);	//Reinitialise input pointer for each output pixel
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + nChannelCnt*nInChannels); //Move to next filter for each output pixel
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//for all the input pixels
					for (nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
					{
						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						PDX_MULAQW_2MX16(acc,vwt,vin);

					}

					PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
					PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
					vin+=vInZP;		//Add input offset

					//multiply and accumulate
					PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);

					sat_sum = PDX_RADD_2MX40(acc);									//PDX_RADD_2MX40: Adds across all 16lanes of acc and returns sum
					//adding bias<<1 to compensate for sign bit during multiplication
					//doubling index for bias buffer to account for 32bit bias instead of 64bit
					if(pBiasBuffer)	{
						sat_sum += (xb_int40)(pBiasBuffer[nChannelCnt]<<1);
					}
					sat_sum = (MAX(MIN(sat_sum, (xb_int40)INT_32BIT_MAX), (xb_int40)INT_32BIT_MIN));//32bit saturation check to store result
					temp = (xb_int32)((int32_t)((int64_t)PDX_CVT64_40(sat_sum)));	//convert 40bit var into 32bit to perform multiplication

					product = PDX_MULW_32(temp, (uint32_t)nQuantizedMultiplier[nChannelCnt]);	//multiply with the quantization multiplier; product(80bit) = temp(32bit) * nQuantizedMultiplier(32bit)
					product =  PDX_SLA_80(product, (xb_int32)nQuantizedShift[nChannelCnt]);		//shift result by quantization multiplier
					temp = PDX_PACKQSRV_80(product,2);								//packs 80bit product into 32bit var with saturation and rounding
					temp+= (xb_int32)pOutZeroPoint;									//add output offset
					temp = (MAX(MIN(temp, (xb_int32)INT_8BIT_MAX), (xb_int32)INT_8BIT_MIN));//8bit saturation check to store result
					*outp++ =(int8_t)((int32_t)temp);								//store result as 8-bit data
				}
			}
		}
	} else {
		for (int b = 0; b < nBatches; b++){
			//No of filter is equals to the nOutsize
			//process upto 2*PDX_M channels at at time for conv
			for(int32_t nCol=0; nCol < nSize; nCol++)//per pixel, do upto 2*PDX_M channel of input channel at at time
			{
				//do all output channels for a single pixel
				for (int32_t nChannelCnt = 0; nChannelCnt < nOutChannels; nChannelCnt++)
				{
					acc = 0;//reset accumulator

					//reset input
					inp = (xb_vec2Mx8 *)(pInputBuffer + nCol*nInChannels);	//Reinitialise input pointer for each output pixel
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + nChannelCnt*nInChannels); //Move to next filter for each output pixel
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//for all the input pixels
					for (nPixProcessed= 0; nPixProcessed < nInChannels; nPixProcessed += (2*PDX_M))
					{
						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						PDX_MULAQW_2MX16(acc,vwt,vin);

					}

					sat_sum = PDX_RADD_2MX40(acc);									//PDX_RADD_2MX40: Adds across all 16lanes of acc and returns sum
					//adding bias<<1 to compensate for sign bit during multiplication
					//doubling index for bias buffer to account for 32bit bias instead of 64bit
					if(pBiasBuffer)	{
						sat_sum += (xb_int40)(pBiasBuffer[nChannelCnt]<<1);
					}
					sat_sum = (MAX(MIN(sat_sum, (xb_int40)INT_32BIT_MAX), (xb_int40)INT_32BIT_MIN));//32bit saturation check to store result
					temp = (xb_int32)((int32_t)((int64_t)PDX_CVT64_40(sat_sum)));	//convert 40bit var into 32bit to perform multiplicatio

					product = PDX_MULW_32(temp, (uint32_t)nQuantizedMultiplier[nChannelCnt]);	//multiply with the quantization multiplier; product(80bit) = temp(32bit) * nQuantizedMultiplier(32bit)
					product =  PDX_SLA_80(product, (xb_int32)nQuantizedShift[nChannelCnt]);		//shift result by quantization multiplier
					temp = PDX_PACKQSRV_80(product,2);								//packs 80bit product into 32bit var with saturation and rounding
					temp+= (xb_int32)pOutZeroPoint;									//add output offset
					temp = (MAX(MIN(temp, (xb_int32)INT_8BIT_MAX), (xb_int32)INT_8BIT_MIN));//8bit saturation check to store result
					*outp++ =(int8_t)((int32_t)temp);								//store result as 8-bit data
				}
			}
		}
	}
	return;
}

void conv2d_3x3_8bit_conv_stride_2x2(
		const int8_t* pInputBuffer,
		const int8_t* pWeightsBuffer,
		const int32_t* pBiasBuffer,
		int8_t* pOutputBuffer,
		int32_t nInChannels,
		int32_t nOutChannels,
		int32_t nWidth,
		int32_t nHeight,
		int32_t nFilters,
		int32_t *nQuantizedMultiplier,
		int32_t *nQuantizedShift,
		int32_t pInZeroPoint,
		int32_t pOutZeroPoint
		)
{

	int8_t* __restrict outp = (int8_t*) pOutputBuffer;

	const immediate Lane=0;
	//Defining the input and filter offsets
	xb_vec2Mx16 vInZP = PDX_REP_2MX16((xb_vec2Mx16)pInZeroPoint,Lane);//Replicates the lane of data specified, across all lanes of a vector register

	xb_vec2Mx16 vin,vwt;
	xb_int32 temp;
	xb_int40 sat_sum;
	xb_int80 product;

	vbool4M temp_mask;
	vbool2M acc_mask, ffff;

	xb_vec2Mx40 acc = 0;
	xb_vec2Mx8 *inp = (xb_vec2Mx8 *)pInputBuffer;
	int32_t nFilterDepth = nInChannels;
	int32_t nFilterRem = nFilterDepth % 16;//2*PDX_M
	int32_t nFilterDepth_16mul = nFilterDepth - nFilterRem;

	//if channels are multiple of 16
	if(nFilterRem == 0)
	{
		int32_t nRow = 0,nCol =0;
		//for 0th row and 0th column
		for(nRow = 1 ;nRow < nHeight-1; nRow+=STRIDE_2)
		{
			for(nCol = 1; nCol < nWidth-1; nCol+=STRIDE_2)
			{
				for(int32_t nFil =0; nFil<nFilters; nFil++)
				{
					acc = 0;//reset accumulator

					for(int32_t nKernelHeight = -1; nKernelHeight<= 1 ; nKernelHeight++)
					{
						int32_t nCurrentRow = (nRow + nKernelHeight);
						for(int32_t nKernelWidth = -1; nKernelWidth<= 1 ; nKernelWidth++)
						{
							int32_t nCurrentCol = (nCol + nKernelWidth);

							inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
							valign ina; // define align vector
							ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

							xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
							valign wta;	// define align vector
							wta=PDX_LA_2MX8_PP (wtp);

							//for all the input pixels
							for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
							{

								PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
								PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
								vin+=vInZP;		//Add input offset

								PDX_MULAQW_2MX16(acc,vwt,vin);
							}
						}
					}
					*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
				}
			}
		}
	}
	else
	{
		int32_t nRow = 0,nCol =0;
		//for 0th row and 0th column

		nFilterDepth_16mul = nFilterDepth - nFilterRem;
		temp_mask = PDX_MOVB_AU32((0b1<<(nFilterRem)) - 1);
		acc_mask = PDX_CVTBB2M_B4M_L(temp_mask);  // mask to accumulate values of remaining channels

		for(nRow = 1 ;nRow < nHeight-1; nRow+=STRIDE_2)
		{
			for(nCol = 1; nCol < nWidth-1; nCol+=STRIDE_2)
			{
				for(int32_t nFil =0; nFil<nFilters; nFil++)
				{
					acc = 0;//reset accumulator

					for(int32_t nKernelHeight = -1; nKernelHeight<= 1 ; nKernelHeight++)
					{
						int32_t nCurrentRow = (nRow + nKernelHeight);
						for(int32_t nKernelWidth = -1; nKernelWidth<= 1 ; nKernelWidth++)
						{
							int32_t nCurrentCol = (nCol + nKernelWidth);

							inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
							valign ina; // define align vector
							ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

							xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
							valign wta;	// define align vector
							wta=PDX_LA_2MX8_PP (wtp);

							//for all the input pixels
							for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
							{

								PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
								PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
								vin+=vInZP;		//Add input offset

								PDX_MULAQW_2MX16(acc,vwt,vin);
							}
							//for remaining channels
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							//multiply and accumulate
							//for ex if input channels are 35, inputs from 1st 32 channels are handled in above for loop.
							// for rest 3 channels the mask will mask out rest 13 lanes and consider only 1st 3 lane for multiply and accumulate.
							PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);
						}
					}
					*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
				}
			}
		}
	}
}


void conv2d_3x3_8bit_conv_stride_1x1(
		const int8_t* pInputBuffer,
		const int8_t* pWeightsBuffer,
		const int32_t* pBiasBuffer,
		int8_t* pOutputBuffer,
		int32_t nInChannels,
		int32_t nOutChannels,
		int32_t nWidth,
		int32_t nHeight,
		int32_t nFilters,
		int32_t *nQuantizedMultiplier,
		int32_t *nQuantizedShift,
		int32_t pInZeroPoint,
		int32_t pOutZeroPoint
		)
{

	int8_t* __restrict outp = (int8_t*) pOutputBuffer;

	const immediate Lane=0;
	//Defining the input and filter offsets
	xb_vec2Mx16 vInZP = PDX_REP_2MX16((xb_vec2Mx16)pInZeroPoint,Lane);//Replicates the lane of data specified, across all lanes of a vector register

	xb_vec2Mx16 vin,vwt;
	xb_int32 temp;
	xb_int40 sat_sum;
	xb_int80 product;

	vbool4M temp_mask;
	vbool2M acc_mask, ffff;

	xb_vec2Mx40 acc = 0;
	xb_vec2Mx8 *inp = (xb_vec2Mx8 *)pInputBuffer;
	int32_t nFilterDepth = nInChannels;
	int32_t nFilterRem = nFilterDepth % 16;//2*PDX_M
	int32_t nFilterDepth_16mul = nFilterDepth - nFilterRem;

	int32_t nChannelCnt = 0;

	/*
	 * The code is split into 7 sections as shown below:
	 *
	 * +---+---------------------------------+---+
	 * | 1 |               2                 | 3 |
	 * +---+---------------------------------+---+
	 * |   x                                 x   |
	 * |   x   xxxxxxxxxxxxxxxxxxxxxxxxxxx   x   |
	 * |   x                                 x   |
	 * |   x    xxxxxxxxxxxxxxxxxxxxxxxxxx   x   |
	 * |   x                4                x   |
	 * |   x   xxxxxxxxxxxxxxxxxxxxxxxxxxx   x   |
	 * |   x                                 x   |
	 * |   x                                 x   |
	 * +---+---------------------------------+---+
	 * | 5 |                6                | 7 |
	 * +---+---------------------------------+---+
	 *
	 *  1st pixel and last pixel of the top row and bottom
	 *  row is handled separately.
	 *  All the middle elements of the top row and the bottom
	 *  row are handled separately
	 *  For middle part of the input frame, inside one for loop
	 *  1st column and the last column is handled separately.
	 */

	//if channels are multiple of 16
	if(nFilterRem == 0)
	{
		int32_t nRow = 0,nCol =0;
		//for 0th row and 0th column
		int32_t pixel=0;

		for(int32_t nFil =0; nFil<nFilters; nFil++)
		{
			acc = 0;//reset accumulator

			//for nCurrentRow = 0 & nCurrentCol = 0
			//   mask for 3x3 filter
			//    000
			//    011
			//    011
			// when the loop is running 1st column or top row of the filter kernel we have to
			// reject the calculations done and save rest of the values in accumulator
			//Hence neglecting nKernelHeight = -1 and nKernelWidth = -1
			for(int32_t nKernelHeight = 0; nKernelHeight<= 1 ; nKernelHeight++)
			{
				int32_t nCurrentRow = (nRow + nKernelHeight);
				for(int32_t nKernelWidth = 0; nKernelWidth<= 1 ; nKernelWidth++)
				{
					int32_t nCurrentCol = (nCol + nKernelWidth);

					inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//for all the input pixels
					for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
					{

						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						PDX_MULAQW_2MX16(acc,vwt,vin);
						nChannelCnt++;
					}
				}
			}
			*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
		}

		//rest of the elements of top row execpt the last element
		nRow = 0;
		for(nCol = 1; nCol < nWidth-1; nCol++)
		{

			for(int32_t nFil =0; nFil<nFilters; nFil++)
			{
				acc = 0;//reset accumulator

				//for nCurrentRow = 0 & nCurrentCol = 1 to n-2 (2nd column to last but one column)
				//   mask for 3x3 filter
				//    000
				//    111
				//    111
				// when the loop is running top row of the filter kernel we have to
				// reject the calculations done and save rest of the values in accumulator
				// hence neglecting nKernelHeight = -1
				for(int32_t nKernelHeight = 0; nKernelHeight<= 1 ; nKernelHeight++)
				{
					int32_t nCurrentRow = (nRow + nKernelHeight);
					for(int32_t nKernelWidth = -1; nKernelWidth<= 1 ; nKernelWidth++)
					{
						int32_t nCurrentCol = (nCol + nKernelWidth);

						inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
						valign ina; // define align vector
						ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

						xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
						valign wta;	// define align vector
						wta=PDX_LA_2MX8_PP (wtp);

						//for all the input pixels
						for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
						{
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							PDX_MULAQW_2MX16(acc,vwt,vin);
						}
					}
				}
				*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);

			}
		}

		//last column of top row
		nRow = 0;
		nCol=nWidth-1;
		for(int32_t nFil =0; nFil<nFilters; nFil++)
		{
			acc = 0;//reset accumulator

			//for nCurrentRow = 0 & nCurrentCol = nWidth-1 (last column)
			//   mask for 3x3 filter
			//    000
			//    110
			//    110
			// when the loop is running to 3rd column or top row of the filter kernel we have to
			// reject the calculations done and save rest of the values in accumulator
			// hence neglect nKernelHeight = -1 and nKernelWidth = 1
			for(int32_t nKernelHeight = 0; nKernelHeight<= 1 ; nKernelHeight++)
			{
				int32_t nCurrentRow = (nRow + nKernelHeight);

				for(int32_t nKernelWidth = -1; nKernelWidth<=0 ; nKernelWidth++)
				{
					int32_t nCurrentCol = nCol + nKernelWidth;

					inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//for all the input pixels
					for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
					{
						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						PDX_MULAQW_2MX16(acc,vwt,vin);
					}
				}
			}

			*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
		}

		//From Row =1 to row = nHeight-2 for all columns

		for(nRow = 1 ;nRow < nHeight-1; nRow++)
		{
			//for col  = 0
			nCol = 0;
			for(int32_t nFil =0; nFil<nFilters; nFil++)
			{
				acc = 0;//reset accumulator

				//for nCurrentRow = 0 & nCurrentCol = 0 to n-1
				// when nCurrentCol == 0
				//   mask for 3x3 filter
				//    011
				//    011
				//    011
				// when the loop is running to 1st column of the filter kernel we have to
				// reject the calculations done and save rest of the values in accumulator
				// hence reject nKernelWidth= -1
				for(int32_t nKernelHeight = -1; nKernelHeight<= 1 ; nKernelHeight++)
				{
					int32_t nCurrentRow = (nRow + nKernelHeight);

					for(int32_t nKernelWidth = 0; nKernelWidth<= 1 ; nKernelWidth++)
					{
						int32_t nCurrentCol = (nCol + nKernelWidth);

						inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
						valign ina; // define align vector
						ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

						xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
						valign wta;	// define align vector
						wta=PDX_LA_2MX8_PP (wtp);

						//for all the input pixels
						for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
						{
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							PDX_MULAQW_2MX16(acc,vwt,vin);
						}
					}
				}

				*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
			}

			for(nCol = 1;nCol < nWidth-1; nCol++)
			{
				for(int32_t nFil =0; nFil<nFilters; nFil++)
				{
					acc = 0;//reset accumulator
					//for middle part (inputs without involving border rows or columns)
					//we take all the pixels of the kernel into account for computation.
					for(int32_t nKernelHeight = -1; nKernelHeight<= 1 ; nKernelHeight++)
					{
						int32_t nCurrentRow = (nRow + nKernelHeight);
						for(int32_t nKernelWidth = -1; nKernelWidth<= 1 ; nKernelWidth++)
						{
							int32_t nCurrentCol = (nCol + nKernelWidth);

							inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
							valign ina; // define align vector
							ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

							xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
							valign wta;	// define align vector
							wta=PDX_LA_2MX8_PP (wtp);

							//for all the input pixels
							for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
							{
								PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
								PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
								vin+=vInZP;		//Add input offset

								PDX_MULAQW_2MX16(acc,vwt,vin);
							}
						}
					}
					*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
				}
			}
			nCol = nWidth-1;
			for(int32_t nFil =0; nFil<nFilters; nFil++)
			{
				acc = 0;//reset accumulator

				//for nCurrentRow = 0 & nCurrentCol = 0 to n-1
				// when nCurrentCol == nWidth-1
				//   mask for 3x3 filter
				//    110
				//    110
				//    110
				// when the loop is running to 3rd column of the filter kernel we have to
				// reject the calculations done and save rest of the values in accumulator
				// hence neglect nKernelWidth = 1
				for(int32_t nKernelHeight = -1; nKernelHeight<= 1 ; nKernelHeight++)
				{
					int32_t nCurrentRow = (nRow + nKernelHeight);
					for(int32_t nKernelWidth = -1; nKernelWidth<= 0 ; nKernelWidth++)
					{
						int32_t nCurrentCol = (nCol + nKernelWidth);

						inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
						valign ina; // define align vector
						ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

						xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
						valign wta;	// define align vector
						wta=PDX_LA_2MX8_PP (wtp);

						//for all the input pixels
						for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
						{
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							PDX_MULAQW_2MX16(acc,vwt,vin);
						}
					}
				}

				*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
			}
		}


		//nRow = nHeight -1 and nCol = 0
		nRow = nHeight -1 ;
		nCol =0;
		//for (nHeight -1)th row and 0th column
		for(int32_t nFil =0; nFil<nFilters; nFil++)
		{
			acc = 0;//reset accumulator

			//for nCurrentRow = nHeight -1 & nCurrentCol = 0
			//   mask for 3x3 filter
			//    011
			//    011
			//    000
			// when the loop is running 1st column or 3rd row of the filter kernel we have to
			// reject the calculations done and save rest of the values in accumulator
			//hence neglect nKernelHeight= 1 and nKernelWidth = -1
			for(int32_t nKernelHeight = -1; nKernelHeight<= 0 ; nKernelHeight++)
			{
				int32_t nCurrentRow = (nRow + nKernelHeight);
				for(int32_t nKernelWidth = 0; nKernelWidth<= 1 ; nKernelWidth++)
				{
					int32_t nCurrentCol = (nCol + nKernelWidth);


					inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//for all the input pixels
					for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
					{

						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						PDX_MULAQW_2MX16(acc,vwt,vin);
					}
				}
			}

			*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
		}

		//rest of the elements of last row execpt the last element
		nRow = nHeight -1;
		for(nCol = 1; nCol < nWidth-1; nCol++)
		{
			for(int32_t nFil =0; nFil<nFilters; nFil++)
			{
				acc = 0;//reset accumulator

				//for last row
				//   mask for 3x3 filter
				//    111
				//    111
				//    000
				// when the loop is running top row of the filter kernel we have to
				// reject the calculations done and save rest of the values in accumulator
				// hence neglect nKernelHeight = 1

				for(int32_t nKernelHeight = -1; nKernelHeight<= 0 ; nKernelHeight++)
				{
					int32_t nCurrentRow =(nRow + nKernelHeight);
					for(int32_t nKernelWidth = -1; nKernelWidth<= 1 ; nKernelWidth++)
					{
						int32_t nCurrentCol = nCol + nKernelWidth;

						inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
						valign ina; // define align vector
						ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

						xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
						valign wta;	// define align vector
						wta=PDX_LA_2MX8_PP (wtp);

						//for all the input pixels
						for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
						{
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							PDX_MULAQW_2MX16(acc,vwt,vin);
						}
					}
				}
			*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
			}
		}

		//last column of last row
		nRow = nHeight -1;
		nCol=nWidth-1;
		for(int32_t nFil =0; nFil<nFilters; nFil++)
		{
			acc = 0;//reset accumulator
			// for last column of last row
			//   mask for 3x3 filter
			//    110
			//    110
			//    000
			// when the loop is running to 3rd column and last row of the filter kernel we have to
			// reject the calculations done and save rest of the values in accumulator
			//hence we reject nKernelHeight = 1 and nKernelWidth = 1

			for(int32_t nKernelHeight = -1; nKernelHeight<= 0 ; nKernelHeight++)
			{
				int32_t nCurrentRow = (nRow + nKernelHeight);
				for(int32_t nKernelWidth = -1; nKernelWidth<= 0 ; nKernelWidth++)
				{
					int32_t nCurrentCol = nCol + nKernelWidth;

					inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//for all the input pixels
					for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
					{
						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						PDX_MULAQW_2MX16(acc,vwt,vin);
					}
				}
			}

			*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
		}
	}
	//to handle cases when the input channels are not multiple of 16. We handle input channels in chunks of 16 and
	//perform load and accumulate operation once for the remaining channels with appropriate mask
	else
	{
		int32_t nRow = 0,nCol =0;
		//for 0th row and 0th column

		nFilterDepth_16mul = nFilterDepth - nFilterRem;
		temp_mask = PDX_MOVB_AU32((0b1<<(nFilterRem)) - 1);
		acc_mask = PDX_CVTBB2M_B4M_L(temp_mask);  // mask to accumulate values of remaining channels

		for(int32_t nFil =0; nFil<nFilters; nFil++)
		{
			acc = 0;//reset accumulator

			//for nCurrentRow = 0 & nCurrentCol = 0
			//   mask for 3x3 filter
			//    000
			//    011
			//    011
			// when the loop is running 1st column or top row of the filter kernel we have to
			// reject the calculations done and save rest of the values in accumulator
			//Hence neglecting nKernelHeight = -1 and nKernelWidth = -1
			for(int32_t nKernelHeight = 0; nKernelHeight<= 1 ; nKernelHeight++)
			{
				int32_t nCurrentRow = (nRow + nKernelHeight);
				for(int32_t nKernelWidth = 0; nKernelWidth<= 1 ; nKernelWidth++)
				{
					int32_t nCurrentCol = (nCol + nKernelWidth);

					inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//for all the input pixels
					for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
					{

						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						PDX_MULAQW_2MX16(acc,vwt,vin);
					}

					//for remaining channels
					PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
					PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
					vin+=vInZP;		//Add input offset

					//multiply and accumulate
					//for ex if input channels are 35, inputs from 1st 32 channels are handled in above for loop.
					// for rest 3 channels the mask will mask out rest 13 lanes and consider only 1st 3 lane for multiply and accumulate.
					PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);

				}
			}

			*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
		}

		//rest of the elements of top row execpt the last element
		nRow = 0;
		for(nCol = 1; nCol < nWidth-1; nCol++)
		{

			for(int32_t nFil =0; nFil<nFilters; nFil++)
			{
				acc = 0;//reset accumulator

				//for nCurrentRow = 0 & nCurrentCol = 1 to n-2 (2nd column to last but one column)
				//   mask for 3x3 filter
				//    000
				//    111
				//    111
				// when the loop is running top row of the filter kernel we have to
				// reject the calculations done and save rest of the values in accumulator
				// hence neglecting nKernelHeight = -1
				for(int32_t nKernelHeight = 0; nKernelHeight<= 1 ; nKernelHeight++)
				{
					int32_t nCurrentRow = (nRow + nKernelHeight);
					for(int32_t nKernelWidth = -1; nKernelWidth<= 1 ; nKernelWidth++)
					{
						int32_t nCurrentCol = (nCol + nKernelWidth);

						inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
						valign ina; // define align vector
						ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

						xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
						valign wta;	// define align vector
						wta=PDX_LA_2MX8_PP (wtp);

						//for all the input pixels
						for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
						{
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							PDX_MULAQW_2MX16(acc,vwt,vin);
						}
						//for remaining channels
						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						//multiply and accumulate
						PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);
					}
				}

				*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
			}
		}

		//last column of top row
		nRow = 0;
		nCol=nWidth-1;
		for(int32_t nFil =0; nFil<nFilters; nFil++)
		{
			acc = 0;//reset accumulator

			//for nCurrentRow = 0 & nCurrentCol = nWidth -1 (last column)
			//   mask for 3x3 filter
			//    000
			//    110
			//    110
			// when the loop is running to 3rd column or top row of the filter kernel we have to
			// reject the calculations done and save rest of the values in accumulator
			//hence reject the nKernelHeight= -1 and nKernelWidth =1
			for(int32_t nKernelHeight = 0; nKernelHeight<= 1 ; nKernelHeight++)
			{
				int32_t nCurrentRow = (nRow + nKernelHeight);
				for(int32_t nKernelWidth = -1; nKernelWidth<= 0 ; nKernelWidth++)
				{
					int32_t nCurrentCol =nCol + nKernelWidth;

					inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//for all the input pixels
					for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
					{
						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						PDX_MULAQW_2MX16(acc,vwt,vin);
					}
					//for remaining channels
					PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
					PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
					vin+=vInZP;		//Add input offset

					//multiply and accumulate
					PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);
				}
			}

			*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
		}

		//From Row =1 to row = nHeight-2 for all columns
		for(nRow = 1 ;nRow < nHeight-1; nRow++)
		{
			//for col  = 0
			nCol = 0;
			for(int32_t nFil =0; nFil<nFilters; nFil++)
			{
				acc = 0;//reset accumulator
				// when nCurrentCol == 0
				//   mask for 3x3 filter
				//    011
				//    011
				//    011
				// when the loop is running to 1st column of the filter kernel we have to
				// reject the calculations done and save rest of the values in accumulator
				//hence reject nKernelWidth = -1

				for(int32_t nKernelHeight = -1; nKernelHeight<= 1 ; nKernelHeight++)
				{
					int32_t nCurrentRow = (nRow + nKernelHeight);
					for(int32_t nKernelWidth = 0; nKernelWidth<= 1 ; nKernelWidth++)
					{
						int32_t nCurrentCol = (nCol + nKernelWidth);

						inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
						valign ina; // define align vector
						ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

						xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
						valign wta;	// define align vector
						wta=PDX_LA_2MX8_PP (wtp);

						//for all the input pixels
						for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
						{
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							PDX_MULAQW_2MX16(acc,vwt,vin);
						}
						//for remaining channels
						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						//multiply and accumulate
						PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);
					}
				}

				*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
			}

			for(nCol = 1;nCol < nWidth-1; nCol++)
			{
				for(int32_t nFil =0; nFil<nFilters; nFil++)
				{
					acc = 0;//reset accumulator
					//for middle part (inputs without involving border rows or columns)
					//we take all the pixels of the kernel into account for computation.
					for(int32_t nKernelHeight = -1; nKernelHeight<= 1 ; nKernelHeight++)
					{
						int32_t nCurrentRow = (nRow + nKernelHeight);
						for(int32_t nKernelWidth = -1; nKernelWidth<= 1 ; nKernelWidth++)
						{
							int32_t nCurrentCol = (nCol + nKernelWidth);

							inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
							valign ina; // define align vector
							ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

							xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
							valign wta;	// define align vector
							wta=PDX_LA_2MX8_PP (wtp);

							//for all the input pixels
							for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
							{
								PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
								PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
								vin+=vInZP;		//Add input offset

								PDX_MULAQW_2MX16(acc,vwt,vin);
							}
							//for remaining channels
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							//multiply and accumulate
							PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);
						}
					}

					*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
				}
			}
			nCol = nWidth-1;
			for(int32_t nFil =0; nFil<nFilters; nFil++)
			{
				acc = 0;//reset accumulator

				// when nCurrentCol == nWidth-1
				//   mask for 3x3 filter
				//    110
				//    110
				//    110
				// when the loop is running to 3rd column of the filter kernel we have to
				// reject the calculations done and save rest of the values in accumulator
				//hence reject nKernelWidth = 1
				for(int32_t nKernelHeight = -1; nKernelHeight<= 1 ; nKernelHeight++)
				{
					int32_t nCurrentRow = (nRow + nKernelHeight);
					for(int32_t nKernelWidth = -1; nKernelWidth<= 0 ; nKernelWidth++)
					{
						int32_t nCurrentCol = (nCol + nKernelWidth);

						inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
						valign ina; // define align vector
						ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

						xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
						valign wta;	// define align vector
						wta=PDX_LA_2MX8_PP (wtp);

						//for all the input pixels
						for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
						{
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							PDX_MULAQW_2MX16(acc,vwt,vin);
						}
						//for remaining channels
						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						//multiply and accumulate
						PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);
					}
				}

				*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
			}
		}

		//nRow = nHeight -1 and nCol = 0
		nRow = nHeight -1 ;
		nCol =0;
		//for 0th row and 0th column
		for(int32_t nFil =0; nFil<nFilters; nFil++)
		{
			acc = 0;//reset accumulator

			//for nCurrentRow = nHeight -1 & nCurrentCol = 0
			//   mask for 3x3 filter
			//    011
			//    011
			//    000
			// when the loop is running 1st column or 3rd row of the filter kernel we have to
			// reject the calculations done and save rest of the values in accumulator
			//hence neglect nKernelHeight = 1 and nKernelWidth = -1
			for(int32_t nKernelHeight = -1; nKernelHeight<= 0 ; nKernelHeight++)
			{
				int32_t nCurrentRow = (nRow + nKernelHeight);
				for(int32_t nKernelWidth = 0; nKernelWidth<= 1 ; nKernelWidth++)
				{
					int32_t nCurrentCol = (nCol + nKernelWidth);


					inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//for all the input pixels
					for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
					{

						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						PDX_MULAQW_2MX16(acc,vwt,vin);
					}
					//for remaining channels
					PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
					PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
					vin+=vInZP;		//Add input offset

					//multiply and accumulate
					PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);
				}
			}

			*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
		}

		//rest of the elements of last row execpt the last element
		nRow = nHeight -1;
		for(nCol = 1; nCol < nWidth-1; nCol++)
		{
			for(int32_t nFil =0; nFil<nFilters; nFil++)
			{
				acc = 0;//reset accumulator

				//for nCurrentRow = 0 & nCurrentCol = 1 to n-2 (2nd column to last but one column)
				//   mask for 3x3 filter
				//    111
				//    111
				//    000
				// when the loop is running 3rd row of the filter kernel we have to
				// reject the calculations done and save rest of the values in accumulator
				//hence neglect nKernelHeight = 1
				for(int32_t nKernelHeight = -1; nKernelHeight<= 0 ; nKernelHeight++)
				{
					int32_t nCurrentRow = (nRow + nKernelHeight);
					for(int32_t nKernelWidth = -1; nKernelWidth<= 1 ; nKernelWidth++)
					{
						int32_t nCurrentCol = nCol + nKernelWidth;

						inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
						valign ina; // define align vector
						ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

						xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
						valign wta;	// define align vector
						wta=PDX_LA_2MX8_PP (wtp);

						//for all the input pixels
						for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
						{
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							PDX_MULAQW_2MX16(acc,vwt,vin);
						}
						//for remaining channels
						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						//multiply and accumulate
						PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);
					}
				}

				*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
			}
		}

		//last column of last row
		nRow = nHeight -1;
		nCol=nWidth-1;
		for(int32_t nFil =0; nFil<nFilters; nFil++)
		{
			acc = 0;//reset accumulator

			//for nCurrentRow = 0 & nCurrentCol = nWidth (last column)
			//   mask for 3x3 filter
			//    110
			//    110
			//    000
			// when the loop is running to 3rd column or last row of the filter kernel we have to
			// reject the calculations done and save rest of the values in accumulator
			//hence neglect nKernelHeight= 1 and nKernelWidth =1

			for(int32_t nKernelHeight = -1; nKernelHeight<= 0 ; nKernelHeight++)
			{
				int32_t nCurrentRow = (nRow + nKernelHeight);
				for(int32_t nKernelWidth = -1; nKernelWidth<= 0 ; nKernelWidth++)
				{
					int32_t nCurrentCol =  nCol + nKernelWidth;

					inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//for all the input pixels
					for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
					{
						PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
						PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
						vin+=vInZP;		//Add input offset

						PDX_MULAQW_2MX16(acc,vwt,vin);
					}
					//for remaining channels
					PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
					PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
					vin+=vInZP;		//Add input offset

					//multiply and accumulate
					PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);
				}
			}

			*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
		}
	}
}


//1x1 2D convolution in non-interleaved format using 16bit Eagle intrinsics
void conv2d_1x1_non_int_asm16(
		const ADI_ACTIVATION_DATATYPE *pInputBuffer,
		ADI_ACTIVATION_DATATYPE *pOutputBuffer,
		const ADI_WEIGHTS_DATATYPE *pWeightsBuffer,
		const ADI_CONV_BUFF_DATATYPE *pBias,
		ADI_CONV_BUFF_DATATYPE  nOutWidth,
		ADI_CONV_BUFF_DATATYPE  nInChannels,
		ADI_CONV_BUFF_DATATYPE  nOutChannels,
		ADI_QMULTIPLIER_DATATYPE *pQuantizedMultiplier,	//Quantized multiplier
		ADI_CONV_BUFF_DATATYPE *pQuantizedShift,		//Quantized scale
		ADI_CONV_BUFF_DATATYPE pInZeroPoint,          //Input Zero Point
		ADI_CONV_BUFF_DATATYPE pOutZeroPoint)          //Output Zero Point
{
	//TODO:Separate out width and height
	const ADI_ACTIVATION_DATATYPE *pInputBuffer_copy = pInputBuffer;
	const int nSize = (nOutWidth * nOutWidth);
	const immediate Lane = 0;
	const immediate round_mode = ROUNDING_MODE;

	int nBytesToWrite = 0;
	xb_vec2Mx16 vwt, vin;
	xb_vec2Mx40 vsum;//Accumulator

	valign ax, az;//align input and output

#ifdef USE_EXTRA_PRECISION
	xb_vecMx8* __restrict pz = (xb_vecMx8 *)pOutputBuffer;
	xb_vecMx32  vOutZP = pOutZeroPoint;
	//load constants for range
	xb_vecMx32 vmin = ACT_MIN;
	xb_vecMx32 vmax = ACT_MAX;
	xb_vec2Mx40 vmax32bit = (xb_vec2Mx40)INT_32BIT_MAX;//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx40 vmin32bit = (xb_vec2Mx40)INT_32BIT_MIN;//Replicates the lane of data specified, across all lanes of a vector register
	vbool2M greater_than32bit, lesser_than32bit;
	xb_vecMx32 first8, last8;

#else
	xb_vec2Mx8* __restrict pz = (xb_vec2Mx8 *)pOutputBuffer;
	xb_vec2Mx16  vOutZP = pOutZeroPoint;
	xb_vec2Mx16 vmin = -128;
	xb_vec2Mx16 vmax = 127;
#endif


	az = PDX_Z_ALIGN(); // initialize the alignment register to zero

	//zeropts and range are global across all channels
	xb_vec2Mx16 vInZP = pInZeroPoint;


	for(int32_t nChannel = 0; nChannel < nOutChannels; nChannel++)//per out channel
	{
		pInputBuffer = pInputBuffer_copy;//reset back to beginning of buffer for next channel

#ifdef USE_EXTRA_PRECISION
		xb_vecMx32 mult_acc_40 = pQuantizedMultiplier[nChannel];
		xb_vecMx80 outacc;

		//Load pQuantizedShift for channel
		xb_vecMx32 shift = pQuantizedShift[nChannel];
#else
		//Quant multiplier and shift per output channel, we know this will fit in int16
		uint16_t ReducedShift = (uint16_t)((pQuantizedMultiplier[nChannel] + (1 << 15)) >> 16);//Qmult is  (val) << 31, reduce this by 16 here to fit in int16
		//balance Qmult shift remaining is 15 but we include the +1 shift for PDX_MULAQW_2MX16 too here
		//this shift of 16 is accounted for during PDX_PACKQSRV_2MX40
		xb_vec2Mx16 mult_acc = ReducedShift;

		//Load pQuantizedShift for channel
		xb_vec2Mx40 shift = pQuantizedShift[nChannel];
#endif

		//add zp * wt to bias
		int32_t zp_wt_sum;
		int16_t wt_sum = 0;
		const ADI_WEIGHTS_DATATYPE *pCurrWeights = pWeightsBuffer;//back to beginning
		for(int32_t j=0; j < nInChannels; j++)
		{
			//weights are 8 bit so we have enough headroom
			int16_t nCurrWt = (int16_t)(*pCurrWeights++);
			wt_sum += nCurrWt;
		}

		//PDX_MULAQW_2MX16 will add a *2, so shift this sum also by 2
		zp_wt_sum = (pInZeroPoint) * wt_sum;//8 bit * 16 bit should fit within 32 bit
		zp_wt_sum += pBias[nChannel];//bias specific to output channel
		zp_wt_sum <<= 1;

#ifdef USE_EXTRA_PRECISION
		xb_vecMx80 add_acc_80 = (xb_vecMx32)pQuantizedMultiplier[nChannel] * (xb_vecMx32)zp_wt_sum;
#else
		int64_t vconst_add = (int32_t)ReducedShift * (int32_t)zp_wt_sum;
		//saturate to fit within 40bits
		vconst_add = MAX(vconst_add,(int64_t)0xFFFFFF8000000000);
		vconst_add = MIN(vconst_add,(int64_t)0x7FFFFFFFFF);
		xb_vec2Mx40 add_acc = vconst_add;//PDX_REP_2MX40((xb_vec2Mx40)vconst_add,Lane);
#endif

		int nBytesLeft = nSize;
		for(int32_t nCol=0; nCol < nSize; nCol += 2*PDX_M)//per pixel, do 16(2*PDX_M) at a time
		{

			xb_vec2Mx40 acc = 0;

			const ADI_WEIGHTS_DATATYPE *pCurrWeights = pWeightsBuffer;//back to beginning
			const xb_vec2Mx8 *px = (const xb_vec2Mx8 *)pInputBuffer;

			//devNote-Out data despite being in 16 bit is effectively 8 bit
			//so we have a headroom of 40 - 8+8 = 24 bit headroom
			//we can do 2^23 macs before this will overflow so we can be assured
			//that even if acc doesnt saturate here we should be fine
			for(int32_t j=0; j < nInChannels; j++)
			{
				PDX_LSR16_8_IP(vwt,pCurrWeights,1);

				ax = PDX_LA_2MX8_PP (px); // prime, NOP if a[] is aligned
				//Load 8 bit input sign extended to 16 bit
				PDX_LA16_2MX8_XP(vin, ax, px, nSize); // load aligned, extend, increment to next channel


				//multiply and accumulate to 40 bit register
				//this will effectively do acc += vwt*vin*2;
				PDX_MULAQW_2MX16(acc,vwt,vin);
			}
#ifdef USE_EXTRA_PRECISION
			//16 40 bit -> 8 80 bits

			//keep 32 bit and do 80 bit multiplication
			//copy from acc to narrow register vector

			//Saturate each lane in acc before converting to 32bit
			//sets to true if first op greater than second op
			greater_than32bit =  PDX_GT_2MX40(acc, vmax32bit);//Get bool reg for registers greater than 32bit value
			//sets to true if first op less than second op
			lesser_than32bit =  PDX_LT_2MX40(acc, vmin32bit);//Get bool reg for registers greater than 32bit value

			//if bool is TRUE, first op is selected or else second op is selected
			acc = PDX_MOV_2MX40_T(vmax32bit, acc, greater_than32bit);
			acc = PDX_MOV_2MX40_T(vmin32bit, acc, lesser_than32bit);

			//there is no saturation in this conversion, hence to avoid conversion the 32 bit overflow check.
			//16-way 40-bit wide vector signed Integer convert operation, converting to 16-way (pair) 32-bit
			PDX_CVT32D_2MX40(last8, first8, acc);

			//first8
			outacc = mult_acc_40 * first8;//8-way 32bit mac
			outacc += add_acc_80;

			//shift and round
			outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			//convert from 8 80bit -> 8 8bit

			xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_MX32(conv_out,vmax);
			conv_out = PDX_MAX_MX32(conv_out,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft -= PDX_M;
			PDX_SAV32_MX8_XP(conv_out, az, pz, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 8-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_MX8_FP(az,pz);//flush

			//last16
			if(nBytesLeft>0){
				//first8
				outacc = mult_acc_40 * last8;//8-way 32bit mac
				outacc += add_acc_80;

				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= PDX_M;
				PDX_SAV32_MX8_XP(conv_out, az, pz, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(az,pz);//flush
			}
			pInputBuffer += 2*PDX_M;//move onto next set of 16 pixels

#else
			//16 40 bit -> 16 bit and then again 40 bits mac

			//convert this to 16 bit for 16 bit multiplication with pQuantizedMultiplier
			//if this is beyond range of 16bit it will saturate
			//if we shift this by 16 here per storing, there is a chance of this becoming zero for low values

			xb_vec2Mx16 conv_out = PDX_PACKSIV_2MX40  (acc, 0);

			//multiply with 16 bit ReducedShift in 40 bit register
			acc = mult_acc * conv_out;
			acc += add_acc;//add (bias + sum(wt)*zp) * reduced shift * 2
			acc = PDX_SLS_2MX40(acc,shift);//saturating left shift, right shift if negative

			//round and shift and saturate
			conv_out = PDX_PACKQSRV_2MX40  (acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation

			//add output zero point
			conv_out += vOutZP;

			//Saturate to 8 bit range -128 to 127
			conv_out = PDX_MIN_2MX16(conv_out,vmax);
			conv_out = PDX_MAX_2MX16(conv_out,vmin);

			nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;

		    PDX_SAV16_2MX8_XP(conv_out, az, pz,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
		    //to 16-way 8-bit signed, forward post-increment addressing mode

		    PDX_SAPOS_2MX8_FP(az,pz);//flush

			nBytesLeft -= 2*PDX_M;
			pInputBuffer += 2*PDX_M;//move onto next set of 16 pixels
#endif
		}
		pWeightsBuffer += nInChannels;//interleaved, move to next channel
	}
	return;
}

//2D depthwise-convolution in interleaved format using 16bit Eagle intrinsics. Also accounts for padding using a temp buffer
void depthconv2d_8bitconv_16bitquant(
									const int8_t *pInputBuffer,					//Input buffer
									int8_t *pOutputBuffer,						//Output buffer
									const int8_t *pWeightsBuffer,				//Weight buffer
									const int32_t *pBiasBuffer,					//Bias
									int32_t nInputWidth,						//Width of input buffer
									int32_t nInputHeight,						//Height of input buffer
									int32_t nDepthMult,							//If input channels are repeated
									int32_t nInChannels,						//In Channels
									int32_t nOutChannels,						//Out Channels
									int32_t nKernelSizeWidth,					//Kernel size
									int32_t nKernelSizeHeight,					//Kernel size
									int32_t nTotalPaddingWidth,					//Total padding width
									int32_t nTotalPaddingHeight,				//Total padding height
									int32_t *pQuantizedMultiplier,				//Quantized multiplier
									int32_t *pQuantizedShift,					//Quantized scale
									int32_t pInZeroPoint,                       //Input Zero Point
									int32_t pOutZeroPoint,                      //Output Zero Point
									int32_t nStrideWidth,                       //stride
									int32_t nStrideHeight,
									int32_t nActMin,							//act min
									int32_t nActMax)                      		//act max
{
	//Peform an interleaved padding for rows and columns
	int i,nCol,nRow;
	ADI_ACTIVATION_DATATYPE *pPaddedBuffer = (ADI_ACTIVATION_DATATYPE *)pTemp;
	xb_vec4Mx8 vInZP = pInZeroPoint;

	//nDepthMult indicates whether the same set of input channels is used across all output weights
	//for eg 1 input channel with depth mult of 1 and 8 output channels uses same weights on 1 input channel
	//if depth mult is not 1, then num of input and output channels must match so diff weights on diff input channels in this code
	//we do not handle cases where depth mult is not equal to output channel eg where 2 input channels are used for 1 output channel and
	//then next 2 input channels for next output channel.

	//this variable indicates how many channel padding has to be done in the interleaved format
	//if we are using depthmult = 1 it indicates we are operating on only 1 channel at a time so padding repeat = 1
	//else we have to do padding for each of the input/output channels

	int nNextPixelInc = 0;//same channel repeated for output channels
	int nPaddingChannels = 1;
	int nChannelIncrement = 1;
	int nChannelsProcesssedInLoop = MIN(2*PDX_M,nInChannels);

	//use different input channel for each output channel
	if(nInChannels == nOutChannels) {
		nPaddingChannels = nInChannels;
		nNextPixelInc = MIN(2*PDX_M,nInChannels);
		nChannelIncrement = MIN(2*PDX_M,nInChannels);
	}

	//This set of code handles odd padding cases
	//int nTotalPadding = nTotalPaddingWidth;
	int nInitialPaddingWidth = nTotalPaddingWidth/2;
	int nFinalPaddingWidth = (nTotalPaddingWidth + 1)/2 ;
	int nInitialPaddingHeight = nTotalPaddingHeight/2;
	int nFinalPaddingHeight = (nTotalPaddingHeight + 1)/2 ;

	// Padding for top for all initial padding rows
	for (i = 0; i < (nInputWidth + nTotalPaddingWidth)*nInitialPaddingHeight*nPaddingChannels; i++) {
		*pPaddedBuffer++ = -vInZP;
	}

	//num of bytes left in the column to process
	int nBytesLeft = (nInputWidth+nTotalPaddingWidth)*nPaddingChannels;

	//pad the remaining lines as well in an interleaved way 4*PDX_M at a time
	pInputBuffer -= nInitialPaddingWidth*nPaddingChannels;
	int nBytesNotPadded = 0;
	for (nCol = 0; nCol < (nInputWidth+nTotalPaddingWidth)*nPaddingChannels; nCol += 4*PDX_M) {

		xb_vec4Mx8 * inv = (xb_vec4Mx8 *)(pInputBuffer);  // to account for padding values
		//mask the first nInitialPadding * nPaddingRepeat number of cols
		vbool4M mask0 = PDX_MOVB_AU32 (0);

		//Initial padding
		if (nCol + 4*PDX_M < nInitialPaddingWidth*nPaddingChannels)  { //initial padding > 4*PDX_M
			//all 0s
			mask0 = PDX_MOVB_AU32(0);//all zero padding
		} else if (nCol < nInitialPaddingWidth*nPaddingChannels) {  // 0 < initial padding < 4*PDX_M
			//mix of 0s and valid pixels
			int nLeft = nCol + 4*PDX_M - nInitialPaddingWidth*nPaddingChannels; //num of non-zero elements
			uint32_t nShift = (((uint64_t)1)<<(nLeft)) - 1;
			nShift <<= 4*PDX_M - nLeft;//make lsb of mask = 0
			vbool4M m = PDX_MOVB_AU32 (nShift);
			mask0 |= m;
		} else {
			//no mask, all valid pixels
			mask0 |= PDX_MOVB_AU32(0xFFFFFFFF);
		}

		//1s denote where input needs to be read from buffer

		//Final padding
		nBytesNotPadded = (nCol + 4*PDX_M) - (nInputWidth + nInitialPaddingWidth)*nPaddingChannels - nBytesNotPadded;//check if we have finished with valid pixels
		if (nBytesNotPadded > 0) {
			int EndPadding = 4*PDX_M - nBytesNotPadded;//mask sets 1 to pixels not to be padded
			uint32_t nShift = (((uint64_t)1)<<(EndPadding)) - 1;
			vbool4M m = PDX_MOVB_AU32 (nShift);
			mask0 &= m;
		} else {
			nBytesNotPadded = 0;
		}

		//use the mask to copy the elements to temp buffer with padding
		ADI_ACTIVATION_DATATYPE *pOut = pPaddedBuffer;
		xb_vec4Mx8 in0;
		int nBytesWrite = MIN(nBytesLeft,4*PDX_M);

		//repeat the operation for all rows of the image
		for (nRow = 0; nRow < nInputHeight; nRow += 1) {
			valign ina = PDX_LA_4MX8_PP (inv);
			PDX_LA_4MX8_XP (in0, ina, inv, nInputWidth*nPaddingChannels);  // inc to next row
			in0 = PDX_MOV_4MX8_T (in0, -vInZP, mask0);  // Clear the first and/or last lane, if needed. set -zp so addition will zp will make it 0

			xb_vec4Mx8 * outv = (xb_vec4Mx8 *) pOut;
			valign outa = PDX_LA_4MX8_PP (outv);
			PDX_SAV_4MX8_XP (in0, outa, outv, nBytesWrite);//doing post increment bounded to 32 here
			PDX_SAPOS_4MX8_FP (outa, outv);
			pOut += (nInputWidth + nTotalPaddingWidth)*nPaddingChannels;
		}
		pInputBuffer += nBytesWrite;  // go to next set of columns
		pPaddedBuffer += nBytesWrite; // go to next column
		nBytesLeft -= nBytesWrite;
	}

	pPaddedBuffer = (ADI_ACTIVATION_DATATYPE *)(pTemp + (nInputWidth + nTotalPaddingWidth)*
			(nInputHeight + nInitialPaddingHeight)*nPaddingChannels);
	// Padding for bottom for all final padding rows
	for (i = 0; i < (nInputWidth + nTotalPaddingWidth)*nFinalPaddingHeight*nPaddingChannels; i++) {
		*pPaddedBuffer++ = -vInZP;
	}

	//Now run the depthwise convolution on the padded buffer
	xb_vec2Mx8 *inp;

	xb_vec2Mx40 acc;
	xb_vec2Mx16 vin,vwt;
	//calculate bias*wt
	xb_vec2Mx16 vInZP16 = pInZeroPoint;
	xb_vec2Mx16 vFilterZP = 0;
	int nBytesToWrite=0;
	xb_vecMx32 first8, last8;
	xb_vec2Mx40 outacc;
	xb_vecMx80 quant_acc;
	const immediate round_mode = ROUNDING_MODE;
	xb_vecMx32 mult_l,mult_h;
	xb_vecMx32 shift_l,shift_h;
	//xb_vec2Mx40 vbias;
	xb_vecMx32 vbias_l,vbias_h;
	xb_vecMx32 conv_out;
	xb_vecMx32 vmin = nActMin;
	xb_vecMx32 vmax = nActMax;
	xb_vecMx32 vOutZP = pOutZeroPoint;
	xb_vecMx8* __restrict outp  = (xb_vecMx8 *)pOutputBuffer;
	valign outa = PDX_LA_MX8_PP (outp); // prime, NOP if a[] is aligned

	//Once padding is done, then run convolution
	//data is present in interleaved format - all channels for a pixel
	//we will do depthwise for all input channels at a time
	for(int nRow = 0;nRow + nKernelSizeHeight <= nInputHeight + nTotalPaddingHeight;nRow += nStrideHeight)
	{
		//align with row start
		ADI_ACTIVATION_DATATYPE *pIn = (ADI_ACTIVATION_DATATYPE *)(pTemp + (nInputWidth + nTotalPaddingWidth)*nRow*nInChannels);  //pointer to move down the rows
		for(int nCol = 0;nCol + nKernelSizeWidth<= nInputWidth + nTotalPaddingWidth;nCol += nStrideWidth)
		{
			//perform operation for all output channels for 1 pixel

			//align with next col start
			ADI_ACTIVATION_DATATYPE *pInputIter = pIn;

			//perform on all inputs channels for 1 pixel first

			//if nDepthMult is 1 we have to run all the filters on same pixels
			//so we can only process 1 channel at a time
			//if this is not the case we can do upto 2*PDX_M input channel at a time
			int nRemainingChannels = nOutChannels;
			//read all inputs channels for a pixel upto 2*PDX_M
			for(int nChannel = 0;nChannel < nOutChannels;nChannel+=nChannelIncrement)
			{
				const int8_t *pCurrWts = pWeightsBuffer + nChannel; //Move to next filter for each output pixel
				ADI_ACTIVATION_DATATYPE *pInputCol = pInputIter;

				nBytesLeft = MIN(nChannelsProcesssedInLoop,nRemainingChannels);

				//read in mult factors and bias for the channels
				xb_vecMx32 *vMult = (xb_vecMx32 *)(pQuantizedMultiplier + nChannel);
				valign wMulta =  PDX_LA_MX32_PP(vMult);

				xb_vecMx32 *vShift = (xb_vecMx32 *)(pQuantizedShift + nChannel);
				valign wShifta =  PDX_LA_MX32_PP(vShift);

				xb_vecMx32 *vBias = (xb_vecMx32 *)(pBiasBuffer + nChannel);
				valign wBiasa =  PDX_LA_MX32_PP(vBias);

				//read 8 way 32 bit signed
				PDX_LA_MX32_XP (mult_l, wMulta, vMult, 4*PDX_M);
				PDX_LA_MX32_XP (mult_h, wMulta, vMult, 4*PDX_M);

				PDX_LA_MX32_XP (shift_l, wShifta, vShift, 4*PDX_M);
				PDX_LA_MX32_XP (shift_h, wShifta, vShift, 4*PDX_M);

				PDX_LA_MX32_XP (vbias_l, wBiasa, vBias, 4*PDX_M);
				PDX_LA_MX32_XP (vbias_h, wBiasa, vBias, 4*PDX_M);

				vbias_l = PDX_SLS_MX32(vbias_l,1);//*2 to match with acc
				vbias_h = PDX_SLS_MX32(vbias_h,1);//*2 to match with acc

				acc = 0;
				xb_vec2Mx8 *wtp = (xb_vec2Mx8 *)(pCurrWts); //Move to next filter for each output pixel
				valign wta = PDX_LA_2MX8_PP (wtp); //wt align vector

				//do depthwise on all these channels at once
				for(int nFilterHeight = 0;nFilterHeight < nKernelSizeHeight;nFilterHeight++)
				{
					inp = (xb_vec2Mx8 *)(pInputCol);	//Reinitialise input pointer for each output pixel
					valign ina = PDX_LA_2MX8_PP (inp); // align vector

					for(int nFilterWidth = 0;nFilterWidth < nKernelSizeWidth;nFilterWidth++)
					{
						//reading 16 way 8 bit inputs and weights
						PDX_LA16_2MX8_XP (vin, ina, inp, nInChannels);//read 2*PDX_M number of channels for 1 pixel, skip to adjoining pixel
						vin += vInZP16;		//Add input offset
						ina = PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

						PDX_LA16_2MX8_XP (vwt, wta, wtp, nOutChannels);//read 2*PDX_M number of channels for 1 pixel
						vwt += vFilterZP;	//Add filter offset
						wta = PDX_LA_2MX8_PP (wtp); // prime, NOP if a[] is aligned

						//multiply and accumulate
						PDX_MULAQW_2MX16(acc,vin,vwt);//acc contains upto 2*PDX_M channel results for pixel
					}
					//set to next row
					pInputCol += (nInputWidth + nTotalPaddingWidth)*nInChannels;
					//pCurrWts += nKernelSizeWidth*nOutChannels;
				}

				//depth conv done now do scaling
				//perform scaling and addition

				//quantization compensation
				PDX_CVT32D_2MX40(last8, first8, acc);	//Converting 40bit results to 32bit to prevent loss of accuracy from packing of 40bit -> 16bit
				first8 += vbias_l;

				//first8
				quant_acc = mult_l * first8;	//Multiplying 2 32-bit vectors and storing result in 80bit vector
				//shift and round
				quant_acc = PDX_SLS_MX80(quant_acc,shift_l);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);	//pack 80bit result to 32bit with rounding and saturation.
				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);

				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft-=PDX_M;

				PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				PDX_SAPOS_MX8_FP(outa,outp);//flush

				if(nBytesLeft>0){
					//last8
					last8 += vbias_h;

					//Multiplying 2 32-bit vectors and storing result in 80bit vector
					quant_acc = mult_h * last8;
					//shift and round
					quant_acc = PDX_SLS_MX80(quant_acc,shift_h);//saturating left shift, right shift if negative
					//round and shift and saturate
					conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);	//pack 80bit result to 32bit with rounding and saturation.
					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);

					nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
					nBytesLeft-=PDX_M;
					PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					PDX_SAPOS_MX8_FP(outa,outp);//flush
				}
				nRemainingChannels -= nChannelIncrement;
				pInputIter += nNextPixelInc;//process next channel
			}
			pIn += nInChannels*nStrideWidth;//go to next pixel
		}
	}
}

//2D depthwise-convolution with stride of 1 in non-interleaved format using 16bit Eagle intrinsics. Also accounts for padding
void depthconv2d_noskip_asm_non_interleaved_padding1_8bitconv_16bitquant(
		const ADI_ACTIVATION_DATATYPE *pInputBuffer,						//Input buffer
		ADI_ACTIVATION_DATATYPE *pOutputBuffer,						//Output buffer
		const ADI_WEIGHTS_DATATYPE *pWeightsBuffer,						//Weight buffer
		const ADI_CONV_BUFF_DATATYPE *pBiasBuffer,						//Bias
		ADI_CONV_BUFF_DATATYPE nInputWidth,								//Width of input buffer
		ADI_CONV_BUFF_DATATYPE nDepthMult,							//If input channels are repeated
		ADI_CONV_BUFF_DATATYPE nInChannels,						    //In Channels
		ADI_CONV_BUFF_DATATYPE nOutChannels,						//Out Channels
		ADI_ACTIVATION_DATATYPE nKernelSize,						//Kernel size
		ADI_ACTIVATION_DATATYPE nTotalPadding,						//Total padding
		ADI_QMULTIPLIER_DATATYPE *pQuantizedMultiplier,				//Quantized multiplier
		ADI_CONV_BUFF_DATATYPE *pQuantizedShift,					//Quantized scale
		ADI_CONV_BUFF_DATATYPE pInZeroPoint,          //Input Zero Point
		ADI_CONV_BUFF_DATATYPE pOutZeroPoint)         //Output Zero Point
{
	ADI_ACTIVATION_DATATYPE nStrideLen = 1;
	ADI_ACTIVATION_DATATYPE nOutputBufferWidth = (ADI_ACTIVATION_DATATYPE)(nInputWidth - nKernelSize + nTotalPadding)/nStrideLen + 1;

	const immediate Lane = 0;
	const immediate round_mode = ROUNDING_MODE;


	xb_vec4Mx8 vInZP = pInZeroPoint;//PDX_REP_4MX8((xb_vec4Mx8)pInZeroPoint,Lane);//Replicates the lane of data specified, across all lanes of a vector register

#ifdef USE_EXTRA_PRECISION
	xb_vecMx8* __restrict outp  = (xb_vecMx8 *)pOutputBuffer;
	xb_vecMx32  vOutZP = pOutZeroPoint;
	//load constants for range
	xb_vecMx32 vmin = ACT_MIN;
	xb_vecMx32 vmax = ACT_MAX;
	xb_vec2Mx40 vmax32bit = (xb_vec2Mx40)INT_32BIT_MAX;//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx40 vmin32bit = (xb_vec2Mx40)INT_32BIT_MIN;//Replicates the lane of data specified, across all lanes of a vector register
	vbool2M greater_than32bit, lesser_than32bit;
	xb_vecMx32 first8, last8;
	valign outa = PDX_LA_MX8_PP (outp); // prime, NOP if a[] is aligned
#else
	xb_vec2Mx8* __restrict outp = (xb_vec2Mx8 *) pOutputBuffer;//outbuffer

	xb_vec2Mx16 vOutZP = pOutZeroPoint;//PDX_REP_2MX40((xb_vec2Mx16)pOutZeroPoint,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	//load constants for range
	xb_vec2Mx16 vmin = -128;//PDX_REP_2MX16((xb_vec2Mx16)-128,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx16 vmax = 127;//PDX_REP_2MX16((xb_vec2Mx16)127,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx16 conv_out, first16, last16;
	xb_vec4Mx20 vsum;
	xb_vec4Mx20 vmax16bit = (xb_vec4Mx20)0x07FFF;//PDX_REP_4MX20((xb_vec4Mx20)0x07FFF,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec4Mx20 vmin16bit = (xb_vec4Mx20)0xF8000;//PDX_REP_4MX20((xb_vec4Mx20)0xF8000,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	vbool4M greater_than16bit, lesser_than16bit;
	valign outa = PDX_Z_ALIGN(); // initialize the alignment register vaWrite to zero
#endif


	int col = 0;
	xb_vec4Mx20 acc,tempacc1;
	xb_vec2Mx40 outacc;
	int nBytesToWrite;
	int nRemCols;
	xb_vec4Mx20 zeros = 0;

	for(int nChannels = 0;nChannels < nOutChannels;nChannels++)
	{
#ifdef USE_EXTRA_PRECISION
		xb_vecMx32 mult_acc_40 = pQuantizedMultiplier[nChannels];
		xb_vecMx80 outacc;

		//Load pQuantizedShift for channel
		xb_vecMx32 shift = pQuantizedShift[nChannels];
#else
		uint16_t ReducedShift = (uint16_t)((pQuantizedMultiplier[nChannels] + (1 << 15)) >> 16);//Qmult is  (val) << 31, reduce this by 16 here to fit in int16
		//balance Qmult shift remaining is 15 but we include the +1 shift for PDX_MULAQW_4MX8 too here
		//this shift of 16 is accounted for during PDX_PACKQSRV_2MX40
		xb_vec2Mx16 mult_acc = PDX_REP_2MX16(ReducedShift,Lane);			//Replicates the lane of data specified, across all lanes of a vector register

		const immediate nTotalShift = pQuantizedShift[nChannels];			//Load shift factor for quantization per channel
		xb_vec2Mx40 shift = PDX_REP_2MX40((xb_vec2Mx40)nTotalShift,Lane);	//Replicates the lane of data specified, across all lanes of a vector register

		//bias specific to output channel
		xb_vec2Mx40 vbias = PDX_REP_2MX40((xb_vec2Mx40)((int64_t)((int64_t)pBiasBuffer[nChannels]<<2)*(ReducedShift)),Lane);
		xb_vec2Mx40 outacc;
#endif

		//saturate bias within 20 bits
		//load bias*2 in nvec to match with vwt*vin*2
		//add zp * wt to bias
		int32_t zp_wt_sum;
		int32_t zp_wt_sum_first_pixel;
		int32_t zp_wt_sum_last_pixel;

		int32_t zp_wt_sum_first_row;
		int32_t zp_wt_sum_first_row_first_pixel;
		int32_t zp_wt_sum_first_row_last_pixel;

		int32_t zp_wt_sum_last_row;
		int32_t zp_wt_sum_last_row_first_pixel;
		int32_t zp_wt_sum_last_row_last_pixel;

		int16_t wt_sum = 0;
		int16_t wt_sum_first_pixel = 0;
		int16_t wt_sum_last_pixel = 0;
		int16_t wt_sum_first_row_first_pixel = 0;
		int16_t wt_sum_first_row = 0;
		int16_t wt_sum_first_row_last_pixel = 0;
		int16_t wt_sum_last_row_first_pixel = 0;
		int16_t wt_sum_last_row = 0;
		int16_t wt_sum_last_row_last_pixel = 0;

		//initialize weights for this channel
		//loading each of the (nKernelSize x nKernelSize) weights into it's own vector
		//each kernel weight is replicated in all the lanes to be multiplied in parallel
		int8_t nCurrWt;
		int8_t *filter_buff =  (int8_t *)(pWeightsBuffer + nChannels);

		nCurrWt = (int8_t)(*filter_buff);
		filter_buff += nInChannels;
		wt_sum += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		wt_sum_last_row += nCurrWt;
		wt_sum_last_row_last_pixel += nCurrWt;
		xb_vec4Mx8 w00 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		nCurrWt = (int8_t)(*filter_buff);
		filter_buff += nInChannels;
		wt_sum += nCurrWt;
		wt_sum_first_pixel += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		wt_sum_last_row_first_pixel += nCurrWt;
		wt_sum_last_row += nCurrWt;
		wt_sum_last_row_last_pixel += nCurrWt;
		xb_vec4Mx8 w01 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		nCurrWt = (int8_t)(*filter_buff);
		filter_buff += nInChannels;
		wt_sum += nCurrWt;
		wt_sum_first_pixel += nCurrWt;
		wt_sum_last_row_first_pixel += nCurrWt;
		wt_sum_last_row += nCurrWt;
		xb_vec4Mx8 w02 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		//handle first col padding using weights w10,w20
		nCurrWt = (int8_t)(*filter_buff);
		filter_buff += nInChannels;
		wt_sum += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		wt_sum_first_row += nCurrWt;
		wt_sum_first_row_last_pixel += nCurrWt;
		wt_sum_last_row += nCurrWt;
		wt_sum_last_row_last_pixel += nCurrWt;
		xb_vec4Mx8 w10 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		nCurrWt = (int8_t)(*filter_buff);
		filter_buff += nInChannels;
		wt_sum += nCurrWt;
		wt_sum_first_pixel += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		wt_sum_first_row_first_pixel += nCurrWt;
		wt_sum_first_row += nCurrWt;
		wt_sum_first_row_last_pixel += nCurrWt;
		wt_sum_last_row_first_pixel += nCurrWt;
		wt_sum_last_row += nCurrWt;
		wt_sum_last_row_last_pixel += nCurrWt;
		xb_vec4Mx8 w11 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		nCurrWt = (int8_t)(*filter_buff);
		filter_buff += nInChannels;
		wt_sum += nCurrWt;
		wt_sum_first_pixel += nCurrWt;
		wt_sum_first_row_first_pixel += nCurrWt;
		wt_sum_first_row += nCurrWt;
		wt_sum_last_row_first_pixel += nCurrWt;
		wt_sum_last_row += nCurrWt;
		xb_vec4Mx8 w12 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		nCurrWt = (int8_t)(*filter_buff);
		filter_buff += nInChannels;
		wt_sum += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		wt_sum_first_row += nCurrWt;
		wt_sum_first_row_last_pixel += nCurrWt;
		xb_vec4Mx8 w20 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		nCurrWt = (int8_t)(*filter_buff);
		filter_buff += nInChannels;
		wt_sum += nCurrWt;
		wt_sum_first_pixel += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		wt_sum_first_row_first_pixel += nCurrWt;
		wt_sum_first_row += nCurrWt;
		wt_sum_first_row_last_pixel += nCurrWt;
		xb_vec4Mx8 w21 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		nCurrWt = (int8_t)(*filter_buff);
		filter_buff += nInChannels;
		wt_sum += nCurrWt;
		wt_sum_first_pixel += nCurrWt;
		wt_sum_first_row_first_pixel += nCurrWt;
		wt_sum_first_row += nCurrWt;
		xb_vec4Mx8 w22 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector


		//PDX_MULAQW_2MX16 will add a *2, so shift this sum also by 2
		zp_wt_sum = (pInZeroPoint) * wt_sum;//8 bit * 16 bit should fit within 32 bit

		zp_wt_sum_first_pixel = (pInZeroPoint) * wt_sum_first_pixel;//8 bit * 16 bit should fit within 32 bit
		zp_wt_sum_last_pixel = (pInZeroPoint) * wt_sum_last_pixel;//8 bit * 16 bit should fit within 32 bit

		zp_wt_sum_first_row = (pInZeroPoint) * wt_sum_first_row;//8 bit * 16 bit should fit within 32 bit
		zp_wt_sum_first_row_first_pixel = (pInZeroPoint) * wt_sum_first_row_first_pixel;//8 bit * 16 bit should fit within 32 bit
		zp_wt_sum_first_row_last_pixel = (pInZeroPoint) * wt_sum_first_row_last_pixel;//8 bit * 16 bit should fit within 32 bit

		zp_wt_sum_last_row = (pInZeroPoint) * wt_sum_last_row;//8 bit * 16 bit should fit within 32 bit
		zp_wt_sum_last_row_first_pixel = (pInZeroPoint) * wt_sum_last_row_first_pixel;//8 bit * 16 bit should fit within 32 bit
		zp_wt_sum_last_row_last_pixel = (pInZeroPoint) * wt_sum_last_row_last_pixel;//8 bit * 16 bit should fit within 32 bit

#ifdef USE_EXTRA_PRECISION
		zp_wt_sum += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum <<= 1;

		zp_wt_sum_first_pixel += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_first_pixel <<= 1;
		zp_wt_sum_last_pixel += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_last_pixel <<= 1;

		zp_wt_sum_first_row += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_first_row <<= 1;

		zp_wt_sum_first_row_first_pixel += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_first_row_first_pixel <<= 1;

		zp_wt_sum_first_row_last_pixel += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_first_row_last_pixel <<= 1;

		zp_wt_sum_last_row += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_last_row <<= 1;

		zp_wt_sum_last_row_first_pixel += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_last_row_first_pixel <<= 1;

		zp_wt_sum_last_row_last_pixel += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_last_row_last_pixel <<= 1;

		xb_vecMx80 add_acc_80 = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum;
		xb_vecMx80 add_acc_80_first_pixel = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_first_pixel;
		xb_vecMx80 add_acc_80_last_pixel = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_last_pixel;

		xb_vecMx80 add_acc_80_first_row = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_first_row;
		xb_vecMx80 add_acc_80_first_row_first_pixel = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_first_row_first_pixel;
		xb_vecMx80 add_acc_80_first_row_last_pixel = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_first_row_last_pixel;

		xb_vecMx80 add_acc_80_last_row = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_last_row;
		xb_vecMx80 add_acc_80_last_row_first_pixel = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_last_row_first_pixel;
		xb_vecMx80 add_acc_80_last_row_last_pixel = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_last_row_last_pixel;
#else
		vsum = max((xb_vec4Mx20)(zp_wt_sum << 1), (xb_vec4Mx20)0xFFFFF);
		vsum = min(vsum, (xb_vec4Mx20)0x7FFFF);

		int64_t vconst_add = (int32_t)ReducedShift * (int32_t)pBiasBuffer[nChannels];
		vconst_add <<= 1;
		//saturate to fit within 40bits
		vconst_add = MAX(vconst_add,(int64_t)0xFFFFFF8000000000);
		vconst_add = MIN(vconst_add,(int64_t)0x7FFFFFFFFF);
		xb_vec2Mx40 add_acc = (int32_t)vconst_add;
#endif

		//create first row mask
		vbool4M mask0 = PDX_MOVB_AU32 (0xFFFFFFFE);					//setting mask to account for initial padding
		vbool4M nomask = PDX_MOVB_AU32 (0xFFFFFFFF);					//setting mask to account for initial padding

		//top row with first row padded, for 3x3 1 first col and 1 last col

		xb_vec4Mx8 * inp = (xb_vec4Mx8 *) (pInputBuffer - 1);  //pointer to move down the rows, -1 to simulate padding
		valign ina = PDX_LA_4MX8_PP (inp);

		xb_vec4Mx8 in00,in01,in02;//load input and increment input pointer to next location,w01,w02 not used
		xb_vec4Mx8 in10,in11,in12;
		xb_vec4Mx8 in20,in21,in22;

		xb_vec4Mx8 temp1, temp2;

		int nBytesLeft = nOutputBufferWidth;
		//First row we only process the bottom 2 rows assuming top row is padded

		for(int nCol = 0;nCol < nInputWidth;nCol += 4*PDX_M)
		{
			nRemCols = MIN(nBytesLeft - 1,4*PDX_M);
			uint32_t nShift = (((uint64_t)1)<<(nRemCols)) - 1;//If we have 16 elements remaining padding is needed on the last 1 hence nRemCols - 1
			vbool4M end_padding_mask = PDX_MOVB_AU32 (nShift);

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP(in10, ina, inp, 1); //load input and increment input pointer to next location
			//in10 += vInZP;						 //add input zero point to each input vector

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP (in11, ina, inp, 1); //load input and increment input pointer to next location
			//in11 += vInZP;						 //add input zero point to each input vector

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP (in12, ina, inp, nInputWidth - 2);  //load input and increment input pointer to next row (here)
			//in12 += vInZP;						 //add input zero point to each input vector

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP (in20, ina, inp, 1); //load input and increment input pointer to next location
			//in20 += vInZP;						 //add input zero point to each input vector

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP (in21, ina, inp, 1); //load input and increment input pointer to next location
			//in21 += vInZP;						 //add input zero point to each input vector

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP (in22, ina, inp, -(nInputWidth + 2) + 4*PDX_M);  //load input and increment input pointer back to beginning
			//in22 += vInZP;						 //add input zero point to each input vector

			//multiply and accumulate
			tempacc1 = w10 * in10;					//Multiply  - 16way 16bit
			tempacc1 <<= 1;
			PDX_MULAQW_4MX8(tempacc1,w20,in20);					//Multiply and Accumulate - 16way 16bit
			//if bool is TRUE, first op is selected or else second op is selected
			acc = PDX_MOV_4MX20_T(tempacc1,zeros,mask0);//simulate padding

			//acc += vsum;//Load bias into acc
			PDX_MULAQW_4MX8(acc,w11,in11);					//Multiply and Accumulate - 16way 16bit
			PDX_MULAQW_4MX8(acc,w21,in21);					//Multiply and Accumulate - 16way 16bit

			PDX_MULAQW_4MX8_T(acc,w12,in12,end_padding_mask);					//Multiply and Accumulate - 16way 16bit
			PDX_MULAQW_4MX8_T(acc,w22,in22,end_padding_mask);					//Multiply and Accumulate - 16way 16bit

#ifdef USE_EXTRA_PRECISION
			//create mask based on elements left
			//convert 32 8 bit to 32 32bit data
			//map higher bits in H to 3 and 4
			//map lower bits in L to 1 and 2
			vbool2M end_padding_mask34 = PDX_CVTBB2M_B_H(end_padding_mask);
			vboolM end_padding_mask4 = PDX_CVTBBM_B2M_H(end_padding_mask34);
			vboolM end_padding_mask3 = PDX_CVTBBM_B2M_L(end_padding_mask34);
			vbool2M end_padding_mask12 = PDX_CVTBB2M_B_L(end_padding_mask);
			vboolM end_padding_mask2 = PDX_CVTBBM_B2M_H(end_padding_mask12);
			vboolM end_padding_mask1 = PDX_CVTBBM_B2M_L(end_padding_mask12);

			//start padding mask
			vbool2M start_padding_mask34 = PDX_CVTBB2M_B_H(mask0);
			vboolM start_padding_mask4 = PDX_CVTBBM_B2M_H(start_padding_mask34);
			vboolM start_padding_mask3 = PDX_CVTBBM_B2M_L(start_padding_mask34);
			vbool2M start_padding_mask12 = PDX_CVTBB2M_B_L(mask0);
			vboolM start_padding_mask2 = PDX_CVTBBM_B2M_H(start_padding_mask12);
			vboolM start_padding_mask1 = PDX_CVTBBM_B2M_L(start_padding_mask12);


			//32 20 bit -> 8 80 bits
			//convert 32 20 bit acc to 8 32 bit acc.
			//convert L half of acc to 2 32 bit acc
			PDX_CVT32D_4MX20_L(last8,first8,acc);

			//keep 32 bit and do 80 bit multiplication

			//first8
			outacc = mult_acc_40 * first8;//8-way 32bit mac

			xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_first_row,add_acc_80_first_row_first_pixel,start_padding_mask1);
			acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_first_row_last_pixel,end_padding_mask1);
			outacc += acc_proc;


			//shift and round
			outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			//convert from 8 80bit -> 8 8bit

			xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_MX32(conv_out,vmax);
			conv_out = PDX_MAX_MX32(conv_out,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft -= PDX_M;
			PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 8-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_MX8_FP(outa,outp);//flush

			//last8
			if(nBytesLeft>0){
				//first8
				outacc = mult_acc_40 * last8;//8-way 32bit mac

				xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_first_row,add_acc_80_first_row_first_pixel,start_padding_mask2);
				acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_first_row_last_pixel,end_padding_mask2);
				outacc += acc_proc;


				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= PDX_M;
				PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush
			}


			if(nBytesLeft>0){
				PDX_CVT32D_4MX20_H(last8,first8,acc);

				//keep 32 bit and do 80 bit multiplication

				//first8
				outacc = mult_acc_40 * first8;//8-way 32bit mac

				xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_first_row,add_acc_80_first_row_first_pixel,start_padding_mask3);
				acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_first_row_last_pixel,end_padding_mask3);
				outacc += acc_proc;

				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= nBytesToWrite;
				PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush

				//last8
				if(nBytesLeft>0){
					//first8
					outacc = mult_acc_40 * last8;//8-way 32bit mac

					//where start padding mask = 0, use add_acc_80_first_row_first_pixel
					xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_first_row,add_acc_80_first_row_first_pixel,start_padding_mask4);//simulate padding
					//where end padding mask = 0 use add_acc_80_first_row_last_pixel
					acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_first_row_last_pixel,end_padding_mask4);//simulate padding
					outacc += acc_proc;

					//shift and round
					outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
					//round and shift and saturate
					//convert from 8 80bit -> 8 8bit

					xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
					nBytesLeft -= nBytesToWrite;
					PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					//to 8-way 8-bit signed, forward post-increment addressing mode
					PDX_SAPOS_MX8_FP(outa,outp);//flush
				}
			}
#else
			//account for 1st row padding
			//Quantization Compensation
			//Saturate each lane in acc before converting to 16bit
			//sets to true if first op greater than second op
			greater_than16bit =  PDX_GT_4MX20(acc, vmax16bit);//Get bool reg for registers greater than 16bit value
			//sets to true if first op less than second op
			lesser_than16bit =  PDX_LT_4MX20(acc, vmin16bit);//Get bool reg for registers greater than 16bit value
			//if bool is TRUE, first op is selected or else second op is selected
			acc = PDX_MOV_4MX20_T(vmax16bit, acc,greater_than16bit);
			acc = PDX_MOV_4MX20_T(vmin16bit, acc, lesser_than16bit);
			//Separate 32way 20bit data into 2 16way 16bit registers and perform quantization comp separately
			PDX_CVT16D_4MX20(last16, first16,acc);

			//first16
			outacc = mult_acc * first16;//PDX_MULMNW_2MX16(mult_acc,first16,0,0);
			outacc += add_acc;
			//shift and round
			outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_2MX16(conv_out,vmax);
			conv_out = PDX_MAX_2MX16(conv_out,vmin);
			nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
			PDX_SAV16_2MX8_XP(conv_out, outa, outp,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush
			nBytesLeft -= nBytesToWrite;

			//last16
			outacc = mult_acc * last16;//PDX_MULMNW_2MX16(mult_acc,last16,0,0);
			outacc += add_acc;
			//shift and round
			outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_2MX16(conv_out,vmax);
			conv_out = PDX_MAX_2MX16(conv_out,vmin);
			nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
			PDX_SAV16_2MX8_XP(conv_out, outa, outp,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush
			nBytesLeft -= nBytesToWrite;
#endif
			mask0 = nomask;
		}

		for(int nRow = 0;nRow < nInputWidth - 2;nRow++)
		{
			inp = (xb_vec4Mx8 *) (pInputBuffer + nRow*nInputWidth - 1);  //pointer to move down the rows, -1 for padding
			//Processing for remaining rows
			nBytesLeft = nOutputBufferWidth;
			mask0 = PDX_MOVB_AU32 (0xFFFFFFFE);					//setting mask to account for initial padding
			for(int nCol = 0;nCol < nInputWidth;nCol += 4*PDX_M)
			{
				nRemCols = MIN(nBytesLeft - 1,4*PDX_M);
				uint32_t nShift = (((uint64_t)1)<<(nRemCols)) - 1;//if we have 16 el remaining, 15 dont need padding
				vbool4M end_padding_mask = PDX_MOVB_AU32 (nShift);

				ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
				PDX_LA_4MX8_XP(in00, ina, inp, 1); //load input and increment input pointer to next location
				//in00 += vInZP;						 //add input zero point to each input vector

				ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
				PDX_LA_4MX8_XP (in01, ina, inp, 1); //load input and increment input pointer to next location
				//in01 += vInZP;						 //add input zero point to each input vector

				ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
				PDX_LA_4MX8_XP (in02, ina, inp, nInputWidth - 2);  //load input and increment input pointer to next row (here)
				//in02 += vInZP;						 //add input zero point to each input vector

				ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
				PDX_LA_4MX8_XP(in10, ina, inp, 1); //load input and increment input pointer to next location
				//in10 += vInZP;						 //add input zero point to each input vector

				ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
				PDX_LA_4MX8_XP (in11, ina, inp, 1); //load input and increment input pointer to next location
				//in11 += vInZP;						 //add input zero point to each input vector

				ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
				PDX_LA_4MX8_XP (in12, ina, inp, nInputWidth - 2);  //load input and increment input pointer to next row (here)
				//in12 += vInZP;						 //add input zero point to each input vector

				ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
				PDX_LA_4MX8_XP (in20, ina, inp, 1); //load input and increment input pointer to next location
				//in20 += vInZP;						 //add input zero point to each input vector

				ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
				PDX_LA_4MX8_XP (in21, ina, inp, 1); //load input and increment input pointer to next location
				//in21 += vInZP;						 //add input zero point to each input vector

				ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
				PDX_LA_4MX8_XP (in22, ina, inp, -2*nInputWidth - 2 + 4*PDX_M);  //load input and increment input pointer back to beginning
				//in22 += vInZP;						 //add input zero point to each input vector

				//multiply and accumulate
				tempacc1 = w00 * in00;					//Multiply  - 16way 16bit
				tempacc1 <<= 1;
				PDX_MULAQW_4MX8(tempacc1,w10,in10);					//Multiply and Accumulate - 16way 16bit
				PDX_MULAQW_4MX8(tempacc1,w20,in20);					//Multiply and Accumulate - 16way 16bit

				//if bool is TRUE, first op is selected or else second op is selected
				acc = PDX_MOV_4MX20_T(tempacc1,zeros,mask0);//simulate padding

				//acc = acc + vsum;
				PDX_MULAQW_4MX8(acc,w01,in01);					//Multiply and Accumulate - 16way 16bit
				PDX_MULAQW_4MX8(acc,w11,in11);					//Multiply and Accumulate - 16way 16bit
				PDX_MULAQW_4MX8(acc,w21,in21);					//Multiply and Accumulate - 16way 16bit

				PDX_MULAQW_4MX8_T(acc,w02,in02,end_padding_mask);					//Multiply and Accumulate - 16way 16bit
				PDX_MULAQW_4MX8_T(acc,w12,in12,end_padding_mask);					//Multiply and Accumulate - 16way 16bit
				PDX_MULAQW_4MX8_T(acc,w22,in22,end_padding_mask);					//Multiply and Accumulate - 16way 16bit
#ifdef USE_EXTRA_PRECISION
				//32 20 bit -> 8 80 bits
				//create mask based on elements left
				//convert 32 8 bit to 32 32bit data
				//map higher bits in H to 3 and 4
				//map lower bits in L to 1 and 2
				vbool2M end_padding_mask34 = PDX_CVTBB2M_B_H(end_padding_mask);
				vboolM end_padding_mask4 = PDX_CVTBBM_B2M_H(end_padding_mask34);
				vboolM end_padding_mask3 = PDX_CVTBBM_B2M_L(end_padding_mask34);
				vbool2M end_padding_mask12 = PDX_CVTBB2M_B_L(end_padding_mask);
				vboolM end_padding_mask2 = PDX_CVTBBM_B2M_H(end_padding_mask12);
				vboolM end_padding_mask1 = PDX_CVTBBM_B2M_L(end_padding_mask12);

				//start padding mask
				vbool2M start_padding_mask34 = PDX_CVTBB2M_B_H(mask0);
				vboolM start_padding_mask4 = PDX_CVTBBM_B2M_H(start_padding_mask34);
				vboolM start_padding_mask3 = PDX_CVTBBM_B2M_L(start_padding_mask34);
				vbool2M start_padding_mask12 = PDX_CVTBB2M_B_L(mask0);
				vboolM start_padding_mask2 = PDX_CVTBBM_B2M_H(start_padding_mask12);
				vboolM start_padding_mask1 = PDX_CVTBBM_B2M_L(start_padding_mask12);

				PDX_CVT32D_4MX20_L(last8,first8,acc);

				//keep 32 bit and do 80 bit multiplication

				//first8
				outacc = mult_acc_40 * first8;//8-way 32bit mac

				xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80,add_acc_80_first_pixel,start_padding_mask1);
				acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_last_pixel,end_padding_mask1);
				outacc += acc_proc;

				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= nBytesToWrite;
				PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush

				//last8
				if(nBytesLeft>0){
					//first8
					outacc = mult_acc_40 * last8;//8-way 32bit mac
					xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80,add_acc_80_first_pixel,start_padding_mask2);
					acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_last_pixel,end_padding_mask2);
					outacc += acc_proc;

					//shift and round
					outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
					//round and shift and saturate
					//convert from 8 80bit -> 8 8bit

					xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
					nBytesLeft -= nBytesToWrite;
					PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					//to 8-way 8-bit signed, forward post-increment addressing mode
					PDX_SAPOS_MX8_FP(outa,outp);//flush
				}


				if(nBytesLeft>0){
					PDX_CVT32D_4MX20_H(last8,first8,acc);

					//keep 32 bit and do 80 bit multiplication

					//first8
					outacc = mult_acc_40 * first8;//8-way 32bit mac

					xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80,add_acc_80_first_pixel,start_padding_mask3);
					acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_last_pixel,end_padding_mask3);
					outacc += acc_proc;


					//shift and round
					outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
					//round and shift and saturate
					//convert from 8 80bit -> 8 8bit

					xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
					nBytesLeft -= nBytesToWrite;
					PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					//to 8-way 8-bit signed, forward post-increment addressing mode
					PDX_SAPOS_MX8_FP(outa,outp);//flush

					//last8
					if(nBytesLeft>0){
						//first8

						xb_vecMx80 outacc1;
						outacc1 = mult_acc_40 * last8;//8-way 32bit mac

						xb_vecMx80 acc_proc_in = PDX_MOV_MX80_T(add_acc_80,add_acc_80_first_pixel,start_padding_mask4);
						acc_proc_in = PDX_MOV_MX80_T(acc_proc_in,add_acc_80_last_pixel,end_padding_mask4);
						outacc1 += acc_proc_in;

						//shift and round
						outacc1 = PDX_SLS_MX80(outacc1,shift);//saturating left shift, right shift if negative
						//round and shift and saturate
						//convert from 8 80bit -> 8 8bit

						xb_vecMx32 conv_out1 = PDX_PACKQSRV_MX80(outacc1, round_mode);//shift by 32 bit 80->32

						//add output zero point
						conv_out1 += vOutZP;
						//Saturate to 8 bit range output_activation_min to 127
						conv_out1 = PDX_MIN_MX32(conv_out1,vmax);
						conv_out1 = PDX_MAX_MX32(conv_out1,vmin);
						nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
						nBytesLeft -= nBytesToWrite;
						PDX_SAV32_MX8_XP(conv_out1, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
						//to 8-way 8-bit signed, forward post-increment addressing mode
						PDX_SAPOS_MX8_FP(outa,outp);//flush
					}
				}
#else
				//account for 1st row padding
				//Quantization Compensation
				//Saturate each lane in acc before converting to 16bit
				//sets to true if first op greater than second op
				greater_than16bit =  PDX_GT_4MX20(acc, vmax16bit);//Get bool reg for registers greater than 16bit value
				//sets to true if first op less than second op
				lesser_than16bit =  PDX_LT_4MX20(acc, vmin16bit);//Get bool reg for registers greater than 16bit value
				//if bool is TRUE, first op is selected or else second op is selected
				acc = PDX_MOV_4MX20_T(vmax16bit, acc,greater_than16bit);
				acc = PDX_MOV_4MX20_T(vmin16bit, acc, lesser_than16bit);
				//Separate 32way 20bit data into 2 16way 16bit registers and perform quantization comp separately
				PDX_CVT16D_4MX20(last16, first16, acc);

				//first16
				outacc = mult_acc * first16;//PDX_MULMNW_2MX16(mult_acc,first16,0,0);
				outacc += add_acc;
				//shift and round
				outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_2MX16(conv_out,vmax);
				conv_out = PDX_MAX_2MX16(conv_out,vmin);
				nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
				PDX_SAV16_2MX8_XP(conv_out, outa, outp,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush
				nBytesLeft -= nBytesToWrite;

				//last16
				outacc = mult_acc * last16;//PDX_MULMNW_2MX16(mult_acc,last16,0,0);
				outacc += add_acc;
				//shift and round
				outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_2MX16(conv_out,vmax);
				conv_out = PDX_MAX_2MX16(conv_out,vmin);
				nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
				PDX_SAV16_2MX8_XP(conv_out, outa, outp,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush
				nBytesLeft -= nBytesToWrite;
#endif
				mask0 = nomask;
			}
		}

		//Process for last row
		inp = (xb_vec4Mx8 *) (pInputBuffer + (nInputWidth - 2)*nInputWidth - 1);  //pointer to move down the rows -1 for padding
		nBytesLeft = nOutputBufferWidth;
		mask0 = PDX_MOVB_AU32 (0xFFFFFFFE);					//setting mask to account for initial padding
		//First row we only process the top 2 rows assuming bottom row is padded
		for(int nCol = 0;nCol < nInputWidth;nCol += 4*PDX_M)
		{
			nRemCols = MIN(nBytesLeft - 1,4*PDX_M);
			uint32_t nShift = (((uint64_t)1)<<(nRemCols)) - 1;//only last element to be padded
			vbool4M end_padding_mask = PDX_MOVB_AU32 (nShift);

			valign ina = PDX_LA_4MX8_PP (inp);
			PDX_LA_4MX8_XP(in00, ina, inp, 1); //load input and increment input pointer to next location
			//in00 += vInZP;						 //add input zero point to each input vector

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP (in01, ina, inp, 1); //load input and increment input pointer to next location
			//in01 += vInZP;						 //add input zero point to each input vector

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP (in02, ina, inp, nInputWidth - 2);  //load input and increment input pointer to next row (here)
			//in02 += vInZP;						 //add input zero point to each input vector

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP (in10, ina, inp, 1); //load input and increment input pointer to next location
			//in10 += vInZP;						 //add input zero point to each input vector

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP (in11, ina, inp, 1); //load input and increment input pointer to next location
			//in11 += vInZP;						 //add input zero point to each input vector

			ina = PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
			PDX_LA_4MX8_XP (in12, ina, inp, -(nInputWidth + 2) + 4*PDX_M);  //load input and increment input pointer back to beginning
			//in12 += vInZP;						 //add input zero point to each input vector

			//multiply and accumulate
			tempacc1 = w00 * in00;
			tempacc1 <<= 1;
			PDX_MULAQW_4MX8(tempacc1,w10,in10);					//Multiply and Accumulate - 16way 16bit

			//if bool is TRUE, first op is selected or else second op is selected
			acc = PDX_MOV_4MX20_T(tempacc1,zeros,mask0);//simulate padding

			//acc += vsum;                                    //load bias				//Load bias into acc
			PDX_MULAQW_4MX8(acc,w01,in01);					//Multiply and Accumulate - 16way 16bit
			PDX_MULAQW_4MX8(acc,w11,in11);					//Multiply and Accumulate - 16way 16bit

			PDX_MULAQW_4MX8_T(acc,w02,in02,end_padding_mask);					//Multiply and Accumulate - 16way 16bit
			PDX_MULAQW_4MX8_T(acc,w12,in12,end_padding_mask);					//Multiply and Accumulate - 16way 16bit
#ifdef USE_EXTRA_PRECISION
			//32 20 bit -> 8 80 bits
			//create mask based on elements left
			//convert 32 8 bit to 32 32bit data
			//map higher bits in H to 3 and 4
			//map lower bits in L to 1 and 2
			vbool2M end_padding_mask34 = PDX_CVTBB2M_B_H(end_padding_mask);
			vboolM end_padding_mask4 = PDX_CVTBBM_B2M_H(end_padding_mask34);
			vboolM end_padding_mask3 = PDX_CVTBBM_B2M_L(end_padding_mask34);
			vbool2M end_padding_mask12 = PDX_CVTBB2M_B_L(end_padding_mask);
			vboolM end_padding_mask2 = PDX_CVTBBM_B2M_H(end_padding_mask12);
			vboolM end_padding_mask1 = PDX_CVTBBM_B2M_L(end_padding_mask12);

			//start padding mask
			vbool2M start_padding_mask34 = PDX_CVTBB2M_B_H(mask0);
			vboolM start_padding_mask4 = PDX_CVTBBM_B2M_H(start_padding_mask34);
			vboolM start_padding_mask3 = PDX_CVTBBM_B2M_L(start_padding_mask34);
			vbool2M start_padding_mask12 = PDX_CVTBB2M_B_L(mask0);
			vboolM start_padding_mask2 = PDX_CVTBBM_B2M_H(start_padding_mask12);
			vboolM start_padding_mask1 = PDX_CVTBBM_B2M_L(start_padding_mask12);

			PDX_CVT32D_4MX20_L(last8,first8,acc);

			//keep 32 bit and do 80 bit multiplication

			//first8
			outacc = mult_acc_40 * first8;//8-way 32bit mac
			xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_last_row,add_acc_80_last_row_first_pixel,start_padding_mask1);
			acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_last_row_last_pixel,end_padding_mask1);
			outacc += acc_proc;


			//shift and round
			outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			//convert from 8 80bit -> 8 8bit

			xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_MX32(conv_out,vmax);
			conv_out = PDX_MAX_MX32(conv_out,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft -= nBytesToWrite;
			PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 8-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_MX8_FP(outa,outp);//flush

			//last8
			if(nBytesLeft>0){
				//first8
				outacc = mult_acc_40 * last8;//8-way 32bit mac
				//where start padding mask = 0, use add_acc_80_first_row_first_pixel
				xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_last_row,add_acc_80_last_row_first_pixel,start_padding_mask2);//simulate padding
				//where end padding mask = 0 use add_acc_80_first_row_last_pixel
				acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_last_row_last_pixel,end_padding_mask2);//simulate padding
				outacc += acc_proc;

				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= nBytesToWrite;
				PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush
			}


			if(nBytesLeft>0){
				PDX_CVT32D_4MX20_H(last8,first8,acc);

				//keep 32 bit and do 80 bit multiplication

				//first8
				outacc = mult_acc_40 * first8;//8-way 32bit mac
				xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_last_row,add_acc_80_last_row_first_pixel,start_padding_mask3);
				acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_last_row_last_pixel,end_padding_mask3);
				outacc += acc_proc;

				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= nBytesToWrite;
				PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush

				//last8
				if(nBytesLeft>0){
					//first8
					outacc = mult_acc_40 * last8;//8-way 32bit mac
					xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_last_row,add_acc_80_last_row_first_pixel,start_padding_mask4);
					acc_proc = PDX_MOV_MX80_T(acc_proc,add_acc_80_last_row_last_pixel,end_padding_mask4);
					outacc += acc_proc;

					//shift and round
					outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
					//round and shift and saturate
					//convert from 8 80bit -> 8 8bit

					xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
					nBytesLeft -= nBytesToWrite;
					PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					//to 8-way 8-bit signed, forward post-increment addressing mode
					PDX_SAPOS_MX8_FP(outa,outp);//flush
				}
			}
#else
			//account for 1st row padding
			//Quantization Compensation
			//Saturate each lane in acc before converting to 16bit
			//sets to true if first op greater than second op
			greater_than16bit =  PDX_GT_4MX20(acc, vmax16bit);//Get bool reg for registers greater than 16bit value
			//sets to true if first op less than second op
			lesser_than16bit =  PDX_LT_4MX20(acc, vmin16bit);//Get bool reg for registers greater than 16bit value
			//if bool is TRUE, first op is selected or else second op is selected
			acc = PDX_MOV_4MX20_T(vmax16bit, acc,greater_than16bit);
			acc = PDX_MOV_4MX20_T(vmin16bit, acc, lesser_than16bit);
			//Separate 32way 20bit data into 2 16way 16bit registers and perform quantization comp separately
			PDX_CVT16D_4MX20(last16, first16, acc);

			//first16
			outacc = mult_acc * first16;//PDX_MULMNW_2MX16(mult_acc,first16,0,0);
			outacc += add_acc;
			//shift and round
			outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_2MX16(conv_out,vmax);
			conv_out = PDX_MAX_2MX16(conv_out,vmin);
			nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
			PDX_SAV16_2MX8_XP(conv_out, outa, outp,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush
			nBytesLeft -= nBytesToWrite;

			//last16
			outacc = mult_acc * last16;//PDX_MULMNW_2MX16(mult_acc,last16,0,0);
			outacc += add_acc;
			//shift and round
			outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_2MX16(conv_out,vmax);
			conv_out = PDX_MAX_2MX16(conv_out,vmin);
			nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
			PDX_SAV16_2MX8_XP(conv_out, outa, outp,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush
			nBytesLeft -= nBytesToWrite;
#endif
			mask0 = nomask;
		}
		pInputBuffer += (nDepthMult==1)*(nInputWidth*nInputWidth);
	}
}

//FIXME: Change the depthconv to work with interleaved data.
//2D depthwise-convolution with stride of 2 in non-interleaved format using 16bit Eagle intrinsics. Also accounts for padding
void depthconv2d_skip_asm_non_interleaved_padding1_8bitconv_16bitquant(
		const ADI_ACTIVATION_DATATYPE *pInputBuffer,					//Input buffer
		ADI_ACTIVATION_DATATYPE *pOutputBuffer,					//Output buffer
		const ADI_WEIGHTS_DATATYPE *pWeightsBuffer,					//Weight buffer
		const ADI_CONV_BUFF_DATATYPE *pBiasBuffer,					//Bias
		ADI_CONV_BUFF_DATATYPE nInputWidth,							//Width of input buffer
		ADI_CONV_BUFF_DATATYPE nDepthMult,						//If channels have to be repeated
		ADI_CONV_BUFF_DATATYPE nInChannels,						    //In Channels
		ADI_CONV_BUFF_DATATYPE nOutChannels,					//Out Channels
		ADI_ACTIVATION_DATATYPE nKernelSize,					//Kernel size
		ADI_ACTIVATION_DATATYPE nTotalPadding,					//Total padding
		ADI_QMULTIPLIER_DATATYPE *pQuantizedMultiplier,			//Quantized multiplier
		ADI_CONV_BUFF_DATATYPE *pQuantizedShift,				//Quantized scale
		ADI_CONV_BUFF_DATATYPE pInZeroPoint,          //Input Zero Point
		ADI_CONV_BUFF_DATATYPE pOutZeroPoint)          //Output Zero Point
{
	ADI_ACTIVATION_DATATYPE nStrideLen = 2;
	ADI_ACTIVATION_DATATYPE nOutputBufferWidth = (ADI_ACTIVATION_DATATYPE)(nInputWidth - nKernelSize + nTotalPadding)/nStrideLen + 1;

	const immediate Lane = 0;
	const immediate round_mode = ROUNDING_MODE;



#ifdef USE_EXTRA_PRECISION
	xb_vecMx8* __restrict outp  = (xb_vecMx8 *)pOutputBuffer;
	xb_vecMx32  vOutZP = pOutZeroPoint;
	//load constants for range
	xb_vecMx32 vmin = ACT_MIN;
	xb_vecMx32 vmax = ACT_MAX;
	xb_vec2Mx40 vmax32bit = (xb_vec2Mx40)INT_32BIT_MAX;//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx40 vmin32bit = (xb_vec2Mx40)INT_32BIT_MIN;//Replicates the lane of data specified, across all lanes of a vector register
	vbool2M greater_than32bit, lesser_than32bit;
	xb_vecMx32 first8, last8;
	valign outa = PDX_LA_MX8_PP(outp); // initialize the alignment register vaWrite to zero
#else
	valign outa = PDX_Z_ALIGN(); // initialize the alignment register vaWrite to zero
	//outbuffer
	xb_vec2Mx8 * outp = (xb_vec2Mx8 *) pOutputBuffer;

	//zeropts and range are global across all channels
	xb_vec2Mx16 vOutZP = PDX_REP_2MX40((xb_vec2Mx16)pOutZeroPoint,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	//load constants for range
	xb_vec2Mx16 vmin = PDX_REP_2MX16((xb_vec2Mx16)-128,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx16 vmax = PDX_REP_2MX16((xb_vec2Mx16)127,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx16 conv_out, first16, last16;
	xb_vec4Mx20 vsum;
	xb_vec4Mx20 vmax16bit = PDX_REP_4MX20((xb_vec4Mx20)0x7FFF,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec4Mx20 vmin16bit = PDX_REP_4MX20((xb_vec4Mx20)0xFFFF8000,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	vbool4M greater_than16bit, lesser_than16bit;
#endif

	xb_vec4Mx8 vInZP = pInZeroPoint;//PDX_REP_4MX8((xb_vec4Mx8)pInZeroPoint,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	for(int nChannels = 0;nChannels < nOutChannels;nChannels++)
	{
#ifdef USE_EXTRA_PRECISION
		xb_vecMx32 mult_acc_40 = pQuantizedMultiplier[nChannels];
		xb_vecMx80 outacc;

		//Load pQuantizedShift for channel
		xb_vecMx32 shift = pQuantizedShift[nChannels];
#else
		uint16_t ReducedShift = (uint16_t)((pQuantizedMultiplier[nChannels] + (1 << 15)) >> 16);//Qmult is  (val) << 31, reduce this by 16 here to fit in int16
		//balance Qmult shift remaining is 15 but we include the +1 shift for PDX_MULAQW_2MX16 too here
		//this shift of 16 is accounted for during PDX_PACKQSRV_2MX40
		xb_vec2Mx16 mult_acc = PDX_REP_2MX16(ReducedShift,Lane);//Replicates the lane of data specified, across all lanes of a vector register

		//Load pQuantizedShift for channel
		const immediate nTotalShift = pQuantizedShift[nChannels]-1;
		xb_vec2Mx40 shift = PDX_REP_2MX40((xb_vec2Mx40)nTotalShift,Lane);//Replicates the lane of data specified, across all lanes of a vector register

		//bias specific to output channel
		xb_vec2Mx40 vbias = PDX_REP_2MX40((xb_vec2Mx40)((int64_t)((int64_t)pBiasBuffer[nChannels]<<2)*(ReducedShift)),Lane);
#endif

		//saturate bias within 20 bits
		//load bias*2 in nvec to match with vwt*vin*2
		//add zp * wt to bias
		int32_t zp_wt_sum;
		int32_t zp_wt_sum_last_pixel;
		int32_t zp_wt_sum_last_row;
		int32_t zp_wt_sum_last_row_last_pixel;

		int16_t wt_sum = 0;
		int16_t wt_sum_last_pixel = 0;

		int16_t wt_sum_last_row = 0;
		int16_t wt_sum_last_row_last_pixel = 0;

		//initialize weights for this channel
		//loading each of the (nKernelSize x nKernelSize) weights into it's own vector
		//each kernel weight is replicated in all the lanes to be multiplied in parallel
		int8_t nCurrWt;
		int8_t *filter_buff =  (int8_t *)pWeightsBuffer + nChannels;

		nCurrWt = (int8_t)(*filter_buff);
		wt_sum += nCurrWt;
		wt_sum_last_row += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		wt_sum_last_row_last_pixel += nCurrWt;
		filter_buff+=nOutChannels;

		xb_vec4Mx8 w00 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector
		nCurrWt = (int8_t)(*filter_buff);
		wt_sum += nCurrWt;
		wt_sum_last_row += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		wt_sum_last_row_last_pixel += nCurrWt;
		filter_buff+=nOutChannels;

		xb_vec4Mx8 w01 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector
		nCurrWt = (int8_t)(*filter_buff);
		wt_sum += nCurrWt;
		wt_sum_last_row += nCurrWt;
		filter_buff+=nOutChannels;
		xb_vec4Mx8 w02 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		//handle first col padding using weights w10,w20
		nCurrWt = (int8_t)(*filter_buff);
		wt_sum += nCurrWt;
		wt_sum_last_row += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		wt_sum_last_row_last_pixel += nCurrWt;
		filter_buff+=nOutChannels;

		xb_vec4Mx8 w10 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector
		nCurrWt = (int8_t)(*filter_buff);
		wt_sum += nCurrWt;
		wt_sum_last_row += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		wt_sum_last_row_last_pixel += nCurrWt;
		filter_buff+=nOutChannels;

		xb_vec4Mx8 w11 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector
		nCurrWt = (int8_t)(*filter_buff);
		wt_sum += nCurrWt;
		wt_sum_last_row += nCurrWt;
		filter_buff+=nOutChannels;
		xb_vec4Mx8 w12 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		nCurrWt = (int8_t)(*filter_buff);
		wt_sum += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		filter_buff+=nOutChannels;

		xb_vec4Mx8 w20 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector
		nCurrWt = (int8_t)(*filter_buff);
		wt_sum += nCurrWt;
		wt_sum_last_pixel += nCurrWt;
		filter_buff+=nOutChannels;

		xb_vec4Mx8 w21 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector
		nCurrWt = (int8_t)(*filter_buff);
		wt_sum += nCurrWt;
		filter_buff+=nOutChannels;
		xb_vec4Mx8 w22 = PDX_REP_4MX8((xb_vec4Mx8)nCurrWt,Lane);//load current weight and replicate the same in all lanes of the vector

		//PDX_MULAQW_2MX16 will add a *2, so shift this sum also by 2
		zp_wt_sum = (pInZeroPoint) * wt_sum;//8 bit * 16 bit should fit within 32 bit
		zp_wt_sum_last_pixel = (pInZeroPoint) * wt_sum_last_pixel;//8 bit * 16 bit should fit within 32 bit
		zp_wt_sum_last_row = (pInZeroPoint) * wt_sum_last_row;//8 bit * 16 bit should fit within 32 bit
		zp_wt_sum_last_row_last_pixel = (pInZeroPoint) * wt_sum_last_row_last_pixel;//8 bit * 16 bit should fit within 32 bit

#ifdef USE_EXTRA_PRECISION
		zp_wt_sum += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_last_pixel += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_last_row += pBiasBuffer[nChannels];//bias specific to output channel
		zp_wt_sum_last_row_last_pixel += pBiasBuffer[nChannels];//bias specific to output channel

		zp_wt_sum <<= 1;
		zp_wt_sum_last_pixel <<= 1;
		zp_wt_sum_last_row <<= 1;
		zp_wt_sum_last_row_last_pixel <<= 1;

		xb_vecMx80 add_acc_80 = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum;
		xb_vecMx80 add_acc_80_last_pixel = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_last_pixel;
		xb_vecMx80 add_acc_80_last_row = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_last_row;
		xb_vecMx80 add_acc_80_last_row_last_pixel = (xb_vecMx32)pQuantizedMultiplier[nChannels] * (xb_vecMx32)zp_wt_sum_last_row_last_pixel;
#else
		vsum = max((xb_vec4Mx20)(zp_wt_sum << 1), (xb_vec4Mx20)0xFFFFF);
		vsum = min(vsum, (xb_vec4Mx20)0x7FFFF);

		xb_vec2Mx40 outacc;
#endif

		//create first row mask
		vbool4M mask0 = PDX_MOVB_AU32 (0xFFFE);
		vbool4M mask2 = PDX_MOVB_AU32 (0x7FFF);

		xb_vec4Mx8 masked_w00 = PDX_MOV_V_T (w00, 0, mask0);  // Clear the first and/or last lane, if needed
		xb_vec4Mx8 masked_w02 = PDX_MOV_V_T (w02, 0, mask2);  // Clear the first and/or last lane, if needed

		//set first weight w10 to 0
		xb_vec4Mx8 masked_w10 = PDX_MOV_V_T (w10, 0, mask0);  // Clear the first and/or last lane, if needed
		xb_vec4Mx8 masked_w12 = PDX_MOV_V_T (w12, 0, mask2);  // Clear the first and/or last lane, if needed

		//set first weight w20 to 0
		xb_vec4Mx8 masked_w20 = PDX_MOV_V_T (w20, 0, mask0);  // Clear the first and/or last lane, if needed
		xb_vec4Mx8 masked_w22 = PDX_MOV_V_T (w22, 0, mask2);  // Clear the first and/or last lane, if needed

		//top row with first row padded, for 3x3 1 first col and 1 last col

		xb_vec4Mx8 * inp = (xb_vec4Mx8 *) pInputBuffer;  // create a pointer to move down the rows
		valign ina = PDX_LA_4MX8_PP (inp);


		xb_vec4Mx8 in00,in01,in02;
		xb_vec4Mx8 in10,in11,in12;
		xb_vec4Mx8 in20,in21,in22;
		xb_vec4Mx8 temp1, temp2;
		xb_vec4Mx20 tempacc;
		vbool4M temp_mask;
		vbool2M save_mask_low;

		int nBytesLeft = nOutputBufferWidth;
		int nBytesToWrite = 0;

		//---------------------------------------------All rows except last----------------------------------------------
		//for first to penultimate rows in one channel - no init padding
		for(int j = 0;j < nOutputBufferWidth - 1;j++)
		{
			inp = (xb_vec4Mx8 *) (pInputBuffer + (j * nStrideLen * nInputWidth));
			//first to penultimate pixels in row - no padding
			for(nBytesLeft = nOutputBufferWidth;nBytesLeft > 4*PDX_M;)
			{
				PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next element
				in00 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

				PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
				in01 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

				PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, nInputWidth - 2);  // read two vectors and go to next row
				in02 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

				PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
				in10 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

				PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
				in11 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

				PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, nInputWidth - 2);  // read two vectors and go to next row
				in12 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

				PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
				in20 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

				PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
				in21 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

				PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, - (nInputWidth * 2) - 2 + 4*PDX_M *2);  // go back to beginning + 64
				in22 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

#ifdef USE_EXTRA_PRECISION
				tempacc = 0;
#else
				tempacc = PDX_REP_4MX20(vsum,Lane);//load bias
#endif
				//multiply and accumulate
				PDX_MULAQW_4MX8(tempacc,w00,in00);
				PDX_MULAQW_4MX8(tempacc,w01,in01);
				PDX_MULAQW_4MX8(tempacc,w02,in02);
				PDX_MULAQW_4MX8(tempacc,w10,in10);
				PDX_MULAQW_4MX8(tempacc,w11,in11);
				PDX_MULAQW_4MX8(tempacc,w12,in12);
				PDX_MULAQW_4MX8(tempacc,w20,in20);
				PDX_MULAQW_4MX8(tempacc,w21,in21);
				PDX_MULAQW_4MX8(tempacc,w22,in22);

#ifdef USE_EXTRA_PRECISION
				//32 20 bit -> 8 80 bits
				//convert 32 20 bit acc to 8 32 bit acc.
				//convert L half of acc to 2 32 bit acc

				PDX_CVT32D_4MX20_L(last8,first8,tempacc);

				//keep 32 bit and do 80 bit multiplication

				//first8
				outacc = mult_acc_40 * first8;//8-way 32bit mac
				outacc += add_acc_80;

				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= PDX_M;
				PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush

				//last8
				if(nBytesLeft>0){
					//first8
					outacc = mult_acc_40 * last8;//8-way 32bit mac
					outacc += add_acc_80;

					//shift and round
					outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
					//round and shift and saturate
					//convert from 8 80bit -> 8 8bit

					xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
					nBytesLeft -= PDX_M;
					PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					//to 8-way 8-bit signed, forward post-increment addressing mode
					PDX_SAPOS_MX8_FP(outa,outp);//flush
				}


				if(nBytesLeft>0){
					PDX_CVT32D_4MX20_H(last8,first8,tempacc);

					//keep 32 bit and do 80 bit multiplication

					//first8
					outacc = mult_acc_40 * first8;//8-way 32bit mac
					outacc += add_acc_80;

					//shift and round
					outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
					//round and shift and saturate
					//convert from 8 80bit -> 8 8bit

					xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
					nBytesLeft -= nBytesToWrite;
					PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					//to 8-way 8-bit signed, forward post-increment addressing mode
					PDX_SAPOS_MX8_FP(outa,outp);//flush

					//last8
					if(nBytesLeft>0){
						//first8
						outacc = mult_acc_40 * last8;//8-way 32bit mac
						outacc += add_acc_80;

						//shift and round
						outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
						//round and shift and saturate
						//convert from 8 80bit -> 8 8bit

						xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

						//add output zero point
						conv_out += vOutZP;
						//Saturate to 8 bit range output_activation_min to 127
						conv_out = PDX_MIN_MX32(conv_out,vmax);
						conv_out = PDX_MAX_MX32(conv_out,vmin);
						nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
						nBytesLeft -= nBytesToWrite;
						PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
						//to 8-way 8-bit signed, forward post-increment addressing mode
						PDX_SAPOS_MX8_FP(outa,outp);//flush
					}
				}
#else
				//Quantization Compensation
				//Saturate each lane in acc before converting to 16bit
				//sets to true if first op greater than second op
				greater_than16bit =  PDX_GT_4MX20(tempacc, vmax16bit);//Get bool reg for registers greater than 16bit value
				//sets to true if first op less than second op
				lesser_than16bit =  PDX_LT_4MX20(tempacc, vmin16bit);//Get bool reg for registers greater than 16bit value
				//if bool is TRUE, first op is selected or else second op is selected
				tempacc = PDX_MOV_4MX20_T(vmax16bit, tempacc,greater_than16bit);
				tempacc = PDX_MOV_4MX20_T(vmin16bit, tempacc, lesser_than16bit);
				//Separate 32way 20bit data into 2 16way 16bit registers and perform quantization comp separately
				PDX_CVT16D_4MX20(last16, first16, tempacc);

				//first16
				outacc=0;
				PDX_MULAQW_2MX16(outacc,mult_acc,first16);
				outacc+=vbias;
				//shift and round
				outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_2MX16(conv_out,vmax);
				conv_out = PDX_MAX_2MX16(conv_out,vmin);
				nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
				nBytesLeft-=2*PDX_M;
				PDX_SAV16_2MX8_XP(conv_out, outa, outp,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush

				//last16
				outacc=0;
				PDX_MULAQW_2MX16(outacc,mult_acc,last16);
				outacc+=vbias;
				//shift and round
				outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_2MX16(conv_out,vmax);
				conv_out = PDX_MAX_2MX16(conv_out,vmin);
				nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
				nBytesLeft-=2*PDX_M;
				PDX_SAV16_2MX8_XP(conv_out, outa, outp,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush
#endif
			}

			//last pixel in row - column padding present

			vbool4M padding_mask = PDX_MOVB_AU32 ((0x1<<(nBytesLeft-1)) - 1);
			xb_vec4Mx8 masked_w02 = PDX_MOV_V_T (w02, 0, padding_mask);  // Clear the first and/or last lane, if needed
			xb_vec4Mx8 masked_w12 = PDX_MOV_V_T (w12, 0, padding_mask);  // Clear the first and/or last lane, if needed
			xb_vec4Mx8 masked_w22 = PDX_MOV_V_T (w22, 0, padding_mask);  // Clear the first and/or last lane, if needed


			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next element
			in00 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
			in01 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, nInputWidth - 2);  // read two vectors and go to next row
			in02 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
			in10 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
			in11 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, nInputWidth - 2);  // read two vectors and go to next row
			in12 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
			in20 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
			in21 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 0);  // go back to beginning + 64
			in22 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

#ifdef USE_EXTRA_PRECISION
			tempacc = 0;
#else
			tempacc = PDX_REP_4MX20(vsum,Lane);//load bias
#endif

			//multiply and accumulate
			PDX_MULAQW_4MX8(tempacc,w00,in00);
			PDX_MULAQW_4MX8(tempacc,w01,in01);
			PDX_MULAQW_4MX8(tempacc,masked_w02,in02);
			PDX_MULAQW_4MX8(tempacc,w10,in10);
			PDX_MULAQW_4MX8(tempacc,w11,in11);
			PDX_MULAQW_4MX8(tempacc,masked_w12,in12);
			PDX_MULAQW_4MX8(tempacc,w20,in20);
			PDX_MULAQW_4MX8(tempacc,w21,in21);
			PDX_MULAQW_4MX8(tempacc,masked_w22,in22);

#ifdef USE_EXTRA_PRECISION
			//32 20 bit -> 8 80 bits
			//convert 32 20 bit acc to 8 32 bit acc.
			//convert L half of acc to 2 32 bit acc

			PDX_CVT32D_4MX20_L(last8,first8,tempacc);

			//keep 32 bit and do 80 bit multiplication

			//first8
			outacc = mult_acc_40 * first8;//8-way 32bit mac

			//if bool is TRUE, first op is selected or else second op is selected
			//create mask based on elements left
			int nRemCols = MIN(nBytesLeft - 1,4*PDX_M);//1 last pixel is padded
			uint32_t nShift = (((uint64_t)1)<<(nRemCols)) - 1;//only last element to be padded
			vbool4M cal_padding_mask = PDX_MOVB_AU32(nShift);
			//create mask based on elements left
			//convert 32 8 bit to 32 32bit data
			//map higher bits in H to 3 and 4
			//map lower bits in L to 1 and 2
			vbool2M end_padding_mask34 = PDX_CVTBB2M_B_H(cal_padding_mask);
			vboolM end_padding_mask4 = PDX_CVTBBM_B2M_H(end_padding_mask34);
			vboolM end_padding_mask3 = PDX_CVTBBM_B2M_L(end_padding_mask34);
			vbool2M end_padding_mask12 = PDX_CVTBB2M_B_L(cal_padding_mask);
			vboolM end_padding_mask2 = PDX_CVTBBM_B2M_H(end_padding_mask12);
			vboolM end_padding_mask1 = PDX_CVTBBM_B2M_L(end_padding_mask12);

			xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80,add_acc_80_last_pixel,end_padding_mask1);//simulate padding
			outacc += acc_proc;

			//shift and round
			outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			//convert from 8 80bit -> 8 8bit

			xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_MX32(conv_out,vmax);
			conv_out = PDX_MAX_MX32(conv_out,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft -= PDX_M;
			PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 8-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_MX8_FP(outa,outp);//flush

			//last8
			if(nBytesLeft>0){
				//first8
				outacc = mult_acc_40 * last8;//8-way 32bit mac

				xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80,add_acc_80_last_pixel,end_padding_mask2);//simulate padding
				outacc += acc_proc;

				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= PDX_M;
				PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush
			}


			if(nBytesLeft>0){
				PDX_CVT32D_4MX20_H(last8,first8,tempacc);

				//keep 32 bit and do 80 bit multiplication

				//first8
				outacc = mult_acc_40 * first8;//8-way 32bit mac

				xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80,add_acc_80_last_pixel,end_padding_mask3);//simulate padding
				outacc += acc_proc;


				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= nBytesToWrite;
				PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush

				//last8
				if(nBytesLeft>0){
					//first8
					outacc = mult_acc_40 * last8;//8-way 32bit mac

					xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80,add_acc_80_last_pixel,end_padding_mask4);//simulate padding
					outacc += acc_proc;


					//shift and round
					outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
					//round and shift and saturate
					//convert from 8 80bit -> 8 8bit

					xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
					nBytesLeft -= nBytesToWrite;
					PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					//to 8-way 8-bit signed, forward post-increment addressing mode
					PDX_SAPOS_MX8_FP(outa,outp);//flush
				}
			}
#else
			//Quantization Compensation
			//Saturate each lane in acc before converting to 16bit
			//sets to true if first op greater than second op
			greater_than16bit =  PDX_GT_4MX20(tempacc, vmax16bit);//Get bool reg for registers greater than 16bit value
			//sets to true if first op less than second op
			lesser_than16bit =  PDX_LT_4MX20(tempacc, vmin16bit);//Get bool reg for registers greater than 16bit value
			//if bool is TRUE, first op is selected or else second op is selected
			tempacc = PDX_MOV_4MX20_T(vmax16bit, tempacc,greater_than16bit);
			tempacc = PDX_MOV_4MX20_T(vmin16bit, tempacc, lesser_than16bit);
			//Separate 32way 20bit data into 2 16way 16bit registers and perform quantization comp separately
			PDX_CVT16D_4MX20(last16, first16, tempacc);

			//first16
			outacc=0;
			PDX_MULAQW_2MX16(outacc,mult_acc,first16);
			outacc+=vbias;
			//shift and round
			outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_2MX16(conv_out,vmax);
			conv_out = PDX_MAX_2MX16(conv_out,vmin);
			nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
			nBytesLeft-=2*PDX_M;
			temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
			save_mask_low = PDX_CVTBB2M_B4M_L(temp_mask);
			PDX_SAV16_2MX8_XP_T(conv_out, outa, outp,nBytesToWrite, temp_mask, save_mask_low);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush

			//last16
			if(nBytesLeft>0){
				outacc=0;
				PDX_MULAQW_2MX16(outacc,mult_acc,last16);
				outacc+=vbias;
				//shift and round
				outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_2MX16(conv_out,vmax);
				conv_out = PDX_MAX_2MX16(conv_out,vmin);
				nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
				nBytesLeft-=2*PDX_M;
				temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
				save_mask_low = PDX_CVTBB2M_B4M_L(temp_mask);
				PDX_SAV16_2MX8_XP_T(conv_out, outa, outp,nBytesToWrite, temp_mask, save_mask_low);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush
			}
#endif
		}
		//----------------------------------------------LAST ROW---------------------------------------------
		//Last padded row done separately
		//w20,w21,w22 not used
		nBytesLeft = nOutputBufferWidth;
		inp =(xb_vec4Mx8 *) ((pInputBuffer + (nInputWidth-2) * nInputWidth));
		ina = PDX_LA_4MX8_PP (inp);
		//ensure we do last padded pixel separately
		for(nBytesLeft = nOutputBufferWidth;nBytesLeft > 4*PDX_M;)
		{
			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next element
			in00 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
			in01 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, nInputWidth - 2);  // read two vectors and go to next row
			in02 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
			in10 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
			in11 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

			PDX_LA_4MX8D_XP (temp1, temp2, ina, inp,  - (nInputWidth) - 2 + 4*PDX_M *2);  // read two vectors and go to next row
			in12 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

#ifdef USE_EXTRA_PRECISION
			tempacc = 0;
#else
			tempacc = PDX_REP_4MX20(vsum,Lane);//load bias
#endif

			//multiply and accumulate
			PDX_MULAQW_4MX8(tempacc,w00,in00);
			PDX_MULAQW_4MX8(tempacc,w01,in01);
			PDX_MULAQW_4MX8(tempacc,w02,in02);
			PDX_MULAQW_4MX8(tempacc,w10,in10);
			PDX_MULAQW_4MX8(tempacc,w11,in11);
			PDX_MULAQW_4MX8(tempacc,w12,in12);

#ifdef USE_EXTRA_PRECISION
			//32 20 bit -> 8 80 bits
			//convert 32 20 bit acc to 8 32 bit acc.
			//convert L half of acc to 2 32 bit acc

			PDX_CVT32D_4MX20_L(last8,first8,tempacc);

			//keep 32 bit and do 80 bit multiplication

			//first8
			outacc = mult_acc_40 * first8;//8-way 32bit mac
			outacc += add_acc_80_last_row;

			//shift and round
			outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			//convert from 8 80bit -> 8 8bit

			xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_MX32(conv_out,vmax);
			conv_out = PDX_MAX_MX32(conv_out,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft -= PDX_M;
			PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 8-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_MX8_FP(outa,outp);//flush

			//last8
			if(nBytesLeft>0){
				//first8
				outacc = mult_acc_40 * last8;//8-way 32bit mac
				outacc += add_acc_80_last_row;

				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= PDX_M;
				PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush
			}


			if(nBytesLeft>0){
				PDX_CVT32D_4MX20_H(last8,first8,tempacc);

				//keep 32 bit and do 80 bit multiplication

				//first8
				outacc = mult_acc_40 * first8;//8-way 32bit mac
				outacc += add_acc_80_last_row;

				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= nBytesToWrite;
				PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush

				//last8
				if(nBytesLeft>0){
					//first8
					outacc = mult_acc_40 * last8;//8-way 32bit mac
					outacc += add_acc_80_last_row;

					//shift and round
					outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
					//round and shift and saturate
					//convert from 8 80bit -> 8 8bit

					xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
					nBytesLeft -= nBytesToWrite;
					PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					//to 8-way 8-bit signed, forward post-increment addressing mode
					PDX_SAPOS_MX8_FP(outa,outp);//flush
				}
			}
#else
			//Quantization Compensation
			//Saturate each lane in acc before converting to 16bit
			//sets to true if first op greater than second op
			greater_than16bit =  PDX_GT_4MX20(tempacc, vmax16bit);//Get bool reg for registers greater than 16bit value
			//sets to true if first op less than second op
			lesser_than16bit =  PDX_LT_4MX20(tempacc, vmin16bit);//Get bool reg for registers greater than 16bit value
			//if bool is TRUE, first op is selected or else second op is selected
			tempacc = PDX_MOV_4MX20_T(vmax16bit, tempacc,greater_than16bit);
			tempacc = PDX_MOV_4MX20_T(vmin16bit, tempacc, lesser_than16bit);
			//Separate 32way 20bit data into 2 16way 16bit registers and perform quantization comp separately
			PDX_CVT16D_4MX20(last16, first16, tempacc);

			//first16
			outacc=0;
			PDX_MULAQW_2MX16(outacc,mult_acc,first16);
			outacc+=vbias;
			//shift and round
			outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_2MX16(conv_out,vmax);
			conv_out = PDX_MAX_2MX16(conv_out,vmin);
			nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
			nBytesLeft-=2*PDX_M;
			PDX_SAV16_2MX8_XP(conv_out, outa, outp,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush

			//last16
			outacc=0;
			PDX_MULAQW_2MX16(outacc,mult_acc,last16);
			outacc+=vbias;
			//shift and round
			outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_2MX16(conv_out,vmax);
			conv_out = PDX_MAX_2MX16(conv_out,vmin);
			nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
			nBytesLeft-=2*PDX_M;
			PDX_SAV16_2MX8_XP(conv_out, outa, outp,nBytesToWrite);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush
#endif
		}

		//last row - with last pixel

		vbool4M padding_mask = PDX_MOVB_AU32 ((0x1<<(nBytesLeft-1)) - 1);
		masked_w02 = PDX_MOV_V_T (w02, 0, padding_mask);  // Clear the first and/or last lane, if needed
		masked_w12 = PDX_MOV_V_T (w12, 0, padding_mask);  // Clear the first and/or last lane, if needed
		//masked_w22 = PDX_MOV_V_T (w22, 0, padding_mask);

		PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next element
		in00 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

		PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
		in01 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

		PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, nInputWidth - 2);  // read two vectors and go to next row
		in02 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

		PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
		in10 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

		PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 1);  // read two vectors and go to next row
		in11 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

		PDX_LA_4MX8D_XP (temp1, temp2, ina, inp, 0);  // read two vectors and go to next row
		in12 = PDX_SELI_4MX8 (temp1, temp2, PDX_SELI_8B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes

#ifdef USE_EXTRA_PRECISION
		tempacc = 0;
#else
		tempacc = PDX_REP_4MX20(vsum,Lane);//load bias
#endif


		//multiply and accumulate
		PDX_MULAQW_4MX8(tempacc,w00,in00);
		PDX_MULAQW_4MX8(tempacc,w01,in01);
		PDX_MULAQW_4MX8(tempacc,masked_w02,in02);
		PDX_MULAQW_4MX8(tempacc,w10,in10);
		PDX_MULAQW_4MX8(tempacc,w11,in11);
		PDX_MULAQW_4MX8(tempacc,masked_w12,in12);

#ifdef USE_EXTRA_PRECISION
		//32 20 bit -> 8 80 bits
		//convert 32 20 bit acc to 8 32 bit acc.
		//convert L half of acc to 2 32 bit acc

		PDX_CVT32D_4MX20_L(last8,first8,tempacc);

		//keep 32 bit and do 80 bit multiplication

		//first8
		outacc = mult_acc_40 * first8;//8-way 32bit mac

		//if bool is TRUE, first op is selected or else second op is selected
		//create mask based on elements left
		int nRemCols = MIN(nBytesLeft - 1,4*PDX_M);//1 last pixel is padded
		uint32_t nShift = (((uint64_t)1)<<(nRemCols)) - 1;//only last element to be padded
		vbool4M cal_padding_mask = PDX_MOVB_AU32(nShift);
		//create mask based on elements left
		//convert 32 8 bit to 32 32bit data
		//map higher bits in H to 3 and 4
		//map lower bits in L to 1 and 2
		vbool2M end_padding_mask34 = PDX_CVTBB2M_B_H(cal_padding_mask);
		vboolM end_padding_mask4 = PDX_CVTBBM_B2M_H(end_padding_mask34);
		vboolM end_padding_mask3 = PDX_CVTBBM_B2M_L(end_padding_mask34);
		vbool2M end_padding_mask12 = PDX_CVTBB2M_B_L(cal_padding_mask);
		vboolM end_padding_mask2 = PDX_CVTBBM_B2M_H(end_padding_mask12);
		vboolM end_padding_mask1 = PDX_CVTBBM_B2M_L(end_padding_mask12);

		xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_last_row,add_acc_80_last_row_last_pixel,end_padding_mask1);//simulate padding
		outacc += acc_proc;

		//shift and round
		outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
		//round and shift and saturate
		//convert from 8 80bit -> 8 8bit

		xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

		//add output zero point
		conv_out += vOutZP;
		//Saturate to 8 bit range output_activation_min to 127
		conv_out = PDX_MIN_MX32(conv_out,vmax);
		conv_out = PDX_MAX_MX32(conv_out,vmin);
		nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
		nBytesLeft -= PDX_M;
		PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
		//to 8-way 8-bit signed, forward post-increment addressing mode
		PDX_SAPOS_MX8_FP(outa,outp);//flush

		//last8
		if(nBytesLeft>0){
			//first8
			outacc = mult_acc_40 * last8;//8-way 32bit mac

			xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_last_row,add_acc_80_last_row_last_pixel,end_padding_mask2);//simulate padding
			outacc += acc_proc;

			//shift and round
			outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			//convert from 8 80bit -> 8 8bit

			xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_MX32(conv_out,vmax);
			conv_out = PDX_MAX_MX32(conv_out,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft -= PDX_M;
			PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 8-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_MX8_FP(outa,outp);//flush
		}


		if(nBytesLeft>0){
			PDX_CVT32D_4MX20_H(last8,first8,tempacc);

			//keep 32 bit and do 80 bit multiplication

			//first8
			outacc = mult_acc_40 * first8;//8-way 32bit mac

			xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_last_row,add_acc_80_last_row_last_pixel,end_padding_mask3);//simulate padding
			outacc += acc_proc;

			//shift and round
			outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			//convert from 8 80bit -> 8 8bit

			xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_MX32(conv_out,vmax);
			conv_out = PDX_MAX_MX32(conv_out,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft -= nBytesToWrite;
			PDX_SAV32_MX8_XP(conv_out, outa,outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 8-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_MX8_FP(outa,outp);//flush

			//last8
			if(nBytesLeft>0){
				//first8
				outacc = mult_acc_40 * last8;//8-way 32bit mac
				xb_vecMx80 acc_proc = PDX_MOV_MX80_T(add_acc_80_last_row,add_acc_80_last_row_last_pixel,end_padding_mask4);//simulate padding
				outacc += acc_proc;

				//shift and round
				outacc = PDX_SLS_MX80(outacc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				//convert from 8 80bit -> 8 8bit

				xb_vecMx32 conv_out = PDX_PACKQSRV_MX80(outacc, round_mode);//shift by 32 bit 80->32

				//add output zero point
				conv_out += vOutZP;
				//Saturate to 8 bit range output_activation_min to 127
				conv_out = PDX_MIN_MX32(conv_out,vmax);
				conv_out = PDX_MAX_MX32(conv_out,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft -= nBytesToWrite;
				PDX_SAV32_MX8_XP(conv_out, outa, outp, nBytesToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 8-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_MX8_FP(outa,outp);//flush
			}
		}
#else
		//Quantization Compensation
		//Saturate each lane in acc before converting to 16bit
		//sets to true if first op greater than second op
		greater_than16bit =  PDX_GT_4MX20(tempacc, vmax16bit);//Get bool reg for registers greater than 16bit value
		//sets to true if first op less than second op
		lesser_than16bit =  PDX_LT_4MX20(tempacc, vmin16bit);//Get bool reg for registers greater than 16bit value
		//if bool is TRUE, first op is selected or else second op is selected
		tempacc = PDX_MOV_4MX20_T(vmax16bit, tempacc,greater_than16bit);
		tempacc = PDX_MOV_4MX20_T(vmin16bit, tempacc, lesser_than16bit);
		//Separate 32way 20bit data into 2 16way 16bit registers and perform quantization comp separately
		PDX_CVT16D_4MX20(last16, first16, tempacc);

		//first16
		outacc=0;
		PDX_MULAQW_2MX16(outacc,mult_acc,first16);
		outacc+=vbias;
		//shift and round
		outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
		//round and shift and saturate
		conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
		//add output zero point
		conv_out += vOutZP;
		//Saturate to 8 bit range output_activation_min to 127
		conv_out = PDX_MIN_2MX16(conv_out,vmax);
		conv_out = PDX_MAX_2MX16(conv_out,vmin);
		nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
		nBytesLeft-=2*PDX_M;
		temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
		save_mask_low = PDX_CVTBB2M_B4M_L(temp_mask);
		PDX_SAV16_2MX8_XP_T(conv_out, outa, outp,nBytesToWrite, temp_mask, save_mask_low);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
		//to 16-way 8-bit signed, forward post-increment addressing mode
		PDX_SAPOS_2MX8_FP(outa,outp);//flush

		//last16
		if(nBytesLeft>0){
			outacc=0;
			PDX_MULAQW_2MX16(outacc,mult_acc,last16);
			outacc+=vbias;
			//shift and round
			outacc = PDX_SLS_2MX40(outacc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_2MX40  (outacc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//Saturate to 8 bit range output_activation_min to 127
			conv_out = PDX_MIN_2MX16(conv_out,vmax);
			conv_out = PDX_MAX_2MX16(conv_out,vmin);
			nBytesToWrite = nBytesLeft - 2*PDX_M > 0 ? 2*PDX_M : nBytesLeft;
			nBytesLeft-=2*PDX_M;
			temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
			save_mask_low = PDX_CVTBB2M_B4M_L(temp_mask);
			PDX_SAV16_2MX8_XP_T(conv_out, outa, outp,nBytesToWrite, temp_mask, save_mask_low);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush
		}
#endif
		pInputBuffer += (nDepthMult==1)*(nInputWidth*nInputWidth);
	}
}

//FIXME: Change the depthconv to work with interleaved data.
//2D depthwise-convolution with stride of 2 in non-interleaved format using 16bit Eagle intrinsics. Also accounts for padding
void depthconv2d_skip_asm_non_interleaved_8x10(
		const ADI_ACTIVATION_DATATYPE *pInputBuffer,			//Input buffer
		const ADI_WEIGHTS_DATATYPE *pWeightsBuffer,				//Weight buffer
		const ADI_CONV_BUFF_DATATYPE *pBiasBuffer,				//Bias
		ADI_ACTIVATION_DATATYPE *pOutputBuffer,					//Output buffer
		ADI_CONV_BUFF_DATATYPE nInputWidth,						//Width of input buffer
		ADI_CONV_BUFF_DATATYPE nInputLength,					//Length of input buffer
		ADI_CONV_BUFF_DATATYPE nInChannels,						//Depth of input buffer- In Channels
		ADI_CONV_BUFF_DATATYPE nOutputWidth,					//Width of output buffer
		ADI_CONV_BUFF_DATATYPE nOutputLength,					//Length of output buffer
		ADI_CONV_BUFF_DATATYPE nOutChannels,					//Depth of output buffer- Out Channels
		ADI_ACTIVATION_DATATYPE nKernelWidth,					//Width of filter
		ADI_ACTIVATION_DATATYPE nKernelLength,					//Length of filter
		ADI_ACTIVATION_DATATYPE nPaddingWidth,					//Width of padding
		ADI_ACTIVATION_DATATYPE nPaddingLength,					//Length of padding
		ADI_QMULTIPLIER_DATATYPE *pQuantizedMultiplier,			//Quantized multiplier
		ADI_CONV_BUFF_DATATYPE *pQuantizedShift,				//Quantized scale
		ADI_CONV_BUFF_DATATYPE pInZeroPoint,          			//Input Zero Point
		ADI_CONV_BUFF_DATATYPE pOutZeroPoint,         		//Output Zero Point
		ADI_CONV_BUFF_DATATYPE output_activation_min,
		ADI_CONV_BUFF_DATATYPE output_activation_max)
{
	ADI_ACTIVATION_DATATYPE nStrideLen = 2;

	const immediate Lane = 0;
	const immediate round_mode = 2;

	valign outa = PDX_Z_ALIGN(); // initialize the alignment register vaWrite to zero

	//outbuffer
	xb_vec2Mx8 * outp = (xb_vec2Mx8 *) pOutputBuffer;

	//zeropts and range are global across all channels
	xb_vec2Mx16 vInZP = PDX_REP_2MX16((xb_vec2Mx16)pInZeroPoint,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vecMx32 vOutZP = PDX_REP_MX32((xb_vecMx32)pOutZeroPoint,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	//load constants for range
	xb_vec2Mx16 vmin = PDX_REP_2MX16((xb_vec2Mx16)output_activation_min,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx16 vmax = PDX_REP_2MX16((xb_vec2Mx16)output_activation_max,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	//load constants for 16bit range
	xb_vec2Mx40 vmax16bit = PDX_REP_2MX40((xb_vec2Mx40)0x7FFF,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx40 vmin16bit = PDX_REP_2MX40((xb_vec2Mx40)0xFFFFFFFFFFFF8000,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	vbool2M greater_than16bit, lesser_than16bit;

	//variables
	xb_vec2Mx16 temp1, temp2;
	xb_vec2Mx16 vInput, vWeights;
	vbool4M temp_mask;
	vbool2M fffe, fffc, ffff;//Masks for row padding
	//FFFF does not mask any lane.
	//FFFE masks only the first lane.
	//FFFC masks the first 2 lanes.
	/*INITIAL PADDING
	 * Function has been designed to store one convolution result in one lane of the accumulator.
	 * When there is padding to be accounted for, the idea here is to mask the weights of the
	 * corresponding input that is supposed to be padded so that it does not contribute to the
	 * conv result.
	 * Here, padding width(row) is 3 and stride is 2.
	 * The first input pixel(weight) will not contribute to the first 2 convolutions, hence the FFFC mask.
	 * The second and third pixel(weight) will not contribute to the first convolution, hence the FFFE mask.
	 * All the remaining pixels will be a part of the conv result and hence will not be masked.
	*/
	//FINAL PADDING is calculated dynamically based on the remaining pixels.

	vbool2M padding_mask;
	xb_vec2Mx40 save_reg;
	xb_vec2Mx16 temp_reg;
	xb_vecMx32 conv_out;
	int nBytesToWrite=0;
	xb_vecMx32 first16, last16;
	xb_vec2Mx40 outacc;
	xb_vecMx80 quant_acc;

	temp_mask = PDX_MOVB_AU32(0xFFFCFFFE);
	PDX_CVTBB2M_B4M(fffc, fffe, temp_mask);
	temp_mask = PDX_MOVB_AU32(0xFFFFFFFF);
	PDX_CVTBB2M_B4M(ffff, ffff, temp_mask);

	for(int nChannels = 0;nChannels < nOutChannels;nChannels++)
	{
		xb_vec2Mx8 * inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth);//account for col padding
		valign ina = PDX_LA_2MX8_PP (inp);

		int8_t *filter_buff =  (int8_t *)pWeightsBuffer + nPaddingLength*nKernelWidth*nOutChannels + nChannels;//skip padded rows
		int8_t nCurrWt;

		xb_vec2Mx40 vBias = PDX_REP_2MX40((xb_vec2Mx40)pBiasBuffer[nChannels],Lane);

		xb_vecMx32 mult_acc = PDX_REP_MX32(pQuantizedMultiplier[nChannels],Lane);

		const immediate nTotalShift = pQuantizedShift[nChannels];			//Load shift factor for quantization per channel
		xb_vecMx32  shift = PDX_REP_MX32((xb_vecMx32 )(nTotalShift-1),Lane);	//Replicates the lane of data specified, across all lanes of a vector register

		//First row
		//Loops are designed wrt output pixels
		int nBytesLeft = nOutputWidth;
		for(int nCol = 0; nCol<nOutputWidth; nCol+=2*PDX_M)
		{
			outacc=0;
			for(int j=nPaddingLength; j<nKernelLength; j++)//Start from after padding
			{
				for(int k=0; k<nKernelWidth; k++)
				{
					//load inputs and add input offset
					PDX_LA16D_4MX8_XP (temp1, temp2, ina, inp, 1 );  //find intrinsic that does not update base addr
					vInput = PDX_SELI_2MX16 (temp1, temp2, PDX_SELI_16B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes - stride 2
					vInput += vInZP;

					//Padding
					if(nBytesLeft<2*PDX_M){//Final Padding
						if(k==nKernelWidth-1){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-2)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}							//Masking 2 lanes
						else if(k==nKernelWidth-2 || k==nKernelWidth-3){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-1)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}	//Masking 1 lane
						else padding_mask = ffff;																															//No masking
					}
					else{//Initial Padding
						if(k==0) padding_mask = fffc;				//Masking 2 lanes
						else if(k==1 || k==2) padding_mask = fffe;	//Masking 1 lane
						else padding_mask = ffff;					//No Masking
					}
					//Load weights
					vWeights=0;
					nCurrWt = *filter_buff;
					filter_buff+=nOutChannels;
					PDX_REP_2MX16_T(vWeights, (xb_vec2Mx16)nCurrWt,Lane, padding_mask);//load current weight and replicate the same in all lanes of the vector

					//multiply and accumulate
					PDX_MULAQW_2MX16(outacc,vInput,vWeights);

				}
//				inp += (-nKernelWidth + nInputWidth);//move to next row of inputs
				inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + ((j-3)*nInputWidth)+ (nBytesLeft<2*PDX_M)*2*PDX_M*nStrideLen);
				ina = PDX_LA_2MX8_PP (inp);
			}
			//quantization compensation
			outacc+=vBias;//add bias
			PDX_CVT32D_2MX40(last16, first16, outacc);	//Converting 40bit results to 32bit to prevent loss of accuracy from packing of 40bit -> 16bit

			//first16
			quant_acc=0;
			PDX_MULAQW_MX32(quant_acc,mult_acc,first16);	//Multiplying 2 32-bit vectors and storing result in 80bit vector
			//shift and round
			quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);	//pack 80bit result to 32bit with rounding and saturation.
			//add output zero point
			conv_out += vOutZP;
			//Following instrunctions are needed as there is no direct way to typecast 32bit data to 8bit
			save_reg = PDX_CVT40_MX32_L(conv_out);					//convert to 40bit
			//
			temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);				//pack 40bit data into 16bit vector
			//Saturate to 8 bit range output_activation_min to 127
			temp_reg = PDX_MIN_2MX16(temp_reg,vmax);				//8bit saturation check
			temp_reg = PDX_MAX_2MX16(temp_reg,vmin);				//8bit saturation check
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft-=PDX_M;
			temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
			padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
			PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//Store 16-bit data as 8-bit
			PDX_SAPOS_2MX8_FP(outa,outp);//flush

			if(nBytesLeft>0){
				//last16
				quant_acc=0;
				PDX_MULAQW_MX32(quant_acc,mult_acc,last16);
				//shift and round
				quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//
				save_reg = PDX_CVT40_MX32_L(conv_out);
				//
				temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
				//Saturate to 8 bit range output_activation_min to 127
				temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
				temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft-=PDX_M;
				temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
				padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
				PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush
			}
			inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth+2*PDX_M*nStrideLen);
			ina = PDX_LA_2MX8_PP (inp);
			filter_buff =  (int8_t *)pWeightsBuffer + nPaddingLength*nKernelWidth*nOutChannels + nChannels;//skip padded rows
		}
		//Second row--rest input buffer
		nBytesLeft = nOutputWidth;
		inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth);//account for col padding
		ina = PDX_LA_2MX8_PP (inp);
		filter_buff =  (int8_t *)(pWeightsBuffer + (nPaddingLength-nStrideLen)*nKernelWidth*nOutChannels)+ nChannels;
		for(int nCol = 0; nCol<nOutputWidth; nCol+=2*PDX_M)
		{
			outacc=0;
			for(int j=nPaddingLength-nStrideLen; j<nKernelLength; j++)//Start from after padding
			{
				for(int k=0; k<nKernelWidth; k++)
				{
					//load inputs and add input offset
					PDX_LA16D_4MX8_XP (temp1, temp2, ina, inp, 1 );  //find intrinsic that does not update base addr
					vInput = PDX_SELI_2MX16 (temp1, temp2, PDX_SELI_16B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes - stride 2
					vInput += vInZP;

					//Padding
					if(nBytesLeft<2*PDX_M){
						if(k==nKernelWidth-1){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-2)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}
						else if(k==nKernelWidth-2 || k==nKernelWidth-3){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-1)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}
						else padding_mask = ffff;
					}
					else{
						if(k==0) padding_mask = fffc;
						else if(k==1 || k==2) padding_mask = fffe;
						else padding_mask = ffff;
					}
					//Load weights
					vWeights=0;
					nCurrWt = *filter_buff;
					filter_buff+=nOutChannels;
					PDX_REP_2MX16_T(vWeights, (xb_vec2Mx16)nCurrWt,Lane, padding_mask);//load current weight and replicate the same in all lanes of the vector

					//multiply and accumulate
					PDX_MULAQW_2MX16(outacc,vInput,vWeights);

				}
//				inp += (-nKernelWidth + nInputWidth);//move to next row of inputs
				inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + ((j-1)*nInputWidth)+ (nBytesLeft<2*PDX_M)*2*PDX_M*nStrideLen);
				ina = PDX_LA_2MX8_PP (inp);
			}
			//quantization compensation
			outacc+=vBias;//add bias
			PDX_CVT32D_2MX40(last16, first16, outacc);

			//first16
			quant_acc=0;
			PDX_MULAQW_MX32(quant_acc,mult_acc,first16);
			//shift and round
			quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//
			save_reg = PDX_CVT40_MX32_L(conv_out);
			//
			temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
			//Saturate to 8 bit range output_activation_min to 127
			temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
			temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft-=PDX_M;
			temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
			padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
			PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush

			if(nBytesLeft>0){
				//last16
				quant_acc=0;
				PDX_MULAQW_MX32(quant_acc,mult_acc,last16);
				//shift and round
				quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//
				save_reg = PDX_CVT40_MX32_L(conv_out);
				//
				temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
				//Saturate to 8 bit range output_activation_min to 127
				temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
				temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft-=PDX_M;
				temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
				padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
				PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush
			}
			inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth+2*PDX_M*nStrideLen);
			ina = PDX_LA_2MX8_PP (inp);
			filter_buff =  (int8_t *)(pWeightsBuffer + (nPaddingLength-nStrideLen)*nKernelWidth*nOutChannels)+ nChannels;
		}

		//Middle rows
		for(int nOutRow = 2; nOutRow<nOutputLength-3; nOutRow++)
		{
			nBytesLeft = nOutputWidth;
			inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutRow-2)*nInputWidth*nStrideLen);//account for col padding
			ina = PDX_LA_2MX8_PP (inp);
			filter_buff =  (int8_t *)pWeightsBuffer + nChannels;
			for(int nCol = 0; nCol<nOutputWidth; nCol+=2*PDX_M)
			{
				outacc=0;
				for(int j=0; j<nKernelLength; j++)//Start from after padding
				{
					for(int k=0; k<nKernelWidth; k++)
					{
						//load inputs and add input offset
						PDX_LA16D_4MX8_XP (temp1, temp2, ina, inp, 1 );  //find intrinsic that does not update base addr
						vInput = PDX_SELI_2MX16 (temp1, temp2, PDX_SELI_16B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes - stride 2
						vInput += vInZP;

						//Padding
						if(nBytesLeft<2*PDX_M){
							if(k==nKernelWidth-1){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-2)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}
							else if(k==nKernelWidth-2 || k==nKernelWidth-3){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-1)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}
							else padding_mask = ffff;
						}
						else{
							if(k==0) padding_mask = fffc;
							else if(k==1 || k==2) padding_mask = fffe;
							else padding_mask = ffff;
						}
						//Load weights
						vWeights=0;
						nCurrWt = *filter_buff;
						filter_buff+=nOutChannels;
						PDX_REP_2MX16_T(vWeights, (xb_vec2Mx16)nCurrWt,Lane, padding_mask);//load current weight and replicate the same in all lanes of the vector

						//multiply and accumulate
						PDX_MULAQW_2MX16(outacc,vInput,vWeights);

					}
	//				inp += (-nKernelWidth + nInputWidth);//move to next row of inputs
					inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutRow-2)*nInputWidth*nStrideLen + ((j+1)*nInputWidth)+ (nBytesLeft<2*PDX_M)*2*PDX_M*nStrideLen);
					ina = PDX_LA_2MX8_PP (inp);
				}
				//quantization compensation
				outacc+=vBias;//add bias
				PDX_CVT32D_2MX40(last16, first16, outacc);

				//first16
				quant_acc=0;
				PDX_MULAQW_MX32(quant_acc,mult_acc,first16);
				//shift and round
				quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//
				save_reg = PDX_CVT40_MX32_L(conv_out);
				//
				temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
				//Saturate to 8 bit range output_activation_min to 127
				temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
				temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft-=PDX_M;
				temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
				padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
				PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush


				//last16
				if(nBytesLeft>0){
					quant_acc=0;
					PDX_MULAQW_MX32(quant_acc,mult_acc,last16);
					//shift and round
					quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
					//round and shift and saturate
					conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
					//add output zero point
					conv_out += vOutZP;
					//
					save_reg = PDX_CVT40_MX32_L(conv_out);
					//
					temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
					//Saturate to 8 bit range output_activation_min to 127
					temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
					temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
					nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
					nBytesLeft-=PDX_M;
					temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
					padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
					PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
					//to 16-way 8-bit signed, forward post-increment addressing mode
					PDX_SAPOS_2MX8_FP(outa,outp);//flush
				}
				inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutRow-2)*nInputWidth*nStrideLen + 2*PDX_M*nStrideLen);//account for col padding
				ina = PDX_LA_2MX8_PP (inp);
				filter_buff =  (int8_t *)pWeightsBuffer + nChannels;
			}
		}

		//Second to last row - one row padded at the end
		nBytesLeft = nOutputWidth;
		inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutputLength-3-2)*nInputWidth*nStrideLen);//account for col padding
		ina = PDX_LA_2MX8_PP (inp);
		filter_buff =  (int8_t *)pWeightsBuffer + nChannels;
		for(int nCol = 0; nCol<nOutputWidth; nCol+=2*PDX_M)
		{
			outacc=0;
			for(int j=0; j<nKernelLength-1; j++)//Start from after padding
			{
				for(int k=0; k<nKernelWidth; k++)
				{
					//load inputs and add input offset
					PDX_LA16D_4MX8_XP (temp1, temp2, ina, inp, 1 );  //find intrinsic that does not update base addr
					vInput = PDX_SELI_2MX16 (temp1, temp2, PDX_SELI_16B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes - stride 2
					vInput += vInZP;

					//Padding
					if(nBytesLeft<2*PDX_M){
						if(k==nKernelWidth-1){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-2)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}
						else if(k==nKernelWidth-2 || k==nKernelWidth-3){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-1)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}
						else padding_mask = ffff;
					}
					else{
						if(k==0) padding_mask = fffc;
						else if(k==1 || k==2) padding_mask = fffe;
						else padding_mask = ffff;
					}
					//Load weights
					vWeights=0;
					nCurrWt = *filter_buff;
					filter_buff+=nOutChannels;
					PDX_REP_2MX16_T(vWeights, (xb_vec2Mx16)nCurrWt,Lane, padding_mask);//load current weight and replicate the same in all lanes of the vector

					//multiply and accumulate
					PDX_MULAQW_2MX16(outacc,vInput,vWeights);

				}
//				inp += (-nKernelWidth + nInputWidth);//move to next row of inputs
				inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutputLength-3-2)*nInputWidth*nStrideLen + ((j+1)*nInputWidth)+ (nBytesLeft<2*PDX_M)*2*PDX_M*nStrideLen);
				ina = PDX_LA_2MX8_PP (inp);
			}
			//quantization compensation
			outacc+=vBias;//add bias
			PDX_CVT32D_2MX40(last16, first16, outacc);

			//first16
			quant_acc=0;
			PDX_MULAQW_MX32(quant_acc,mult_acc,first16);
			//shift and round
			quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//
			save_reg = PDX_CVT40_MX32_L(conv_out);
			//
			temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
			//Saturate to 8 bit range output_activation_min to 127
			temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
			temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft-=PDX_M;
			temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
			padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
			PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush


			//last16
			if(nBytesLeft>0){
				quant_acc=0;
				PDX_MULAQW_MX32(quant_acc,mult_acc,last16);
				//shift and round
				quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//
				save_reg = PDX_CVT40_MX32_L(conv_out);
				//
				temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
				//Saturate to 8 bit range output_activation_min to 127
				temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
				temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft-=PDX_M;
				temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
				padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
				PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush
			}
			inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutputLength-3-2)*nInputWidth*nStrideLen + 2*PDX_M*nStrideLen);//account for col padding
			ina = PDX_LA_2MX8_PP (inp);
			filter_buff =  (int8_t *)pWeightsBuffer + nChannels;
		}

		//Penultimate row
		nBytesLeft = nOutputWidth;
		inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutputLength-4)*nInputWidth*nStrideLen);//account for col padding
		ina = PDX_LA_2MX8_PP (inp);
		filter_buff =  (int8_t *)pWeightsBuffer + nChannels;
		for(int nCol = 0; nCol<nOutputWidth; nCol+=2*PDX_M)
		{
			outacc=0;
			for(int j=0; j<nKernelLength-3; j++)//Start from after padding
			{
				for(int k=0; k<nKernelWidth; k++)
				{
					//load inputs and add input offset
					PDX_LA16D_4MX8_XP (temp1, temp2, ina, inp, 1 );  //find intrinsic that does not update base addr
					vInput = PDX_SELI_2MX16 (temp1, temp2, PDX_SELI_16B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes - stride 2
					vInput += vInZP;

					//Padding
					if(nBytesLeft<2*PDX_M){
						if(k==nKernelWidth-1){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-2)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}
						else if(k==nKernelWidth-2 || k==nKernelWidth-3){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-1)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}
						else padding_mask = ffff;
					}
					else{
						if(k==0) padding_mask = fffc;
						else if(k==1 || k==2) padding_mask = fffe;
						else padding_mask = ffff;
					}
					//Load weights
					vWeights=0;
					nCurrWt = *filter_buff;
					filter_buff+=nOutChannels;
					PDX_REP_2MX16_T(vWeights, (xb_vec2Mx16)nCurrWt,Lane, padding_mask);//load current weight and replicate the same in all lanes of the vector

					//multiply and accumulate
					PDX_MULAQW_2MX16(outacc,vInput,vWeights);

				}
//				inp += (-nKernelWidth + nInputWidth);//move to next row of inputs
				inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutputLength-4)*nInputWidth*nStrideLen + ((j+1)*nInputWidth)+ (nBytesLeft<2*PDX_M)*2*PDX_M*nStrideLen);
				ina = PDX_LA_2MX8_PP (inp);
			}
			//quantization compensation
			outacc+=vBias;//add bias
			PDX_CVT32D_2MX40(last16, first16, outacc);

			//first16
			quant_acc=0;
			PDX_MULAQW_MX32(quant_acc,mult_acc,first16);
			//shift and round
			quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//
			save_reg = PDX_CVT40_MX32_L(conv_out);
			//
			temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
			//Saturate to 8 bit range output_activation_min to 127
			temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
			temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft-=PDX_M;
			temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
			padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
			PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush

			if(nBytesLeft>0){
				//last16
				quant_acc=0;
				PDX_MULAQW_MX32(quant_acc,mult_acc,last16);
				//shift and round
				quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//
				save_reg = PDX_CVT40_MX32_L(conv_out);
				//
				temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
				//Saturate to 8 bit range output_activation_min to 127
				temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
				temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft-=PDX_M;
				temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
				padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
				PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush
			}
			inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutputLength-4)*nInputWidth*nStrideLen + 2*PDX_M*nStrideLen);//account for col padding
			ina = PDX_LA_2MX8_PP (inp);
			filter_buff =  (int8_t *)pWeightsBuffer + nChannels;
		}
		//Last row
		nBytesLeft = nOutputWidth;
		inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutputLength-3)*nInputWidth*nStrideLen);//account for col padding
		ina = PDX_LA_2MX8_PP (inp);
		filter_buff =  (int8_t *)pWeightsBuffer + nChannels;
		for(int nCol = 0; nCol<nOutputWidth; nCol+=2*PDX_M)
		{
			outacc=0;
			for(int j=0; j<nKernelLength-5; j++)//Start from after padding
			{
				for(int k=0; k<nKernelWidth; k++)
				{
					//load inputs and add input offset
					PDX_LA16D_4MX8_XP (temp1, temp2, ina, inp, 1 );  //find intrinsic that does not update base addr
					vInput = PDX_SELI_2MX16 (temp1, temp2, PDX_SELI_16B_EXTRACT_1_OF_2_OFF_0);// Get all the even bytes - stride 2
					vInput += vInZP;

					//Padding
					if(nBytesLeft<2*PDX_M){
						if(k==nKernelWidth-1){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-2)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}
						else if(k==nKernelWidth-2 || k==nKernelWidth-3){temp_mask = PDX_MOVB_AU32((0b1<<(nBytesLeft-1)) - 1);padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);}
						else padding_mask = ffff;
					}
					else{
						if(k==0) padding_mask = fffc;
						else if(k==1 || k==2) padding_mask = fffe;
						else padding_mask = ffff;
					}
					//Load weights
					vWeights=0;
					nCurrWt = *filter_buff;
					filter_buff+=nOutChannels;
					PDX_REP_2MX16_T(vWeights, (xb_vec2Mx16)nCurrWt,Lane, padding_mask);//load current weight and replicate the same in all lanes of the vector

					//multiply and accumulate
					PDX_MULAQW_2MX16(outacc,vInput,vWeights);

				}
//				inp += (-nKernelWidth + nInputWidth);//move to next row of inputs
				inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutputLength-3)*nInputWidth*nStrideLen + ((j+1)*nInputWidth)+ (nBytesLeft<2*PDX_M)*2*PDX_M*nStrideLen);
				ina = PDX_LA_2MX8_PP (inp);
			}
			//quantization compensation
			outacc+=vBias;//add bias
			PDX_CVT32D_2MX40(last16, first16, outacc);

			//first16
			quant_acc=0;
			PDX_MULAQW_MX32(quant_acc,mult_acc,first16);
			//shift and round
			quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
			//round and shift and saturate
			conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
			//add output zero point
			conv_out += vOutZP;
			//
			save_reg = PDX_CVT40_MX32_L(conv_out);
			//
			temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
			//Saturate to 8 bit range output_activation_min to 127
			temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
			temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
			nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
			nBytesLeft-=PDX_M;
			temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
			padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
			PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
			//to 16-way 8-bit signed, forward post-increment addressing mode
			PDX_SAPOS_2MX8_FP(outa,outp);//flush

			if(nBytesLeft>0){
				//last16
				quant_acc=0;
				PDX_MULAQW_MX32(quant_acc,mult_acc,last16);
				//shift and round
				quant_acc = PDX_SLS_MX80(quant_acc,shift);//saturating left shift, right shift if negative
				//round and shift and saturate
				conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);//shifts by 16 bits and symmetric rounding with saturation
				//add output zero point
				conv_out += vOutZP;
				//
				save_reg = PDX_CVT40_MX32_L(conv_out);
				//
				temp_reg =PDX_PACKIV_2MX40  (save_reg, 0);
				//Saturate to 8 bit range output_activation_min to 127
				temp_reg = PDX_MIN_2MX16(temp_reg,vmax);
				temp_reg = PDX_MAX_2MX16(temp_reg,vmin);
				nBytesToWrite = nBytesLeft - PDX_M > 0 ? PDX_M : nBytesLeft;
				nBytesLeft-=PDX_M;
				temp_mask = PDX_MOVB_AU32((0b1<<(nBytesToWrite)) - 1);
				padding_mask = PDX_CVTBB2M_B4M_L(temp_mask);
				PDX_SAV16_2MX8_XP_T(temp_reg, outa, outp,nBytesToWrite, temp_mask, padding_mask);//16-way 16-bit signed Aligning vector register variable-length store intrinsic, converting
				//to 16-way 8-bit signed, forward post-increment addressing mode
				PDX_SAPOS_2MX8_FP(outa,outp);//flush
			}
			inp = (xb_vec2Mx8 *) (pInputBuffer-nPaddingWidth + (nOutputLength-3)*nInputWidth*nStrideLen+ 2*PDX_M*nStrideLen);//account for col padding
			ina = PDX_LA_2MX8_PP (inp);
			filter_buff =  (int8_t *)pWeightsBuffer + nChannels;
		}
	}
}


void fullyConnected_asm_16bit(
	const ADI_16BIT_CONV_BUFF_DATATYPE* pInputBuffer,
	const ADI_WEIGHTS_DATATYPE* pWeightsBuffer,
	const ADI_CONV_BUFF_DATATYPE* pBiasBuffer,
	ADI_16BIT_CONV_BUFF_DATATYPE* pOutputBuffer,
	ADI_CONV_BUFF_DATATYPE nFilterDepth,
	ADI_CONV_BUFF_DATATYPE nOutsize,
	ADI_CONV_BUFF_DATATYPE nBatches,
	ADI_QMULTIPLIER_DATATYPE nQuantizedMultiplier,
	ADI_CONV_BUFF_DATATYPE nQuantizedShift,
	ADI_CONV_BUFF_DATATYPE nInputOffset,
	ADI_CONV_BUFF_DATATYPE nFilterOffset,
	ADI_CONV_BUFF_DATATYPE nOutputOffset,
	ADI_CONV_BUFF_DATATYPE output_activation_min,
	ADI_CONV_BUFF_DATATYPE output_activation_max)
{
	int16_t* __restrict outp = (int16_t*) pOutputBuffer;

	const immediate Lane=0;
	//Defining the input and filter offsets
	xb_vec2Mx16 vInZP = PDX_REP_2MX16((xb_vec2Mx16)nInputOffset,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx16 vFilterZP = PDX_REP_2MX16((xb_vec2Mx16)nFilterOffset,Lane);//Replicates the lane of data specified, across all lanes of a vector register

	xb_vec2Mx16 vin,vwt;
	xb_int32 temp;
	xb_int40 sat_sum;
	xb_int80 product;

	vbool4M temp_mask;
	vbool2M acc_mask, ffff;

	temp_mask = PDX_MOVB_AU32(0xFFFFFFFF);
	PDX_CVTBB2M_B4M(ffff, ffff, temp_mask);

	int32_t nPixProcessed=0;
	xb_vec2Mx40 acc = 0;

	if(nFilterDepth % 16){
		int32_t nFilterDepth_16mul = nFilterDepth - (nFilterDepth % 16);
		for (int b = 0; b < nBatches; b++){
			//No of filter is equals to the nOutsize
			for (int32_t nChannelCnt = 0; nChannelCnt < nOutsize; nChannelCnt++)
			{
				acc = 0;//reset accumulator

				xb_vec2Mx16 *inp = (xb_vec2Mx16 *)(pInputBuffer + b*nFilterDepth);	//Reinitialise input pointer for each output pixel
				valign ina; // define align vector
				ina=PDX_LA_2MX16_PP (inp); // prime, NOP if a[] is aligned

				xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + nFilterDepth*nChannelCnt); //Move to next filter for each output pixel
				valign wta;	// define align vector
				wta=PDX_LA_2MX8_PP (wtp);

				//for all the input pixels
				for (nPixProcessed= 0; nFilterDepth - nPixProcessed > 2*PDX_M; nPixProcessed += (2*PDX_M))
				{
					PDX_LA_2MX16_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
					PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
					vin+=vInZP;		//Add input offset
					vwt+=vFilterZP;	//Add filter offset

					PDX_MULAQW_2MX16(acc,vwt,vin);
				}

				PDX_LA_2MX16_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
				PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
				vin+=vInZP;		//Add input offset
				vwt+=vFilterZP;	//Add filter offset

				temp_mask = PDX_MOVB_AU32((0b1<<(nFilterDepth % 16)) - 1);
				acc_mask = PDX_CVTBB2M_B4M_L(temp_mask);
				//multiply and accumulate
				PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);

				sat_sum = PDX_RADD_2MX40(acc);									//PDX_RADD_2MX40: Adds across all 16lanes of acc and returns sum
				//adding bias<<1 to compensate for sign bit during multiplication
				//doubling index for bias buffer to account for 32bit bias instead of 64bit
				if(pBiasBuffer)	sat_sum += (xb_int40)(pBiasBuffer[nChannelCnt*2]<<1);
				temp = (xb_int32)((int32_t)((int64_t)PDX_CVT64_40(sat_sum)));	//convert 40bit var into 32bit to perform multiplication

				product = PDX_MULW_32(temp, (uint32_t)nQuantizedMultiplier);	//multiply with the quantization multiplier; product(80bit) = temp(32bit) * nQuantizedMultiplier(32bit)
				product =  PDX_SLA_80(product, (xb_int32)nQuantizedShift);		//shift result by quantization multiplier
				temp = PDX_PACKQSRV_80(product,2);								//packs 80bit product into 32bit var with saturation and rounding
				temp+= (xb_int32)nOutputOffset;									//add output offset
				temp = (MAX(MIN(temp, (xb_int32)output_activation_max), (xb_int32)output_activation_min));//saturation check to store result
				*outp++ =(int16_t)((int32_t)temp);								//store result as 16-bit data
			}
		}
	}
	else{
		for (int b = 0; b < nBatches; b++){
			//No of filter is equals to the nOutsize
			for (int32_t nChannelCnt = 0; nChannelCnt < nOutsize; nChannelCnt++)
			{
				acc = 0;//reset accumulator

				xb_vec2Mx16 * inp = (xb_vec2Mx16 *)(pInputBuffer + b*nFilterDepth);	//Reinitialise input pointer for each output pixel
				valign ina; // define align vector
				ina=PDX_LA_2MX16_PP (inp); // prime, NOP if a[] is aligned

				xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + nFilterDepth*nChannelCnt*2); //Move to next filter for each output pixel
				valign wta;	// define align vector
				wta=PDX_LA_2MX8_PP (wtp);

				//for all the input pixels
				for (int32_t nFilterCnt = 0; nFilterCnt < nFilterDepth; nFilterCnt += (2*PDX_M))
				{
					PDX_LA_2MX16_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
					PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M);
					vin+=vInZP;		//Add input offset
					vwt+=vFilterZP;	//Add filter offset

					PDX_MULAQW_2MX16(acc,vwt,vin);
				}
				sat_sum = PDX_RADD_2MX40(acc);									//PDX_RADD_2MX40: Adds across all 16lanes of acc and returns sum
				//adding bias<<1 to compensate for sign bit during multiplication
				//doubling index for bias buffer to account for 32bit bias instead of 64bit
				if(pBiasBuffer)	sat_sum += (xb_int40)(pBiasBuffer[nChannelCnt*2]<<1);
				temp = (xb_int32)((int32_t)((int64_t)PDX_CVT64_40(sat_sum)));	//convert 40bit var into 32bit to perform multiplication

				product = PDX_MULW_32(temp, (uint32_t)nQuantizedMultiplier);	//multiply with the quantization multiplier; product(80bit) = temp(32bit) * nQuantizedMultiplier(32bit)
				product =  PDX_SLA_80(product, (xb_int32)nQuantizedShift);		//shift result by quantization multiplier
				temp = PDX_PACKQSRV_80(product,2);								//packs 80bit product into 32bit var with saturation and rounding
				temp+= (xb_int32)nOutputOffset;									//add output offset
				temp = (MAX(MIN(temp, (xb_int32)output_activation_max), (xb_int32)output_activation_min));//saturation check to store result
				*outp++ =(int16_t)((int32_t)temp);								//store result as 16-bit data
			}
		}
	}
}

void fullyConnected_asm_8bit(
	const ADI_ACTIVATION_DATATYPE* pInputBuffer,
	const ADI_WEIGHTS_DATATYPE* pWeightsBuffer,
	const ADI_CONV_BUFF_DATATYPE* pBiasBuffer,
	ADI_ACTIVATION_DATATYPE* pOutputBuffer,
	ADI_CONV_BUFF_DATATYPE nFilterDepth,
	ADI_CONV_BUFF_DATATYPE nOutsize,
	ADI_CONV_BUFF_DATATYPE nBatches,
	ADI_QMULTIPLIER_DATATYPE nQuantizedMultiplier,
	ADI_CONV_BUFF_DATATYPE nQuantizedShift,
	ADI_CONV_BUFF_DATATYPE nInputOffset,
	ADI_CONV_BUFF_DATATYPE nFilterOffset,
	ADI_CONV_BUFF_DATATYPE nOutputOffset,
	ADI_CONV_BUFF_DATATYPE output_activation_min,
	ADI_CONV_BUFF_DATATYPE output_activation_max)
{
	int8_t* __restrict outp = (int8_t*) pOutputBuffer;

	const immediate Lane=0;
	//Defining the input and filter offsets
	xb_vec2Mx16 vInZP = PDX_REP_2MX16((xb_vec2Mx16)nInputOffset,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx16 vFilterZP = PDX_REP_2MX16((xb_vec2Mx16)nFilterOffset,Lane);//Replicates the lane of data specified, across all lanes of a vector register

	xb_vec2Mx16 vin,vwt;
	xb_int32 temp;
	xb_int40 sat_sum;
	xb_int80 product;

	vbool4M temp_mask;
	vbool2M acc_mask, ffff;

	temp_mask = PDX_MOVB_AU32(0xFFFFFFFF);
	PDX_CVTBB2M_B4M(ffff, ffff, temp_mask);

	int32_t nPixProcessed=0;

	xb_vec2Mx40 acc = 0;
	xb_vec2Mx8 *inp = (xb_vec2Mx8 *)pInputBuffer;
	if(nFilterDepth % 16){
		int32_t nFilterDepth_16mul = nFilterDepth - (nFilterDepth % 16);
		for (int b = 0; b < nBatches; b++){
			//No of filter is equals to the nOutsize
			for (int32_t nChannelCnt = 0; nChannelCnt < nOutsize; nChannelCnt++)
			{
				acc = 0;//reset accumulator

				inp = (xb_vec2Mx8 *)(pInputBuffer + b*nFilterDepth);	//Reinitialise input pointer for each output pixel
				valign ina; // define align vector
				ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

				xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + nFilterDepth*nChannelCnt); //Move to next filter for each output pixel
				valign wta;	// define align vector
				wta=PDX_LA_2MX8_PP (wtp);

				//for all the input pixels
				for (nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
				{
					PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
					PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
					vin+=vInZP;		//Add input offset
					vwt+=vFilterZP;	//Add filter offset

					PDX_MULAQW_2MX16(acc,vwt,vin);

				}

				PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
				PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
				vin+=vInZP;		//Add input offset
				vwt+=vFilterZP;	//Add filter offset

				temp_mask = PDX_MOVB_AU32((0b1<<((nFilterDepth % 16))) - 1);
				acc_mask = PDX_CVTBB2M_B4M_L(temp_mask);
				//multiply and accumulate
				PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);

				sat_sum = PDX_RADD_2MX40(acc);									//PDX_RADD_2MX40: Adds across all 16lanes of acc and returns sum
				if(pBiasBuffer)	sat_sum += (xb_int40)(pBiasBuffer[nChannelCnt]<<1);				//adding bias>>1 to compensate for sign bit during multiplication
				temp = (xb_int32)((int32_t)((int64_t)PDX_CVT64_40(sat_sum)));	//convert 40bit var into 32bit to perform multiplication

				product = PDX_MULW_32(temp, (uint32_t)nQuantizedMultiplier);	//multiply with the quantization multiplier; product(80bit) = temp(32bit) * nQuantizedMultiplier(32bit)
				product =  PDX_SLA_80(product, (xb_int32)nQuantizedShift);		//shift result by quantization multiplier
				temp = PDX_PACKQSRV_80(product,2);								//packs 80bit product into 32bit var with saturation and rounding
				temp+= (xb_int32)nOutputOffset;									//add output offset
				temp = (MAX(MIN(temp, (xb_int32)output_activation_max), (xb_int32)output_activation_min));//8bit saturation check to store result
				*outp++ =(int8_t)((int32_t)temp);								//store result as 8-bit data
			}
		}
	}
	else{
		for (int b = 0; b < nBatches; b++){
			//No of filter is equals to the nOutsize
			for (int32_t nChannelCnt = 0; nChannelCnt < nOutsize; nChannelCnt++)
			{
				acc = 0;//reset accumulator

				inp = (xb_vec2Mx8 *)(pInputBuffer + b*nFilterDepth);	//Reinitialise input pointer for each output pixel
				valign ina; // define align vector
				ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

				xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + nFilterDepth*nChannelCnt); //Move to next filter for each output pixel
				valign wta;	// define align vector
				wta=PDX_LA_2MX8_PP (wtp);

				//for all the input pixels
				for (int32_t nFilterCnt = 0; nFilterCnt < nFilterDepth; nFilterCnt += (2*PDX_M))
				{
					PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
					PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
					vin+=vInZP;		//Add input offset
					vwt+=vFilterZP;	//Add filter offset

					PDX_MULAQW_2MX16(acc,vwt,vin);

				}
				sat_sum = PDX_RADD_2MX40(acc);									//PDX_RADD_2MX40: Adds across all 16lanes of acc and returns sum
				if(pBiasBuffer)	sat_sum += (xb_int40)(pBiasBuffer[nChannelCnt]<<1);				//adding bias>>1 to compensate for sign bit during multiplication
				temp = (xb_int32)((int32_t)((int64_t)PDX_CVT64_40(sat_sum)));	//convert 40bit var into 32bit to perform multiplication

				product = PDX_MULW_32(temp, (uint32_t)nQuantizedMultiplier);	//multiply with the quantization multiplier; product(80bit) = temp(32bit) * nQuantizedMultiplier(32bit)
				product =  PDX_SLA_80(product, (xb_int32)nQuantizedShift);		//shift result by quantization multiplier
				temp = PDX_PACKQSRV_80(product,2);								//packs 80bit product into 32bit var with saturation and rounding
				temp+= (xb_int32)nOutputOffset;									//add output offset
				temp = (MAX(MIN(temp, (xb_int32)output_activation_max), (xb_int32)output_activation_min));//8bit saturation check to store result
				*outp++ =(int8_t)((int32_t)temp);								//store result as 8-bit data
			}
		}
	}
}

void MulElementwise_asm(
	const ADI_16BIT_CONV_BUFF_DATATYPE* pInput1,
	const ADI_16BIT_CONV_BUFF_DATATYPE* pInput2,
	ADI_16BIT_CONV_BUFF_DATATYPE* pOutput,
	ADI_CONV_BUFF_DATATYPE nSize,
	ADI_QMULTIPLIER_DATATYPE nQuantizedMultiplier,
	ADI_CONV_BUFF_DATATYPE nQuantizedShift,
	ADI_CONV_BUFF_DATATYPE nInOffset1,
	ADI_CONV_BUFF_DATATYPE nInOffset2,
	ADI_CONV_BUFF_DATATYPE nOutOffset,
	ADI_CONV_BUFF_DATATYPE output_activation_min,
	ADI_CONV_BUFF_DATATYPE output_activation_max
)
{
	const immediate Lane = 0;
	const immediate round_mode = 2;

	xb_vec2Mx16 vInOff1 = PDX_REP_2MX16((xb_vec2Mx16)nInOffset1,Lane);
	xb_vec2Mx16 vInOff2 = PDX_REP_2MX16((xb_vec2Mx16)nInOffset2,Lane);
	xb_vec2Mx16 vOutOff = PDX_REP_2MX16((xb_vec2Mx16)nOutOffset,Lane);

	xb_vec2Mx16 vmin = PDX_REP_2MX16((xb_vec2Mx16)output_activation_min,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx16 vmax = PDX_REP_2MX16((xb_vec2Mx16)output_activation_max,Lane);//Replicates the lane of data specified, across all lanes of a vector register

	xb_vec2Mx16 *inp1 = (xb_vec2Mx16 *)pInput1;
	xb_vec2Mx16 *inp2 = (xb_vec2Mx16 *)pInput2;
	valign ina1=PDX_LA_2MX16_PP (inp1);// define align vector
	valign ina2=PDX_LA_2MX16_PP (inp2);// define align vector

	valign outa = PDX_Z_ALIGN();
	xb_vec2Mx16 *outp = (xb_vec2Mx16 *)pOutput;

	xb_vec2Mx16 shift = PDX_REP_2MX16((xb_vec2Mx16)nQuantizedShift,Lane);
	xb_vec2Mx16 multiplier = PDX_REP_2MX16((xb_vec2Mx16)((nQuantizedMultiplier + (1 << 15)) >> 16),Lane);

	xb_vec2Mx16 vin1, vin2, product;
	xb_vec2Mx40 acc;

	int nElementsProcessed;
	for (nElementsProcessed = 0; (nSize - nElementsProcessed) >= (2*PDX_M);) {
		//reset acc
		acc=0;
		//load inputs
		PDX_LA_2MX16_XP (vin1, ina1, inp1, 2*PDX_M * sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
		PDX_LA_2MX16_XP (vin2, ina2, inp2, 2*PDX_M * sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));

		//add offsets
		vin1+=vInOff1;
		vin2+=vInOff2;
		//multiply
		PDX_MULAQW_2MX16(acc, vin1, vin2);
		//pack to 16bit
		product = PDX_PACKQSRV_2MX40(acc, round_mode);
		//reset acc
		acc=0;
		//multiply by multipler
		PDX_MULAW_2MX16(acc, multiplier, product);
		//shift
		acc = PDX_SLS_2MX40(acc,shift);
		//saturate and save to 16bit
		product = PDX_PACKSIV_2MX40(acc, 0);
		//add offset
		product +=vOutOff;
		//saturate
		product = PDX_MIN_2MX16(product,vmax);
		product = PDX_MAX_2MX16(product,vmin);
		//save product and flush vector
		PDX_SAV_2MX16_XP(product,outa,outp, 2*PDX_M * sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
		PDX_SAPOS_2MX16_FP(outa,outp);//flush
		nElementsProcessed+=(2*PDX_M);
	}
	if((nSize - nElementsProcessed)>0){
		//reset acc
		acc=0;
		//load inputs
		PDX_LA_2MX16_XP (vin1, ina1, inp1,0);
		PDX_LA_2MX16_XP (vin2, ina2, inp2,0);

		//add offsets
		vin1+=vInOff1;
		vin2+=vInOff2;
		//multiply
		PDX_MULAQW_2MX16(acc, vin1, vin2);
		//pack to 16bit
		product = PDX_PACKQSRV_2MX40(acc, round_mode);
		//reset acc
		acc=0;
		//multiply by multipler
		PDX_MULAW_2MX16(acc, multiplier, product);
		//shift
		acc = PDX_SLS_2MX40(acc,shift);
		//saturate and save to 16bit
		product = PDX_PACKSIV_2MX40(acc, 0);
		//add offset
		product +=vOutOff;
		//saturate
		product = PDX_MIN_2MX16(product,vmax);
		product = PDX_MAX_2MX16(product,vmin);
		//save product and flush vector
		PDX_SAV_2MX16_XP(product,outa,outp, (nSize - nElementsProcessed)* sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
		PDX_SAPOS_2MX16_FP(outa,outp);//flush
	}
}

void AddElementWise_asm(
	const ADI_16BIT_CONV_BUFF_DATATYPE* pInput1,
	const ADI_16BIT_CONV_BUFF_DATATYPE* pInput2,
	ADI_CONV_BUFF_DATATYPE nBatches,
	ADI_CONV_BUFF_DATATYPE nInputLen,
	ADI_16BIT_CONV_BUFF_DATATYPE* pOutput
)
{
	xb_vec2Mx40 acc = 0;
	xb_vec2Mx16 *inp1 = (xb_vec2Mx16 *)pInput1;
	xb_vec2Mx16 *inp2 = (xb_vec2Mx16 *)pInput2;
	valign ina1, ina2; // define align vector
	ina1=PDX_LA_2MX16_PP (inp1);
	ina2=PDX_LA_2MX16_PP (inp2);

	valign outa = PDX_Z_ALIGN();
	xb_vec2Mx16 *outp = (xb_vec2Mx16 *)pOutput;
//	valign outa = PDX_LA_2MX16_PP (outp);

	xb_vec2Mx16 vin1, vin2, sum;

	int nPixLeft = nInputLen;

	if(nInputLen%16){
		for (int batch = 0; batch < nBatches; batch++) {
			//reset input pointer for each batch
			inp1 = (xb_vec2Mx16 *)(pInput1 + batch*nInputLen);
			inp2 = (xb_vec2Mx16 *)(pInput2 + batch*nInputLen);
			for (nPixLeft = nInputLen; nPixLeft > 2*PDX_M; ){
				//load input
				PDX_LA_2MX16_XP (vin1, ina1, inp1, 2*PDX_M* sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
				PDX_LA_2MX16_XP (vin2, ina2, inp2, 2*PDX_M* sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
				//add with saturation
				sum = PDX_ADDS_2MX16(vin1, vin2);
				//save sum and flush vector
				PDX_SAV_2MX16_XP(sum,outa,outp, 2*PDX_M* sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
				PDX_SAPOS_2MX16_FP(outa,outp);//flush
				nPixLeft-= (2*PDX_M);
			}
			//load input
			PDX_LA_2MX16_XP (vin1, ina1, inp1, 2*PDX_M* sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
			PDX_LA_2MX16_XP (vin2, ina2, inp2, 2*PDX_M* sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
			//add with saturation
			sum = PDX_ADDS_2MX16(vin1, vin2);
			//save sum and flush vector
			PDX_SAV_2MX16_XP(sum,outa,outp, nPixLeft* sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
			PDX_SAPOS_2MX16_FP(outa,outp);//flush
		}
	}
	else{
		for (int batch = 0; batch < nBatches; batch++) {
			//reset input pointer for each batch
			inp1 = (xb_vec2Mx16 *)(pInput1 + batch*nInputLen);
			inp2 = (xb_vec2Mx16 *)(pInput2 + batch*nInputLen);
			for (int i = 0; i < nInputLen; i+= (2*PDX_M)){
				//load input
				PDX_LA_2MX16_XP (vin1, ina1, inp1, 2*PDX_M* sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
				PDX_LA_2MX16_XP (vin2, ina2, inp2, 2*PDX_M* sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
				//add with saturation
				sum = PDX_ADDS_2MX16(vin1, vin2);
				//save sum and flush vector
				PDX_SAV_2MX16_XP(sum,outa,outp, 2*PDX_M* sizeof(ADI_16BIT_CONV_BUFF_DATATYPE));
				PDX_SAPOS_2MX16_FP(outa,outp);//flush
			}
		}
	}
}


void ReluQuantized_asm_8bit(
	const ADI_ACTIVATION_DATATYPE* pInput,
	ADI_ACTIVATION_DATATYPE* pOutput,
	const ADI_QMULTIPLIER_DATATYPE nSize,
	ADI_QMULTIPLIER_DATATYPE nQuantizedMultiplier,
	ADI_CONV_BUFF_DATATYPE nQuantizedShift,
	ADI_CONV_BUFF_DATATYPE nInOffset,
	ADI_CONV_BUFF_DATATYPE nOutOffset,
	ADI_CONV_BUFF_DATATYPE output_activation_min,
	ADI_CONV_BUFF_DATATYPE output_activation_max
)
{
	const immediate Lane = 0;
	const immediate round_mode = 2;

	xb_vec2Mx16 vInOff = PDX_REP_2MX16((xb_vec2Mx16)nInOffset,Lane);
	xb_vec2Mx16 vOutOff = PDX_REP_2MX16((xb_vec2Mx16)nOutOffset,Lane);

	xb_vec2Mx16 vmin = PDX_REP_2MX16((xb_vec2Mx16)output_activation_min,Lane);//Replicates the lane of data specified, across all lanes of a vector register
	xb_vec2Mx16 vmax = PDX_REP_2MX16((xb_vec2Mx16)output_activation_max,Lane);//Replicates the lane of data specified, across all lanes of a vector register

	xb_vec2Mx8 *inp = (xb_vec2Mx8 *)pInput;
	valign ina=PDX_LA_2MX8_PP (inp);// define align vector

	valign outa = PDX_Z_ALIGN();
	xb_vec2Mx8 *outp = (xb_vec2Mx8 *)pOutput;

	xb_vec2Mx16 shift = PDX_REP_2MX16((xb_vec2Mx16)(nQuantizedShift+1),Lane);
	xb_vec2Mx16 multiplier = PDX_REP_2MX16((xb_vec2Mx16)((nQuantizedMultiplier + (1 << 15)) >> 16),Lane);

	xb_vec2Mx16 vin, result;
	xb_vec2Mx40 acc;

	int nElementsProcessed;
	for (nElementsProcessed = 0; (nSize - nElementsProcessed) >= (2*PDX_M);) {
		//load inputs
		PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M );
		vin-=vInOff;
		//reset acc
		acc=0;
		//multiply by multipler
		PDX_MULAW_2MX16(acc, multiplier, vin);
		//shift
		acc = PDX_SLS_2MX40(acc,shift);
		//saturate and save to 16bit
		result = PDX_PACKQSRV_2MX40(acc, round_mode);
		//add offset
		result +=vOutOff;
		//saturate
		result = PDX_MIN_2MX16(result,vmax);
		result = PDX_MAX_2MX16(result,vmin);
		//save output as 8-bit data
		PDX_SAV16_2MX8_XP(result, outa, outp,2*PDX_M);
		PDX_SAPOS_2MX8_FP(outa,outp);//flush
		nElementsProcessed += (2*PDX_M);
	}
	if((nSize - nElementsProcessed)>0){
		//load inputs
		PDX_LA16_2MX8_XP (vin, ina, inp, 0);
		vin-=vInOff;
		//reset acc
		acc=0;
		//multiply by multipler
		PDX_MULAW_2MX16(acc, multiplier, vin);
		//shift
		acc = PDX_SLS_2MX40(acc,shift);
		//saturate and save to 16bit
		result = PDX_PACKQSRV_2MX40(acc, round_mode);
		//add offset
		result +=vOutOff;
		//saturate
		result = PDX_MIN_2MX16(result,vmax);
		result = PDX_MAX_2MX16(result,vmin);
		//save output as 8-bit data
		PDX_SAV16_2MX8_XP(result, outa, outp,(nSize - nElementsProcessed));
		PDX_SAPOS_2MX8_FP(outa,outp);//flush
	}
}


void Tanh_opt_Int16(
		ADI_CONV_BUFF_DATATYPE nInputMultiplier,
		ADI_CONV_BUFF_DATATYPE nInputLeftShift,
		ADI_CONV_BUFF_DATATYPE nLength,
		const ADI_16BIT_CONV_BUFF_DATATYPE* pInputData,
		ADI_16BIT_CONV_BUFF_DATATYPE* pOutputData)
{
    int16_t* pInput_in_q3_12 = (int16_t*)nQFormatBuffer;
    xb_vec2Mx16 *inp = (xb_vec2Mx16 *)pInputData;
    xb_vec2Mx16 *          outp;
    outp=(      xb_vec2Mx16 *)pInput_in_q3_12;
    xb_vec2Mx16 vin;
    valign ina,outa; // define align vector
    ina=PDX_LA_2MX16_PP (inp); // prime, NOP if a[] is aligned
    outa = PDX_Z_ALIGN();
    //scaling input to fit into Q3.12.
    if (nInputMultiplier == 0)
    {
    	for (int i = 0; i < nLength; i += (2*PDX_M))
    	{
    		xb_vec2Mx16 vTempInput ;
    		PDX_LA_2MX16_XP (vin, ina, inp, (2*PDX_M)*2); // load aligned, extend
    		vTempInput = PDX_SLS_2MX16(vin, nInputLeftShift);
    		PDX_SAV_2MX16_XP(vTempInput,outa,outp, (2*PDX_M)*2);
    		PDX_SAPOS_2MX16_FP( outa, outp );
    	}
    }
    else
    {
    	xb_vec2Mx40 vTempOut;
    	int32_t nTempRound = nInputLeftShift > 0 ? (1<<(nInputLeftShift-1)) : 0;
    	for (int i = 0; i < nLength; i += 2*PDX_M)
    	{
    		PDX_LA_2MX16_XP (vin, ina, inp, (2*PDX_M)*2); // load aligned, extend
    		vTempOut = PDX_MULW_2MX16(vin,nInputMultiplier);
    		vTempOut = PDX_ADD_2MX40(vTempOut,nTempRound);  //rounding multiplied scaled input with round data nTempRound for 16 bit data;
    		vTempOut = PDX_SRA_2MX40(vTempOut,nInputLeftShift);
    		PDX_SAV_2MX16_XP(PDX_PACKSIV_2MX40(vTempOut,0),outa,outp, (2*PDX_M)*2);
    		PDX_SAPOS_2MX16_FP( outa, outp );
    	}

    }

	vectanh_16b(pInput_in_q3_12, pOutputData, nLength );

	//scaling output to fit from Q7.8 to Q0.15
	xb_vec2Mx16 *out = (xb_vec2Mx16 *)pOutputData;
	outp=(      xb_vec2Mx16 *)pOutputData;
	ina=PDX_LA_2MX16_PP (out); // prime, NOP if a[] is aligned
	outa = PDX_Z_ALIGN();

	for(int i = 0; i < nLength; i += 2*PDX_M)
	{
		xb_vec2Mx16 vTempInput ;
		PDX_LA_2MX16_XP (vin, ina, out, (2*PDX_M)*2); // load aligned, extend

		vTempInput = PDX_SLSI_2MX16(vin, 7);

		PDX_SAV_2MX16_XP(vTempInput,outa,outp, (2*PDX_M)*2);
		PDX_SAPOS_2MX16_FP( outa, outp );
	 }
}

void Logistic_Int8_opt(ADI_CONV_BUFF_DATATYPE nInputZeroPoint,
		ADI_CONV_BUFF_DATATYPE nInputMultiplier,
		ADI_CONV_BUFF_DATATYPE nInputLeftShift,
		ADI_CONV_BUFF_DATATYPE nInputSize, const
		ADI_ACTIVATION_DATATYPE* pInputData,
		ADI_ACTIVATION_DATATYPE* pOutputData)
{
	// Integer bits must be in sync with Prepare() function.
	static constexpr int32_t kOutputZeroPoint = -128;

	//scaling input to fit into Q3.4
	int8_t* pInput_in_q3_4 = (int8_t*)nQFormatBuffer;
	nInputLeftShift = 4-(27 - nInputLeftShift);
	nInputMultiplier = nInputMultiplier>>24;
	xb_vec4Mx8 vInZP = PDX_REP_4MX8((xb_vec4Mx8)nInputZeroPoint,0);
	xb_vec4Mx8 vTempShift = PDX_REP_4MX8((xb_vec4Mx8)nInputLeftShift,0);
	xb_vec4Mx8 vTempMult = PDX_REP_4MX8((xb_vec4Mx8)nInputMultiplier,0);
	xb_vec4Mx8 *inp = (xb_vec4Mx8 *)pInputData;
	xb_vec4Mx8 *          outp;
	outp=(      xb_vec4Mx8 *)pInput_in_q3_4;
	xb_vec4Mx8 vin;
	valign ina,outa; // define align vector
	ina=PDX_LA_4MX8_PP (inp); // prime, NOP if a[] is aligned
	outa = PDX_Z_ALIGN();
	for (int i = 0; i < nInputSize; i += 4*PDX_M)
	{
		xb_vec4Mx20 vTempOut;
		PDX_LA_4MX8_XP (vin, ina, inp, 4*PDX_M); // load aligned, extend;
		vin += vInZP;
		vTempOut = PDX_MULW_4MX8(vin, vTempMult);
		vTempOut = PDX_SLS_4MX20(vTempOut, vTempShift);
		vTempOut = PDX_ADD_4MX20(vTempOut,64);  //rounding multiplied scaled input with round data 1<<6 for 8 bit data;
		vTempOut = PDX_SRAI_4MX20(vTempOut,7);
		PDX_SAV_4MX8_XP(PDX_PACKSIV_4MX20(vTempOut,0),outa,outp, 4*PDX_M);
		PDX_SAPOS_4MX8_FP( outa, outp );
	}

	vecsigmoid_8b((int8_t *)pInput_in_q3_4, pOutputData, nInputSize );

	//scaling output to fit from Q0.7 to Q7.8
	int16_t* output_in_q7_8 = (int16_t*)nQFormatBuffer;
	xb_vec2Mx16 vOutZP = PDX_REP_2MX16((xb_vec2Mx16)kOutputZeroPoint,0);
	xb_vec2Mx8 *out = (xb_vec2Mx8 *)pOutputData;
	xb_vec2Mx16 vout;
	xb_vec2Mx8 *          outpSig;
	outpSig=(      xb_vec2Mx8 *)pOutputData;
	valign inaSig,outaSig; // define align vector
	inaSig=PDX_LA_2MX8_PP (out); // prime, NOP if a[] is aligned
	outaSig = PDX_Z_ALIGN();
	for (int i = 0; i < nInputSize; i += 2*PDX_M)
	{
		PDX_LA16_2MX8_XP (vout, inaSig, out, (2*PDX_M)*2); // load aligned, extend
		vout = PDX_SLLI_2MX16(vout, 1);
		vout = PDX_ADD_2MX16(vout, vOutZP);
		PDX_SAV16_2MX8_XP(vout,outaSig,outpSig, (2*PDX_M)*2);
		PDX_SAPOS_2MX8_FP( outaSig, outpSig );
	}
}


void Logistic_Int16_opt(ADI_CONV_BUFF_DATATYPE nInputMultiplier,
		ADI_CONV_BUFF_DATATYPE nInputLeftShift,
		ADI_CONV_BUFF_DATATYPE nInputSize, const
		ADI_16BIT_CONV_BUFF_DATATYPE* pInputData,
		ADI_16BIT_CONV_BUFF_DATATYPE* pOutputData)
{
	int16_t* pInput_in_q3_12 = (int16_t*)nQFormatBuffer;
	xb_vec2Mx16 *inp = (xb_vec2Mx16 *)pInputData;
	xb_vec2Mx16 *          outp;
	outp=(      xb_vec2Mx16 *)pInput_in_q3_12;
	xb_vec2Mx16 vin;
	valign ina,outa; // define align vector
    ina=PDX_LA_2MX16_PP (inp); // prime, NOP if a[] is aligned
	outa = PDX_Z_ALIGN();
	if (nInputMultiplier == 0)
	{
		pInput_in_q3_12 = (int16_t*)pInputData;
	}
	else
	{
		xb_vec2Mx40 vTempOut;
		int32_t nTempRound = nInputLeftShift > 0 ? (1<<(nInputLeftShift-1)) : 0;
		for (int i = 0; i < nInputSize; i += 2*PDX_M)
		{
		    PDX_LA_2MX16_XP (vin, ina, inp, (2*PDX_M)*2); // load aligned, extend
		    vTempOut = PDX_MULW_2MX16(vin,nInputMultiplier);
		    vTempOut = PDX_ADD_2MX40(vTempOut,nTempRound);
		    vTempOut = PDX_SRA_2MX40(vTempOut,nInputLeftShift);
		    PDX_SAV_2MX16_XP(PDX_PACKSIV_2MX40(vTempOut,0),outa,outp, (2*PDX_M)*2);
		    PDX_SAPOS_2MX16_FP( outa, outp );
		}
	}

	vecsigmoid_16b(pInput_in_q3_12, pOutputData , nInputSize);

	//scaling output to fit from Q7.8 to Q0.15
	xb_vec2Mx16 *out = (xb_vec2Mx16 *)pOutputData;
	outp=(      xb_vec2Mx16 *)pOutputData;
	ina=PDX_LA_2MX16_PP (out); // prime, NOP if a[] is aligned
	outa = PDX_Z_ALIGN();
	for (int i = 0; i < nInputSize; i += 2*PDX_M)
	{
		xb_vec2Mx16 vTempInput ;
		PDX_LA_2MX16_XP (vin, ina, out, (2*PDX_M)*2); // load aligned, extend
        vTempInput = PDX_SLSI_2MX16(vin, 7);
        PDX_SAV_2MX16_XP(vTempInput,outa,outp, (2*PDX_M)*2);
	    PDX_SAPOS_2MX16_FP( outa, outp );
	}
}

void conv2d_3x3_8bit_conv_stride_1x1_valid_padding(
													const int8_t* pInputBuffer,
													const int8_t* pWeightsBuffer,
													const int32_t* pBiasBuffer,
													int8_t* pOutputBuffer,
													int32_t nInChannels,
													int32_t nOutChannels,
													int32_t nWidth,
													int32_t nHeight,
													int32_t nFilters,
													int32_t *nQuantizedMultiplier,
													int32_t *nQuantizedShift,
													int32_t pInZeroPoint,
													int32_t pOutZeroPoint
													)
{

	int8_t* __restrict outp = (int8_t*) pOutputBuffer;

	const immediate Lane=0;
	//Defining the input and filter offsets
	xb_vec2Mx16 vInZP = PDX_REP_2MX16((xb_vec2Mx16)pInZeroPoint,Lane);//Replicates the lane of data specified, across all lanes of a vector register

	xb_vec2Mx16 vin,vwt;
	xb_int32 temp;
	xb_int40 sat_sum;
	xb_int80 product;

	vbool4M temp_mask;
	vbool2M acc_mask, ffff;

	xb_vec2Mx40 acc = 0;
	xb_vec2Mx8 *inp = (xb_vec2Mx8 *)pInputBuffer;
	int32_t nFilterDepth = nInChannels;
	int32_t nFilterRem = nFilterDepth % 16;//2*PDX_M
	int32_t nFilterDepth_16mul = nFilterDepth - nFilterRem;

	int32_t nChannelCnt = 0;
	//if channels are multiple of 16
	if(nFilterRem == 0)
	{
		int32_t nRow,nCol;
		int8_t* pInt = (int8_t*)pInputBuffer;
		for(nRow = 0 ;nRow < nHeight-2; nRow++)
		{
			for(nCol = 0;nCol < nWidth-2; nCol++)
			{
				int8_t* pCurrInt = pInt;
				int8_t* pCurrWt = (int8_t*)pWeightsBuffer;
				for(int32_t nFil = 0; nFil < nFilters; nFil++)
				{
					int8_t* pProcPixel = pCurrInt;//reset
					acc = 0;//reset accumulator
					for(int32_t nKernelHeight = 0; nKernelHeight < 3 ; nKernelHeight++)
					{
						for(int32_t nKernelWidth = 0; nKernelWidth < 3 ; nKernelWidth++)
						{
							//inp = (xb_vec2Mx8 *)(pInputBuffer + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);	//Reinitialise input pointer for each output pixel
							inp = (xb_vec2Mx8 *)(pProcPixel);
							valign ina; // define align vector
							ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

							//xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight + 1)*INT_3x3_FILTER_WIDTH*nInChannels + (nKernelWidth+1)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels); //Move to next filter for each output pixel
							xb_vec2Mx8 *wtp = (xb_vec2Mx8 *)pCurrWt;
							valign wta;	// define align vector
							wta=PDX_LA_2MX8_PP (wtp);

							//for all the input pixels
							for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
							{
								PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
								PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
								vin+=vInZP;		//Add input offset

								PDX_MULAQW_2MX16(acc,vwt,vin);
							}
							//jump to next pixel
							pProcPixel += nInChannels;
							pCurrWt += nInChannels;
						}
						//jump to next row
						pProcPixel += (nWidth*nInChannels) - 3*nInChannels;
					}
					*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
				}
				pInt += nInChannels;//move to next pixel since stride is 1
			}
		}
	}
	//to handle cases when the input channels are not multiple of 16. We handle input channels in chunks of 16 and
	//perform load and accumulate operation once for the remaining channels with appropriate mask
	else
	{
		nFilterDepth_16mul = nFilterDepth - nFilterRem;
		temp_mask = PDX_MOVB_AU32((0b1<<(nFilterRem)) - 1);
		acc_mask = PDX_CVTBB2M_B4M_L(temp_mask);  // mask to accumulate values of remaining channels

		int32_t nRow,nCol;
		int8_t* pInt = (int8_t*)pInputBuffer;
		for(nRow = 0 ;nRow < nHeight-2; nRow++)
		{
			for(nCol = 0;nCol < nWidth-2; nCol++)
			{
				int8_t* pCurrInt = pInt;
				int8_t* pCurrWt = (int8_t*)pWeightsBuffer;
				for(int32_t nFil = 0; nFil < nFilters; nFil++)
				{
					int8_t* pProcPixel = pCurrInt;//reset
					acc = 0;//reset accumulator
					for(int32_t nKernelHeight = 0; nKernelHeight < 3 ; nKernelHeight++)
					{
						for(int32_t nKernelWidth = 0; nKernelWidth < 3 ; nKernelWidth++)
						{
							//inp = (xb_vec2Mx8 *)(pCurrInt + nCurrentRow*nWidth*nInChannels + nCurrentCol*nInChannels);
							inp = (xb_vec2Mx8 *)(pProcPixel);
							//Reinitialise input pointer for each output pixel
							valign ina; // define align vector
							ina = PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

							//xb_vec2Mx8 *wtp = (xb_vec2Mx8 *) (pWeightsBuffer + (nKernelHeight)*INT_3x3_FILTER_WIDTH*nInChannels +	(nKernelWidth)*nInChannels + nFil*INT_3X3_FILTER_WIDTH_x_HEIGHT*nInChannels);
							xb_vec2Mx8 *wtp = (xb_vec2Mx8 *)pCurrWt;
							//Move to next filter for each output pixel
							valign wta;	// define align vector
							wta=PDX_LA_2MX8_PP (wtp);

							//for all the input pixels
							for (int32_t nPixProcessed= 0; nPixProcessed < nFilterDepth_16mul; nPixProcessed += (2*PDX_M))
							{
								PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
								PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
								vin+=vInZP;		//Add input offset

								PDX_MULAQW_2MX16(acc,vwt,vin);
							}
							//for remaining channels
							PDX_LA16_2MX8_XP (vin, ina, inp, 2*PDX_M); // load aligned, extend
							PDX_LA16_2MX8_XP (vwt, wta, wtp, 2*PDX_M); // load aligned, extend
							vin+=vInZP;		//Add input offset

							//multiply and accumulate
							PDX_MULAQW_2MX16_T(acc,vwt,vin,acc_mask);

							//jump to next pixel
							pProcPixel += nInChannels;
							pCurrWt += nInChannels;
						}
						//jump to next row
						pProcPixel += (nWidth*nInChannels) - 3*nInChannels;
					}
					*outp++ = quantize_and_store(acc,pBiasBuffer[nFil],nQuantizedMultiplier[nFil],nQuantizedShift[nFil],nFil,pOutZeroPoint);
				}
				pInt += nInChannels;//move to next pixel since stride is 1
			}
		}
	}
}


void transform_weights(
		int8_t* pOldBuffer,
		int8_t* pNewBuffer,
		int32_t nKernelH,
		int32_t nKernelW,
		int32_t nKernelCh,
		int32_t nNumKernels)
{
	int32_t temp =nKernelCh*nKernelW*nKernelH;
	for(int32_t i=0; i<nKernelH;i++){
		int32_t i_temp = i*nKernelCh*nKernelW;
		for(int32_t j=0; j<nKernelW;j++){
			int32_t j_temp = j*nKernelCh;
			for(int32_t k=0; k<nKernelCh;k++){
				for(int32_t l=0; l<nNumKernels;l++){

					*pNewBuffer++ = *(pOldBuffer + l*temp+
												   k +
												   j_temp+
												   i_temp);
				}
			}
		}
	}
}

void get_single_row_single_channel_weights(
											int8_t* pOldBuffer,
											int8_t* pNewBuffer,
											int32_t nKernelH,
											int32_t nKernelW,
											int32_t nKernelCh,
											int32_t nNumKernels,
											int32_t nCh,
											int32_t nRow)
{
	int32_t temp =nKernelCh*nKernelW*nKernelH;
	int32_t i_temp = nRow*nKernelCh*nKernelW;
	for(int32_t j=0; j<nKernelW;j++){
		int32_t j_temp = j*nKernelCh;
		for(int32_t l=0; l<nNumKernels;l++){
			*pNewBuffer++ = *(pOldBuffer + l*temp+
										   nCh +
										   j_temp+
										   i_temp);
		}
	}
}


void pad_image (
		int8_t* pInputBuffer,
		int8_t* pOutputBuffer,
		ADI_CONV_BUFF_DATATYPE nInHeight,
		ADI_CONV_BUFF_DATATYPE nInWidth,
		ADI_CONV_BUFF_DATATYPE nInChannels,
		ADI_CONV_BUFF_DATATYPE nZeroPoint,
		ADI_CONV_BUFF_DATATYPE nPadHeight,
		ADI_CONV_BUFF_DATATYPE nPadWidth)
{
	int8_t* pIn_buffer = (int8_t*) pInputBuffer;
	int8_t* pPadded_buffer = (int8_t*) pOutputBuffer;

	int32_t nPadWidth_L, nPadWidth_R, nPadHeight_T, nPadHeight_B;
	nPadWidth_L =(int32_t) (nPadWidth>>1);				//Left Padding
	nPadWidth_R = nPadWidth - nPadWidth_L;

	nPadHeight_T =(int32_t) (nPadHeight>>1);			//Top padding
	nPadHeight_B = nPadHeight - nPadHeight_T;

	int32_t newHeight = nInHeight+nPadHeight;
	int32_t newWidth = nInWidth+nPadWidth;

	for(int32_t nRow = 0; nRow< newHeight; nRow++){
		for(int32_t nCol = 0; nCol< newWidth; nCol++){
			if (nCol<nPadWidth_L){//Left padding if present
				memset(pPadded_buffer, -nZeroPoint, sizeof(int8_t)*nInChannels);
				pPadded_buffer+=nInChannels;
			}
			if (nCol>=nPadWidth_L && nCol<nInWidth+nPadWidth_L){
				if (nRow<nPadHeight_T){//Top padding if present
					memset(pPadded_buffer, -nZeroPoint, sizeof(int8_t)*nInChannels);
					pPadded_buffer+=nInChannels;
				}
				if (nRow>=nInHeight+nPadHeight_T){//Bottom padding if present
					memset(pPadded_buffer, -nZeroPoint, sizeof(int8_t)*nInChannels);
					pPadded_buffer+=nInChannels;
				}
				if (nRow>=nPadHeight_T && nRow<nInHeight+nPadHeight_T){//No padding
					memcpy(pPadded_buffer, pIn_buffer, sizeof(int8_t)*nInChannels);
					pPadded_buffer+=nInChannels;
					pIn_buffer +=nInChannels;
				}
			}
			if (nCol>=(nInWidth+nPadWidth_L)){//Check for right padding
				memset(pPadded_buffer, -nZeroPoint, sizeof(int8_t)*nInChannels);
				pPadded_buffer+=nInChannels;
			}
		}
	}
}

void get_padded_input(
		int8_t* pOldBuffer,
		int8_t* pNewBuffer,
		int32_t nKernelH,
		int32_t nKernelW,
		int32_t nKernelCh,
		int32_t nNumKernels,
		int32_t nInputH,
		int32_t nInputW,
		int32_t nInputCh)
{
	for(int32_t i=0; i<nKernelH;i++){
		int32_t i_temp = i*nInputCh*nInputW;
		for(int32_t j=0; j<nKernelW;j++){
			int32_t j_temp = j*nInputCh;
			for(int32_t k=0; k<nKernelCh;k++){
				memset(pNewBuffer, *(pOldBuffer + k +
												   j_temp+
												   i_temp),
									sizeof(int8_t)*nNumKernels);
				pNewBuffer+=nNumKernels;
			}
		}
	}
}


void conv2d_mxn_8bit_dialation_1x1(
		const int8_t* pInputBuffer,
		const int8_t* pWeightsBuffer,
		const int32_t* pBiasBuffer,
		int8_t* pOutputBuffer,
		int32_t nBatches,
		int32_t nInChannels,
		int32_t nOutChannels,
		int32_t nKernelHeight,
		int32_t nKernelWidth,
		int32_t nNumKernels,
		int32_t nInputWidth,
		int32_t nInputHeight,
		int32_t stride_height,
		int32_t stride_width,
		int32_t nPadHeight,
		int32_t nPadWidth,
		int32_t nOutHeight,
		int32_t nOutWidth,
		int32_t *pQuantizedMultiplier,
		int32_t *pQuantizedShift,
		int32_t pInZeroPoint,
		int32_t pOutZeroPoint,
		int32_t nFilterZeroPoint,
		int32_t nActMin,
		int32_t nActMax)
{
	xb_vecMx8* __restrict outp  = (xb_vecMx8 *)pOutputBuffer;
	valign outa = PDX_LA_MX8_PP (outp); // prime, NOP if a[] is aligned
	const immediate Lane=0;

	xb_vec2Mx16 vin,vwt;
	xb_int32 temp;
	xb_int40 sat_sum;
	xb_int80 product;

	vbool4M temp_mask;
	vbool2M acc_mask, ffff;

	xb_vec2Mx40 acc = 0;

	int32_t nTotalPadWidth, nTotalPadHeight;
	nTotalPadWidth = (nOutWidth-1)*stride_width + nKernelWidth - nInputWidth;
	nTotalPadHeight = (nOutHeight-1)*stride_height + nKernelHeight - nInputHeight;

	uint32_t nWeightBufSize =nNumKernels*nKernelHeight*nKernelWidth*nInChannels;
	uint32_t nPaddedInputSize =nInChannels*(nInputWidth+nTotalPadWidth)*(nInputHeight+nTotalPadHeight);
	int32_t nIndexBuffer = 128;


	transform_weights((int8_t*) pWeightsBuffer,(int8_t*)&pTemp[nPaddedInputSize+nIndexBuffer], nKernelHeight,nKernelWidth,nInChannels, nNumKernels);


	xb_vec2Mx8 *wtp;// = (xb_vec2Mx8 *)pWeightsBuffer;
	xb_vec2Mx8 *inp;// = (xb_vec2Mx8 *)pInputBuffer;
	xb_vecMx32 first8, last8;
	xb_vec2Mx40 outacc;
	xb_vecMx80 quant_acc;
	const immediate round_mode = ROUNDING_MODE;
	xb_vecMx32 mult_l,mult_h;
	xb_vecMx32 shift_l,shift_h;
	//xb_vec2Mx40 vbias;
	xb_vecMx32 vbias_l,vbias_h;
	xb_vecMx32 conv_out;
	xb_vecMx32 vmin = nActMin;
	xb_vecMx32 vmax = nActMax;
	xb_vec2Mx16 vInZP = pInZeroPoint;
	xb_vecMx32 vOutZP = pOutZeroPoint;
	xb_vec2Mx16 vFilterZP =nFilterZeroPoint;

	int32_t nFilterDepth = nInChannels;

	int32_t nOutputHeight = nOutHeight; //Stride 1
	int32_t nOutputWidth = nOutWidth;

	int32_t nOutChannelsMod16 = ((int)(nOutChannels / 16))*16;//2*PDX_M
	int32_t nPixLeft = nOutChannels;
	int32_t nPixToWrite = 0;

	for (int32_t nBatch = 0; nBatch < nBatches; ++nBatch) {
		//Get padded image
		pad_image((int8_t*) (pInputBuffer+nBatch*nInputHeight*nInputWidth*nInChannels),(int8_t*)pTemp, nInputHeight, nInputWidth, nInChannels,pInZeroPoint, nTotalPadHeight,nTotalPadWidth);

		for (int32_t out_y = 0; out_y < nOutputHeight; ++out_y) {
			//update inp and wt
			for (int32_t out_x = 0; out_x < nOutputWidth; ++out_x) {
				nPixLeft = nOutChannels;

				//Extract the corresponding input buffer
                get_padded_input((int8_t*) (pTemp+out_y*stride_height*nInChannels*(nInputWidth+nTotalPadWidth)+stride_width*out_x*nInChannels),(int8_t*)&pTemp[nPaddedInputSize+nIndexBuffer+nWeightBufSize], nKernelHeight,nKernelWidth,nInChannels, nNumKernels, nInputHeight+nTotalPadHeight,nInputWidth+nTotalPadWidth,nInChannels);

				for (int32_t nOutChannel = 0; nOutChannel < nOutChannelsMod16; nOutChannel+=2*PDX_M) {
					inp = (xb_vec2Mx8*)(&pTemp[nPaddedInputSize+nIndexBuffer+nWeightBufSize] + nOutChannel);
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					wtp = (xb_vec2Mx8*)(&pTemp[nPaddedInputSize+nIndexBuffer]+ nOutChannel);
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//read in mult factors and bias for the channels
					xb_vecMx32 *vMult = (xb_vecMx32 *)(pQuantizedMultiplier + nOutChannel);
					valign wMulta =  PDX_LA_MX32_PP(vMult);

					xb_vecMx32 *vShift = (xb_vecMx32 *)(pQuantizedShift + nOutChannel);
					valign wShifta =  PDX_LA_MX32_PP(vShift);

					xb_vecMx32 *vBias = (xb_vecMx32 *)(pBiasBuffer + nOutChannel);
					valign wBiasa =  PDX_LA_MX32_PP(vBias);

					//read 8 way 32 bit signed
					PDX_LA_MX32_XP (mult_l, wMulta, vMult, 4*PDX_M);
					PDX_LA_MX32_XP (mult_h, wMulta, vMult, 0);

					PDX_LA_MX32_XP (shift_l, wShifta, vShift, 4*PDX_M);
					PDX_LA_MX32_XP (shift_h, wShifta, vShift, 0);

					PDX_LA_MX32_XP (vbias_l, wBiasa, vBias, 4*PDX_M);
					PDX_LA_MX32_XP (vbias_h, wBiasa, vBias, 0);

					vbias_l = PDX_SLS_MX32(vbias_l,1);//*2 to match with acc
					vbias_h = PDX_SLS_MX32(vbias_h,1);//*2 to match with acc

					acc = 0;// Reset acc
					//Have input buffer in required format. Perform the conv/matmul op and then store  min(2*PDX_M, RemainingOutChannels) pixels at a time
					//Use same input buffer for all filters to get one row of output pixels.
					for(int32_t nKerCh =0; nKerCh<nInChannels*nKernelHeight*nKernelWidth;nKerCh++){
						//READ IP
						PDX_LA16_2MX8_XP (vin, ina, inp, nNumKernels);//read 2*PDX_M number of channels for 1 pixel, skip to adjoining pixel
						vin += vInZP;		//Add input offset
						ina = PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned
						//READ WT
						PDX_LA16_2MX8_XP (vwt, wta, wtp, nNumKernels);//read 2*PDX_M number of channels for 1 pixel
//								vwt += vFilterZP;	//Add filter offset
						wta = PDX_LA_2MX8_PP (wtp); // prime, NOP if a[] is aligned
						//MAC
						PDX_MULAQW_2MX16(acc,vin,vwt);//acc contains upto 2*PDX_M channel results for pixel

					}
					//Quantize and store
					//quantization compensation

					PDX_CVT32D_2MX40(last8, first8, acc);	//Converting 40bit results to 32bit to prevent loss of accuracy from packing of 40bit -> 16bit
					if (pBiasBuffer)
						first8 += vbias_l;

					//first8
					quant_acc = mult_l * first8;	//Multiplying 2 32-bit vectors and storing result in 80bit vector
					//shift and round
					quant_acc = PDX_SLS_MX80(quant_acc,shift_l);//saturating left shift, right shift if negative
					//round and shift and saturate
					conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);	//pack 80bit result to 32bit with rounding and saturation.
					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nPixLeft -= PDX_M;
					PDX_SAV32_MX8_XP(conv_out, outa, outp, PDX_M);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					PDX_SAPOS_MX8_FP(outa,outp);//flush

					if (pBiasBuffer)
						last8 += vbias_h;

					//last8
					quant_acc = mult_h * last8;	//Multiplying 2 32-bit vectors and storing result in 80bit vector
					//shift and round
					quant_acc = PDX_SLS_MX80(quant_acc,shift_h);//saturating left shift, right shift if negative
					//round and shift and saturate
					conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);	//pack 80bit result to 32bit with rounding and saturation.
					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nPixLeft -= PDX_M;
					PDX_SAV32_MX8_XP(conv_out, outa, outp, PDX_M);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					PDX_SAPOS_MX8_FP(outa,outp);//flush

				}
				//Handle non-multiple of 16 pixels
				if(nPixLeft>0){

					inp = (xb_vec2Mx8*)(&pTemp[nPaddedInputSize+nIndexBuffer+nWeightBufSize] + nOutChannelsMod16);
					valign ina; // define align vector
					ina=PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned

					wtp = (xb_vec2Mx8*)(&pTemp[nPaddedInputSize+nIndexBuffer]+ nOutChannelsMod16);
					valign wta;	// define align vector
					wta=PDX_LA_2MX8_PP (wtp);

					//read in mult factors and bias for the channels
					xb_vecMx32 *vMult = (xb_vecMx32 *)(pQuantizedMultiplier + nOutChannelsMod16);
					valign wMulta =  PDX_LA_MX32_PP(vMult);

					xb_vecMx32 *vShift = (xb_vecMx32 *)(pQuantizedShift + nOutChannelsMod16);
					valign wShifta =  PDX_LA_MX32_PP(vShift);

					xb_vecMx32 *vBias = (xb_vecMx32 *)(pBiasBuffer + nOutChannelsMod16);
					valign wBiasa =  PDX_LA_MX32_PP(vBias);

					//read 8 way 32 bit signed
					PDX_LA_MX32_XP (mult_l, wMulta, vMult, 4*PDX_M);
					PDX_LA_MX32_XP (mult_h, wMulta, vMult, 0);

					PDX_LA_MX32_XP (shift_l, wShifta, vShift, 4*PDX_M);
					PDX_LA_MX32_XP (shift_h, wShifta, vShift, 0);

					PDX_LA_MX32_XP (vbias_l, wBiasa, vBias, 4*PDX_M);
					PDX_LA_MX32_XP (vbias_h, wBiasa, vBias, 0);

					vbias_l = PDX_SLS_MX32(vbias_l,1);//*2 to match with acc
					vbias_h = PDX_SLS_MX32(vbias_h,1);//*2 to match with acc

					acc = 0;// Reset acc
					//Have input buffer in required format. Perform the conv/matmul op and then store  min(2*PDX_M, RemainingOutChannels) pixels at a time
					//Use same input buffer for all filters to get one row of output pixels.

					for(int32_t nKerCh =0; nKerCh<nInChannels*nKernelHeight*nKernelWidth;nKerCh++){
						//READ IP
						PDX_LA16_2MX8_XP (vin, ina, inp, nNumKernels);//read 2*PDX_M number of channels for 1 pixel, skip to adjoining pixel
						vin += vInZP;		//Add input offset
						ina = PDX_LA_2MX8_PP (inp); // prime, NOP if a[] is aligned
						//READ WT
						PDX_LA16_2MX8_XP (vwt, wta, wtp, nNumKernels);//read 2*PDX_M number of channels for 1 pixel
	//								vwt += vFilterZP;	//Add filter offset
						wta = PDX_LA_2MX8_PP (wtp); // prime, NOP if a[] is aligned
						//MAC
						PDX_MULAQW_2MX16(acc,vin,vwt);//acc contains upto 2*PDX_M channel results for pixel

					}
					//Quantize and store
					//quantization compensation

					PDX_CVT32D_2MX40(last8, first8, acc);	//Converting 40bit results to 32bit to prevent loss of accuracy from packing of 40bit -> 16bit
					if (pBiasBuffer)
						first8 += vbias_l;

					//first8
					quant_acc = mult_l * first8;	//Multiplying 2 32-bit vectors and storing result in 80bit vector
					//shift and round
					quant_acc = PDX_SLS_MX80(quant_acc,shift_l);//saturating left shift, right shift if negative
					//round and shift and saturate
					conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);	//pack 80bit result to 32bit with rounding and saturation.
					//add output zero point
					conv_out += vOutZP;
					//Saturate to 8 bit range output_activation_min to 127
					conv_out = PDX_MIN_MX32(conv_out,vmax);
					conv_out = PDX_MAX_MX32(conv_out,vmin);
					nPixToWrite = MIN(nPixLeft,PDX_M);
					PDX_SAV32_MX8_XP(conv_out, outa, outp, nPixToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
					PDX_SAPOS_MX8_FP(outa,outp);//flush
					nPixLeft -= nPixToWrite;

					if (nPixLeft>0){
						if (pBiasBuffer)
							last8 += vbias_h;

						//last8
						quant_acc = mult_h * last8;	//Multiplying 2 32-bit vectors and storing result in 80bit vector
						//shift and round
						quant_acc = PDX_SLS_MX80(quant_acc,shift_h);//saturating left shift, right shift if negative
						//round and shift and saturate
						conv_out = PDX_PACKQSRV_MX80   (quant_acc, round_mode);	//pack 80bit result to 32bit with rounding and saturation.
						//add output zero point
						conv_out += vOutZP;
						//Saturate to 8 bit range output_activation_min to 127
						conv_out = PDX_MIN_MX32(conv_out,vmax);
						conv_out = PDX_MAX_MX32(conv_out,vmin);
						nPixToWrite = MIN(nPixLeft,PDX_M);
						PDX_SAV32_MX8_XP(conv_out, outa, outp, nPixToWrite);//8-way 8-bit signed Aligning vector register variable-length store intrinsic, converting
						PDX_SAPOS_MX8_FP(outa,outp);//flush
						nPixLeft -= nPixToWrite;

					}
				}
			}
		}
	}
}
