#include <cstdint>

extern const unsigned int g_person_detect_model_data_size;
extern const unsigned char g_person_detect_model_data[]__attribute__((section(".L2.data"), aligned(16)));
