/*****************************************************************************
 * PeopleDetectCpp.h
 *****************************************************************************/

#ifndef __PRIMITIVES_H__
#define __PRIMITIVES_H__
#pragma once
#include <inttypes.h>
/* Add your custom header content here */

//---------DATATYPES-------------
//input data type is int8, bias/mult are int32
typedef int8_t ADI_ACTIVATION_DATATYPE;
typedef int8_t ADI_WEIGHTS_DATATYPE;
typedef int32_t ADI_CONV_BUFF_DATATYPE;
typedef uint32_t ADI_QMULTIPLIER_DATATYPE;
typedef int16_t ADI_16BIT_CONV_BUFF_DATATYPE;

//#define USE_OPTIMIZED_LSTM

#define USE_OPTIMIZED_DEPTHCONV
//#define USE_NON_INTERLEAVED_DEPTHCONV

//#define USE_OPTIMIZED_FC

#define USE_OPTIMISED_3X3_CONV
#define USE_OPTIMIZED_1x1_CONV
//#define USE_NON_INTERLEAVED_1x1_CONV

//#define USE_OPTIMIZED_AVGPOOL

//#define USE_OPTIMIZED_TANH_INT16
//#define USE_OPTIMIZED_LOGISTIC_INT8
//#define USE_OPTIMIZED_LOGISTIC_INT16
//#define OPT_LOGISTIC_INT16_MULTIPLIER
//#define OPT_TANH_INT16_MULTIPLIER

#ifdef __XTENSA__
#include <xtensa/sim.h>
#include <xtensa/tie/xt_pdxn.h>
#endif

//TODO:Adjust to reasonable levels

#define TEMP_BUFFER_SIZE 96*96*20
//#define TEMP_WT_BUFFER_SIZE 7*7*128


//#define DISPLAY_CYCLE_COUNTS

#ifdef DISPLAY_CYCLE_COUNTS
#define DO_CYCLE_COUNTS
#include "sharc/cycle_count.h" /* Define the macros */
#endif

//1x1 2D convolution in non-interleaved format using 16bit Eagle intrinsics
void conv2d_1x1_non_int_asm16(
		const ADI_ACTIVATION_DATATYPE *pInputBuffer,			//Input buffer
		ADI_ACTIVATION_DATATYPE *pOutputBuffer,			//Output buffer
		const ADI_WEIGHTS_DATATYPE *pWeightsBuffer,			//Weight buffer
		const ADI_CONV_BUFF_DATATYPE *pBiasBuffer,			//Bias
		ADI_CONV_BUFF_DATATYPE nWidth,					//Width of input buffer
		ADI_CONV_BUFF_DATATYPE nInChannels,				//In Channels
		ADI_CONV_BUFF_DATATYPE nOutChannels,			//Out Channels
		ADI_QMULTIPLIER_DATATYPE *pQuantizedMultiplier,	//Quantized multiplier
		ADI_CONV_BUFF_DATATYPE *pQuantizedShift,		//Quantized scale
		ADI_CONV_BUFF_DATATYPE pInZeroPoint,          //Input Zero Point);
		ADI_CONV_BUFF_DATATYPE pOutZeroPoint);	    //Output Zero Point);

void conv2d_1x1_non_int_asm8(
		const ADI_ACTIVATION_DATATYPE *pInputBuffer,			//Input buffer
		ADI_ACTIVATION_DATATYPE *pOutputBuffer,			//Output buffer
		const ADI_WEIGHTS_DATATYPE *pWeightsBuffer,			//Weight buffer
		const ADI_CONV_BUFF_DATATYPE *pBiasBuffer,			//Bias
		ADI_CONV_BUFF_DATATYPE nWidth,					//Width of input buffer
		ADI_CONV_BUFF_DATATYPE nInChannels,				//In Channels
		ADI_CONV_BUFF_DATATYPE nOutChannels,			//Out Channels
		ADI_QMULTIPLIER_DATATYPE *pQuantizedMultiplier,	//Quantized multiplier
		ADI_CONV_BUFF_DATATYPE *pQuantizedShift,		//Quantized scale
		ADI_ACTIVATION_DATATYPE pInZeroPoint,          //Input Zero Point);
		ADI_QMULTIPLIER_DATATYPE pOutZeroPoint);	    //Output Zero Point);

//2D depthwise-convolution with stride of 1 in non-interleaved format using 16bit Eagle intrinsics. Also accounts for padding
void depthconv2d_skip_asm_non_interleaved_padding1_8bitconv_16bitquant(
		const ADI_ACTIVATION_DATATYPE *pInputBuffer,					//Input buffer
		ADI_ACTIVATION_DATATYPE *pOutputBuffer,					//Output buffer
		const ADI_WEIGHTS_DATATYPE *pWeightsBuffer,					//Weight buffer
		const ADI_CONV_BUFF_DATATYPE *pBiasBuffer,					//Bias
		ADI_CONV_BUFF_DATATYPE nInputWidth,							//Width of input buffer
		ADI_CONV_BUFF_DATATYPE nDepthMult,							//If input channels are repeated
		ADI_CONV_BUFF_DATATYPE nInChannels,						//In Channels
		ADI_CONV_BUFF_DATATYPE nOutChannels,					//Out Channels
		ADI_ACTIVATION_DATATYPE nKernelSize,					//Kernel size
		ADI_ACTIVATION_DATATYPE nTotalPadding,					//Total padding
		ADI_QMULTIPLIER_DATATYPE *pQuantizedMultiplier,			//Quantized multiplier
		ADI_CONV_BUFF_DATATYPE *pQuantizedShift,				//Quantized scale
		ADI_CONV_BUFF_DATATYPE pInZeroPoint,          //Input Zero Point
		ADI_CONV_BUFF_DATATYPE pOutZeroPoint);          //Output Zero Point

//2D depthwise-convolution with stride of 2 in non-interleaved format using 16bit Eagle intrinsics. Also accounts for padding
void depthconv2d_noskip_asm_non_interleaved_padding1_8bitconv_16bitquant(
		const ADI_ACTIVATION_DATATYPE *pInputBuffer,						//Input buffer
		ADI_ACTIVATION_DATATYPE *pOutputBuffer,						//Output buffer
		const ADI_WEIGHTS_DATATYPE *pWeightsBuffer,						//Weight buffer
		const ADI_CONV_BUFF_DATATYPE *pBiasBuffer,						//Bias
		ADI_CONV_BUFF_DATATYPE nInputWidth,								//Width of input buffer
		ADI_CONV_BUFF_DATATYPE nDepthMult,							//If input channels are repeated
		ADI_CONV_BUFF_DATATYPE nInChannels,							//In Channels
		ADI_CONV_BUFF_DATATYPE nOutChannels,						//Out Channels
		ADI_ACTIVATION_DATATYPE nKernelSize,						//Kernel size
		ADI_ACTIVATION_DATATYPE nTotalPadding,						//Total padding
		ADI_QMULTIPLIER_DATATYPE *pQuantizedMultiplier,				//Quantized multiplier
		ADI_CONV_BUFF_DATATYPE *pQuantizedShift,					//Quantized scale
		ADI_CONV_BUFF_DATATYPE pInZeroPoint,          //Input Zero Point
		ADI_CONV_BUFF_DATATYPE pOutZeroPoint);          //Output Zero Point

void depthconv2d_skip_asm_non_interleaved_8x10(
		const ADI_ACTIVATION_DATATYPE *pInputBuffer,			//Input buffer
		const ADI_WEIGHTS_DATATYPE *pWeightsBuffer,				//Weight buffer
		const ADI_CONV_BUFF_DATATYPE *pBiasBuffer,				//Bias
		ADI_ACTIVATION_DATATYPE *pOutputBuffer,					//Output buffer
		ADI_CONV_BUFF_DATATYPE nInputWidth,						//Width of input buffer
		ADI_CONV_BUFF_DATATYPE nInputLength,					//Length of input buffer
		ADI_CONV_BUFF_DATATYPE nInChannels,						//Depth of input buffer- In Channels
		ADI_CONV_BUFF_DATATYPE nOutputWidth,					//Width of output buffer
		ADI_CONV_BUFF_DATATYPE nOutputLength,					//Length of output buffer
		ADI_CONV_BUFF_DATATYPE nOutChannels,					//Depth of output buffer- Out Channels
		ADI_ACTIVATION_DATATYPE nKernelWidth,					//Width of filter
		ADI_ACTIVATION_DATATYPE nKernelLength,					//Length of filter
		ADI_ACTIVATION_DATATYPE nPaddingWidth,					//Width of padding
		ADI_ACTIVATION_DATATYPE nPaddingLength,					//Length of padding
		ADI_QMULTIPLIER_DATATYPE *pQuantizedMultiplier,			//Quantized multiplier
		ADI_CONV_BUFF_DATATYPE *pQuantizedShift,				//Quantized scale
		ADI_CONV_BUFF_DATATYPE pInZeroPoint,          			//Input Zero Point
		ADI_CONV_BUFF_DATATYPE pOutZeroPoint,         		//Output Zero Point
		ADI_CONV_BUFF_DATATYPE output_activation_min,
		ADI_CONV_BUFF_DATATYPE output_activation_max);


void fullyConnected_asm_8bit(
	const ADI_ACTIVATION_DATATYPE* pInputBuffer,
	const ADI_WEIGHTS_DATATYPE* pWeightsBuffer,
	const ADI_CONV_BUFF_DATATYPE* pBiasBuffer,
	ADI_ACTIVATION_DATATYPE* pOutputBuffer,
	ADI_CONV_BUFF_DATATYPE nFilterDepth,					//filter_shape.Dims(filter_dim_count - 1),;
	ADI_CONV_BUFF_DATATYPE nOutsize,
	ADI_CONV_BUFF_DATATYPE nBatches,
	ADI_QMULTIPLIER_DATATYPE nQuantizedMultiplier,
	ADI_CONV_BUFF_DATATYPE nQuantizedShift,
	ADI_CONV_BUFF_DATATYPE nInputOffset,
	ADI_CONV_BUFF_DATATYPE nFilterOffset,
	ADI_CONV_BUFF_DATATYPE nOutputOffset,
	ADI_CONV_BUFF_DATATYPE output_activation_min,
	ADI_CONV_BUFF_DATATYPE output_activation_max);

void fullyConnected_asm_16bit(
	const ADI_16BIT_CONV_BUFF_DATATYPE* pInputBuffer,
	const ADI_WEIGHTS_DATATYPE* pWeightsBuffer,
	const ADI_CONV_BUFF_DATATYPE* pBiasBuffer,
	ADI_16BIT_CONV_BUFF_DATATYPE* pOutputBuffer,
	ADI_CONV_BUFF_DATATYPE nFilterDepth,
	ADI_CONV_BUFF_DATATYPE nOutsize,
	ADI_CONV_BUFF_DATATYPE nBatches,
	ADI_QMULTIPLIER_DATATYPE nQuantizedMultiplier,
	ADI_CONV_BUFF_DATATYPE nQuantizedShift,
	ADI_CONV_BUFF_DATATYPE nInputOffset,
	ADI_CONV_BUFF_DATATYPE nFilterOffset,
	ADI_CONV_BUFF_DATATYPE nOutputOffset,
	ADI_CONV_BUFF_DATATYPE output_activation_min,
	ADI_CONV_BUFF_DATATYPE output_activation_max);


//Average pool activation implemented for interleaved data format using Eagle intrinsics
void avgPool_interleaved_asm(const ADI_ACTIVATION_DATATYPE* pInputBuffer, ADI_ACTIVATION_DATATYPE* pOutputBuffer, int32_t nWidth, int32_t nChannels);


/*-------------------------------------------------------------------------
Vectorized Hyperbolic Tangent
The function returns the hyperbolic Tan of x. 16-bit fixed-point function
accepts input in Q3.12 and form output in Q7.8 format.

Input:
  x  input value (Q3.12)
Output:
  z  result (Q7.8)
Returned value:
  None
Domain:
  Whole range
---------------------------------------------------------------------------*/
void Tanh_opt_Int16( ADI_CONV_BUFF_DATATYPE nInputMultiplier, ADI_CONV_BUFF_DATATYPE nInputLeftShift, ADI_CONV_BUFF_DATATYPE nLength,const ADI_16BIT_CONV_BUFF_DATATYPE* pInputData, ADI_16BIT_CONV_BUFF_DATATYPE* pOutputData);


/*-------------------------------------------------------------------------
Vectorized Logistic_int8
The function returns the Logistic (1/(1+exp(-x))) of x. 8-bit
fixed-point function accepts input in Q3.4 and form output in Q0.7 format.

Input:
  x  input value (Q3.4)
Output:
  z  result (Q0.7)
Returned value:
  None
Domain:
  Whole range
---------------------------------------------------------------------------*/
void Logistic_Int8_opt(ADI_CONV_BUFF_DATATYPE nInputZeroPoint, ADI_CONV_BUFF_DATATYPE nInputMultiplier, ADI_CONV_BUFF_DATATYPE nInputLeftShift, ADI_CONV_BUFF_DATATYPE nInputSize, const ADI_ACTIVATION_DATATYPE* pInputData, ADI_ACTIVATION_DATATYPE* pOutputData);

/*-------------------------------------------------------------------------
Vectorized Sigmoid_int16
The function returns the sigmoid (1/(1+exp(-x))) of x. 16-bit fixed-point
function accepts input in Q3.12 and form output in Q7.8 format.

Input:
  x  input value (Q3.12, Q3.4)
Output:
  z  result (Q7.8, Q0.7)
Returned value:
  None
Domain:
  Whole range
---------------------------------------------------------------------------*/
void Logistic_Int16_opt(ADI_CONV_BUFF_DATATYPE nInputMultiplier, ADI_CONV_BUFF_DATATYPE nInputLeftShift, ADI_CONV_BUFF_DATATYPE nInputSize, const ADI_16BIT_CONV_BUFF_DATATYPE* pInputData, ADI_16BIT_CONV_BUFF_DATATYPE* pOutputData);

//Elementwise Addition - Used as part of LSTM
void AddElementWise_asm(
	const ADI_16BIT_CONV_BUFF_DATATYPE* pInput1,
	const ADI_16BIT_CONV_BUFF_DATATYPE* pInput2,
	ADI_CONV_BUFF_DATATYPE nBatches,
	ADI_CONV_BUFF_DATATYPE nInputLen,
	ADI_16BIT_CONV_BUFF_DATATYPE* pOutput
);

//Elementwise Multiplication
void MulElementwise_asm(
	const ADI_16BIT_CONV_BUFF_DATATYPE* pInput1,
	const ADI_16BIT_CONV_BUFF_DATATYPE* pInput2,
	ADI_16BIT_CONV_BUFF_DATATYPE* pOutput,
	ADI_CONV_BUFF_DATATYPE nSize,
	ADI_QMULTIPLIER_DATATYPE pQuantizedMultiplier,
	ADI_CONV_BUFF_DATATYPE pQuantizedShift,
	ADI_CONV_BUFF_DATATYPE pInOffset1,
	ADI_CONV_BUFF_DATATYPE pInOffset2,
	ADI_CONV_BUFF_DATATYPE pOutOffset,
	ADI_CONV_BUFF_DATATYPE output_activation_min,
	ADI_CONV_BUFF_DATATYPE output_activation_max
);

void ReluQuantized_asm_8bit(
	const ADI_ACTIVATION_DATATYPE* pInput,
	ADI_ACTIVATION_DATATYPE* pOutput,
	const ADI_QMULTIPLIER_DATATYPE nSize,
	ADI_QMULTIPLIER_DATATYPE pQuantizedMultiplier,
	ADI_CONV_BUFF_DATATYPE pQuantizedShift,
	ADI_CONV_BUFF_DATATYPE pInOffset,
	ADI_CONV_BUFF_DATATYPE pOutOffset,
	ADI_CONV_BUFF_DATATYPE output_activation_min,
	ADI_CONV_BUFF_DATATYPE output_activation_max
);

void depthconv2d_8bitconv_16bitquant(
									const int8_t *pInputBuffer,						//Input buffer
									int8_t *pOutputBuffer,						    //Output buffer
									const int8_t *pWeightsBuffer,					//Weight buffer
									const int32_t *pBiasBuffer,						//Bias
									int32_t nInputWidth,							//Width of input buffer
									int32_t nInputHeight,							//Height of input buffer
									int32_t nDepthMult,							    //If input channels are repeated
									int32_t nInChannels,						    //In Channels
									int32_t nOutChannels,						    //Out Channels
									int32_t nKernelSizeWidth,						//Kernel size
									int32_t nKernelSizeHeight,						//Kernel size
									int32_t nTotalPaddingWidth,						//Total padding width
									int32_t nTotalPaddingHeight,					//Total padding height
									int32_t *pQuantizedMultiplier,				    //Quantized multiplier
									int32_t *pQuantizedShift,					    //Quantized scale
									int32_t pInZeroPoint,                           //Input Zero Point
									int32_t pOutZeroPoint,                          //Output Zero Point
									int32_t nStrideWidth,                           //stride in row dim
									int32_t nStrideHeight,
									int32_t nActMin,							//act min
									int32_t nActMax);                         //stride in column dim

//1x1 2D convolution in interleaved format using 16bit Eagle intrinsics
void conv2d_1x1_8bitconv_16bitquant(
									const int8_t* pInputBuffer,
									const int8_t* pWeightsBuffer,
									const int32_t* pBiasBuffer,
									int8_t* pOutputBuffer,
									int32_t nBatches,
									int32_t nInChannels,
									int32_t nOutChannels,
									int32_t nSize,
									int32_t *nQuantizedMultiplier,
									int32_t *nQuantizedShift,
									int32_t nInputOffset,
									int32_t nOutputOffset);

void conv2d_3x3_8bit_conv_stride_1x1(
		const int8_t* pInputBuffer,
		const int8_t* pWeightsBuffer,
		const int32_t* pBiasBuffer,
		int8_t* pOutputBuffer,
		int32_t nInChannels,
		int32_t nOutChannels,
		int32_t nWidth,
		int32_t nHeight,
		int32_t nFilters,
		int32_t *nQuantizedMultiplier,
		int32_t *nQuantizedShift,
		int32_t pInZeroPoint,
		int32_t pOutZeroPoint);

void conv2d_3x3_8bit_conv_stride_2x2(
		const int8_t* pInputBuffer,
		const int8_t* pWeightsBuffer,
		const int32_t* pBiasBuffer,
		int8_t* pOutputBuffer,
		int32_t nInChannels,
		int32_t nOutChannels,
		int32_t nWidth,
		int32_t nHeight,
		int32_t nFilters,
		int32_t *nQuantizedMultiplier,
		int32_t *nQuantizedShift,
		int32_t pInZeroPoint,
		int32_t pOutZeroPoint
		);

inline int8_t quantize_and_store(
		xb_vec2Mx40 acc,
		int32_t pBiasBuffer,
		int32_t nQuantizedMultiplierValue,
		int32_t nQuantizedShiftValue,
		int32_t nFil,
		int32_t pOutZeroPoint
		);

void conv2d_mxn_8bit_dialation_1x1(
		const int8_t* pInputBuffer,
		const int8_t* pWeightsBuffer,
		const int32_t* pBiasBuffer,
		int8_t* pOutputBuffer,
		int32_t nBatches,
		int32_t nInChannels,
		int32_t nOutChannels,
		int32_t nKernelHeight,
		int32_t nKernelWidth,
		int32_t nNumKernels,
		int32_t nInputWidth,
		int32_t nInputHeight,
		int32_t stride_height,
		int32_t stride_width,
		int32_t nPadHeight,
		int32_t nPadWidth,
		int32_t nOutHeight,
		int32_t nOutWidth,
		int32_t *pQuantizedMultiplier,
		int32_t *pQuantizedShift,
		int32_t pInZeroPoint,
		int32_t pOutZeroPoint,
		int32_t nFilterZeroPoint,
		int32_t nActMin,
		int32_t nActMax);

void conv2d_3x3_8bit_conv_stride_1x1_valid_padding(
		const int8_t* pInputBuffer,
		const int8_t* pWeightsBuffer,
		const int32_t* pBiasBuffer,
		int8_t* pOutputBuffer,
		int32_t nInChannels,
		int32_t nOutChannels,
		int32_t nWidth,
		int32_t nHeight,
		int32_t nFilters,
		int32_t *nQuantizedMultiplier,
		int32_t *nQuantizedShift,
		int32_t pInZeroPoint,
		int32_t pOutZeroPoint
		);

#endif /* __PRIMITIVES_H__ */
