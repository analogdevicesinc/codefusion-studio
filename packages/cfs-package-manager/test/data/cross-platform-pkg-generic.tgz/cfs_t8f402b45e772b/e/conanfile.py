"""

Copyright (c) 2026 Analog Devices, Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Recipe used ONLY to generate the `cross-platform-pkg-generic.tgz` fixture
consumed by `cfs pkg install --tar` tests. Not a real CFS package and not
published anywhere - see generate.sh in this directory.
"""

import os

from conan import ConanFile
from conan.tools.files import save


class CfsTarGenericMockConan(ConanFile):
    """
    Mock Conan package that declares no `settings` at all, the same shape
    as a real OS-independent CFS package (e.g. cfs_base_data_models). Its
    package_id never varies by os/arch, so a tarball of it must install
    successfully regardless of the host platform - used to confirm the
    local-tarball install path does not misclassify an OS-independent
    package as a platform mismatch.
    """

    name = "cfs_tar_generic_mock"
    version = "1.0.0"
    description = "Mock OS-independent package for cfs_local_install tests"
    license = "MIT"
    package_id_unknown_mode = "unrelated_mode"

    virtualbuildenv = False
    virtualrunenv = False

    def package(self):
        save(
            self,
            os.path.join(self.package_folder, "share", "README.txt"),
            "Mock cfs_tar_generic_mock package - no OS dependency\n"
        )
