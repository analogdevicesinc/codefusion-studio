/* Copyright 2020 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
#ifndef TENSORFLOW_COMPILER_MLIR_LITE_SCHEMA_SCHEMA_UTILS_H_
#define TENSORFLOW_COMPILER_MLIR_LITE_SCHEMA_SCHEMA_UTILS_H_

#include <cstddef>

#include "flatbuffers/flatbuffers.h"
#include "tensorflow/compiler/mlir/lite/schema/schema_generated.h"

namespace tflite {

// The following methods are introduced to resolve op builtin code shortage
// problem. The new builtin operator will be assigned to the extended builtin
// code field in the flatbuffer schema. Those methods helps to hide builtin code
// details.
BuiltinOperator GetBuiltinCode(const OperatorCode *op_code);

BuiltinOperator GetBuiltinCode(const OperatorCodeT *op_code);

// Returns the size of the given TensorType in bytes, or 0 if the TensorType is
// not supported, this function should be aligned with TfLiteTypeGetSize in
// lite/kernels/kernel_util.h.
size_t TensorTypeGetSize(::tflite::TensorType data_type);

}  // namespace tflite

#endif  // TENSORFLOW_COMPILER_MLIR_LITE_SCHEMA_SCHEMA_UTILS_H_
