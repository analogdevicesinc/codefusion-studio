#ifndef TESTS_UTIL_TEST_H
#define TESTS_UTIL_TEST_H

namespace flatbuffers {
namespace tests {

void NumericUtilsTest();
void IsAsciiUtilsTest();
void UtilConvertCase();


}  // namespace tests
}  // namespace flatbuffers

#endif
