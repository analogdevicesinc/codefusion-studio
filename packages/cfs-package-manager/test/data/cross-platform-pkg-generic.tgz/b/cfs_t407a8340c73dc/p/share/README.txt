Mock cfs_tar_generic_mock package - no OS dependency
