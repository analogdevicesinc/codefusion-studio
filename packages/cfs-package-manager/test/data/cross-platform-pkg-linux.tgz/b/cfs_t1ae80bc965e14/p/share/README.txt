Mock cfs_tar_platform_mock package built for os=Linux
