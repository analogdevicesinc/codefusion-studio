"""

Copyright (c) 2026 Analog Devices, Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Recipe used ONLY to generate the cross-platform `conan cache save` tarball
fixtures consumed by `cfs pkg install --tar` tests. Not a real CFS package
and not published anywhere - see generate.sh in this directory.
"""

import os

from conan import ConanFile
from conan.tools.files import save


class CfsTarPlatformMockConan(ConanFile):
    """
    Mock Conan package with no real build step. `package()` just drops
    marker files into the package folder. When built with
    settings.os=Linux, it additionally writes a file whose name contains
    "::" (modeled on the real-world `App::Cpan.3` Perl man page) to
    reproduce the illegal-Windows-filename failure that `conan cache
    restore` hits via Python's `tarfile.extractall` on Windows.
    """

    name = "cfs_tar_platform_mock"
    version = "1.0.0"
    description = "Mock package for cfs_local_install cross-platform tests"
    license = "MIT"
    settings = "os"
    package_type = "unknown"
    package_id_unknown_mode = "unrelated_mode"

    virtualbuildenv = False
    virtualrunenv = False

    def package(self):
        save(
            self,
            os.path.join(self.package_folder, "share", "README.txt"),
            f"Mock cfs_tar_platform_mock package built for os={self.settings.os}\n"
        )
        if str(self.settings.os) == "Linux":
            # Reproduces the real-world trigger: a Perl man page whose
            # filename contains a double colon, illegal on Windows.
            save(
                self,
                os.path.join(
                    self.package_folder,
                    "share", "man", "man3", "App::Cpan.3"
                ),
                "Mock man page with a Windows-illegal filename (contains '::').\n"
            )
