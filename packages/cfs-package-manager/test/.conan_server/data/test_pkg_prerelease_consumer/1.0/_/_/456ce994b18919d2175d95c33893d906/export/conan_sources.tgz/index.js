function activate() {
  console.log('test prerelease consumer active');
}

module.exports = {
  activate,
};
