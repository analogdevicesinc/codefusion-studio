/*
 */
/* ----------------------------------------------------------------------
 * Project:
 * Title:        adi_sharcfx_avgpool_s8.c
 * Description:  Pooling function implementations
 *
 * $Date:        1st May 2024
 * $Revision:    V.1.1.1
 *
 * Target Processor:  SHARC-FX Processor
 *
 * -------------------------------------------------------------------- */
#include <sys/platform.h>
#include <stdio.h>
#include <math.h>
#include <float.h>
#include <complex.h>
#include <matrix.h>
#include <filter.h>
#include <vector.h>

#define NVEC 32

#include "math_fixedpoint_vec.h"
/* Cross-platform data type definitions. */
#include "libdsp_types.h"

//#pragma once
#include <inttypes.h>

#ifdef __XTENSA__
#include <xtensa/sim.h>
#include <xtensa/tie/xt_pdxn.h>
#endif

#define MIN(X, Y) (((X) < (Y)) ? (X) : (Y))
#define MAX(X, Y) (((X) > (Y)) ? (X) : (Y))
/*
 * s8 average pooling function
 *
 * Refer to header file for details.
 *
 */
void adi_sharcfx_maxpool_s8(
							const int32_t input_y,
							const int32_t input_x,
							const int32_t output_y,
							const int32_t output_x,
							const int32_t stride_y,
							const int32_t stride_x,
							const int32_t kernel_y,
							const int32_t kernel_x,
							const int32_t pad_y,
							const int32_t pad_x,
							const int32_t act_min,
							const int32_t act_max,
							const int32_t ch_src,
						    const int8_t *src,
						    int8_t *dst)
{
	xb_vec4Mx8 in_vec0;
	xb_vec4Mx8 act_ll = act_min;
	xb_vec4Mx8 act_hl = act_max;
	xb_vec4Mx8* __restrict pvOut  = (xb_vec4Mx8 *)(dst);
	for (int i_y = 0; i_y < output_y; i_y++)
	{
		for (int i_x = 0; i_x < output_x; i_x++ )//process upto 4*PDX_M at a time
		{

			//kernel X and Y axis starting and end points
			const int32_t k_y_start = MAX(0, i_y * stride_y - pad_y);
			const int32_t k_y_end = MIN(i_y * stride_y - pad_y + kernel_y, input_y);
			const int32_t k_x_start = MAX(0, i_x * stride_x - pad_x);
			const int32_t k_x_end = MIN(i_x * stride_x - pad_x + kernel_x, input_x);

			//input and output
			const int8_t *src_in = src + i_y * stride_y * input_x * ch_src + i_x * stride_x * ch_src;

			//process for all channels
			int nBytesLeft = ch_src;
			for (int nc = 0; nc < ch_src;nc += 4*PDX_M)
			{
				valign pvOuta = PDX_LA_4MX8_PP(pvOut);
				xb_vec4Mx8 out = 0xFFffFF80;
				for (int k_y = 0; k_y < k_y_end - k_y_start; k_y++)
				{
					for (int k_x = 0; k_x < k_x_end - k_x_start; k_x++)
					{
						xb_vec4Mx8 *in_ptr = (xb_vec4Mx8 *)(src_in + ( (k_x * ch_src + k_y * input_x * ch_src)) + nc); //src_in modified at end
						valign in_ptra = PDX_LA_4MX8_PP (in_ptr);
						PDX_LA_4MX8_XP(in_vec0, in_ptra, in_ptr, 4*PDX_M);
						//find max
						out = PDX_MAX_4MX8(out,in_vec0);
					}
				}

				out = PDX_MAX_4MX8(out,act_ll);
				out = PDX_MIN_4MX8(out,act_hl);

				int nBytesWrite = MIN(nBytesLeft,4*PDX_M);
				PDX_SAV_4MX8_XP (out, pvOuta, pvOut, nBytesWrite);
				PDX_SAPOS_4MX8_FP (pvOuta, pvOut);
				nBytesLeft -= nBytesWrite;
			}
		}
	}
}






